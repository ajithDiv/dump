import React, { createContext, useContext, useState, useEffect } from 'react';
import { setGlobalLoadingSetter } from '../_services/loadingService';
const LoadingContext = createContext({
    loading: false,
    setLoading: () => { },
});
export const useLoading = () => useContext(LoadingContext);
export const LoadingProvider = ({ children }) => {
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        setGlobalLoadingSetter(setLoading); // So Axios can control loading
    }, []);
    return (
        <LoadingContext.Provider value={{ loading, setLoading }}>
            {children}
        </LoadingContext.Provider>
    );
};