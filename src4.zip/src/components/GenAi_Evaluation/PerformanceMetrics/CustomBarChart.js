import { Stack } from "@mui/material";
import React, { useState } from "react";
import Select from "react-select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const hardData = [
  {
    metric: "Coherence_score",
    tag: "Coh...",
    Latency: 157,
    Token: 14595,
    Cost: 0.1449,
  },
  {
    metric: "Factuality_score",
    tag: "Fac...",
    Latency: 200,
    Token: 18123,
    Cost: 0.1846,
  },
  {
    metric: "Fluency_score",
    tag: "Flu...",
    Latency: 245,
    Token: 12333,
    Cost: 0.226135,
  },
  {
    metric: "Spelling_score",
    tag: "Spe...",
    Latency: 120,
    Token: 14678,
    Cost: 0.11076,
  },
  {
    metric: "Grammar_score",
    tag: "Gra...",
    Latency: 196,
    Token: 14001,
    Cost: 0.180908,
  },
  {
    metric: "Relevance check (Competency & Question)",
    tag: "Rel...",
    Latency: 298,
    Token: 21092,
    Cost: 0.275054,
  },
  {
    metric: "Relevance check (JD Context & Question)",
    tag: "Rel...",
    Latency: 102,
    Token: 12067,
    Cost: 0.094146,
  },
  {
    metric: "Relevance check (JD Competency & Question)",
    tag: "Rel...",
    Latency: 198,
    Token: 14652,
    Cost: 0.182754,
  }
];


const colors = ["#4c51bf", "#14b8a6", "#f43f5e"];

const options = [
  { value: "Latency", label: "Latency" },
  { value: "Token", label: "Token" },
  { value: "Cost", label: "Cost" },
];

const customStyles = {
  control: (provided) => ({
    ...provided,
    width: 250,
  }),
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{opacity: 0.8, backgroundColor: "white", padding: " 0 0.5rem", borderRadius: "0.5rem"}}>
        <p className="label">{`${payload[0].payload.metric}`}</p>
        {payload.map(item => <p className="label">{item.name} : {item.value}</p> )}
      </div>
    );
  }
  return null;
};

const CustomBarChart = (props) => {
  const [selectedOptions, setSelectedOptions] = useState([]);

  const data = Object.keys(props.data).map(metric => ({
    metric: metric,
    tag: metric.substring(0,3)+"...",
    Latency: props.data[metric].latency,
    Token: props.data[metric].token,
    Cost: props.data[metric].cost,
  }))

  const handleChange = (selected) => {
    setSelectedOptions(selected);
  };

  return (
    <>
      <Stack direction={"row"} justifyContent={"flex-end"}>
        <Select
          value={selectedOptions}
          onChange={handleChange}
          options={options}
          isMulti
          styles={customStyles}
        />
      </Stack>
      <ResponsiveContainer width="100%" height={500}>
        <BarChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="tag" markerEnd="100" height={100}
          tickMargin={20} allowDataOverflow />
          <YAxis />
          <Tooltip content={<CustomTooltip/>} />
          <Legend />
          {selectedOptions.find((item) => item.value === "Latency") && (
            <Bar dataKey="Latency" fill={colors[0]} />
          )}
          {selectedOptions.find((item) => item.value === "Token") && (
            <Bar dataKey="Token" fill={colors[1]} />
          )}
          {selectedOptions.find((item) => item.value === "Cost") && (
            <Bar dataKey="Cost" fill={colors[2]} />
          )}
        </BarChart>
      </ResponsiveContainer>
    </>
  );
};

export default CustomBarChart;
