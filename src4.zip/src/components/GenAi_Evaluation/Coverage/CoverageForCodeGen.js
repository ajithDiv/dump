import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { useState } from "react";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const CoverageForCodeGen = (props) => {
  const coverageDetails = [
    {
      Topic: "Code Refactoring",
      percentage: 80,
      subtopics: {
        "Code conciseness": 20,
        "Conditional logic refactoring": 0,
        "Duplicate code removal": 50,
        Modularization: 10,
        "Readability & maintainability improvements": 0,
      },
    },
    {
      Topic: "Documentation & Explanation",
      percentage: 10,
      subtopics: {
        "Code summarization": 10,
        "Docstring & documentation generation": 0,
        "Inline comments generation": 0,
        "Legacy code explanation": 0,
      },
    },
    {
      Topic: "Language & Prompt Understanding",
      percentage: 10,
      subtopics: { "Natural language and context awareness": 10 },
    },
  ];
  const [accordianStatus, setAccordianStatus] = useState(
    coverageDetails.map((it) => true)
  );

  return (
    <div>
      {coverageDetails.length > 0 && (
        <Stack direction="row-reverse">
          <Button
            style={{ margin: "1rem 0" }}
            variant="contained"
            onClick={() => setAccordianStatus((prev) => prev.map((it) => true))}
          >
            Expand All
          </Button>
        </Stack>
      )}

      {/* {props.loading === true && (
        <Stack width="100%" direction="row" justifyContent="center">
          <CircularProgress />
        </Stack>
      )} */}

      {coverageDetails.map((row, index) => {
        return (
          <Accordion
            expanded={accordianStatus[index]}
            onChange={() =>
              setAccordianStatus((prev) => {
                let temp = [...prev];
                temp[index] = !temp[index];
                return temp;
              })
            }
            defaultExpanded={true}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1-content"
              id="panel1-header"
            >
              <Typography fontWeight={500}>Traceback {index + 1}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer sx={{ marginTop: "0px" }} component={Paper}>
                <Table aria-label="Material-UI Table">
                  <TableHead sx={{ background: "#78ABB6", color: "#fff" }}>
                    <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                      {coverageDetails &&
                        coverageDetails.length > 0 &&
                        Object.keys(coverageDetails[0]).map(
                          (row, index) => {
                            return (
                              <TableCell
                                sx={{
                                  width: index === 2 ? "40%" :"30%",
                                  padding: "0.5rem",
                                  color: "#fff",
                                  textAlign: "center",
                                  borderRight: "1px solid gray",
                                }}
                                key={index}
                              >
                                <strong>{row.toUpperCase()}</strong>
                              </TableCell>
                            );
                          }
                        )}
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#EEF4F9" }
                          : { background: "#EEF4F9" }
                      }
                    >
                      {coverageDetails &&
                        coverageDetails.length > 0 &&
                        Object.keys(coverageDetails[0]).map(
                          (cell, index) => {
                            return (
                              <TableCell
                                sx={{
                                  width: index === 2 ? "40%" : "30%",
                                  padding: index === 2 ? "0 1rem" : "0.5rem",
                                  color: "black",
                                  textAlign: "center",
                                  borderRight: "1px solid gray",
                                }}
                                key={index}
                              >
                                {typeof row[cell] === "object" ? (
                                  Object.keys(row[cell]).map((item, idx) => {
                                    return (
                                      <div
                                        style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          alignItems: "center",
                                        }}
                                      >
                                        <p>
                                          {item
                                            .split("_")
                                            .join(" ")
                                            .toUpperCase()}{" "}
                                          :{" "}
                                        </p>
                                        <strong style={{ fontSize: "1.5em" }}>
                                          {row[cell][item]} %
                                        </strong>
                                      </div>
                                    );
                                  })
                                ) : index === 1 ? (
                                  <strong style={{ fontSize: "1.5em" }}>
                                    {row[cell]} %
                                  </strong>
                                ) : (
                                  row[cell].split("_").join(" ").toUpperCase()
                                )}
                              </TableCell>
                            );
                          }
                        )}
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
              <br />
            </AccordionDetails>
          </Accordion>
        );
      })}
    </div>
  );
};

export default CoverageForCodeGen;
