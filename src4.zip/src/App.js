import "./App.css";
import React, { Component } from "react";
import { userService } from "./_services/user.service";
import { Modal, ModalBody, ModalFooter, ModalHeader, Button } from "reactstrap";
import {
  RouterProvider,
  createBrowserRouter,
  redirect,
} from "react-router-dom/dist";
import Layout from "./globals/Layout";
import Overview from "./pages/Overview";
import Dataset from "./pages/DatasetModule/Dataset/Dataset";
import DatasetDetails from "./pages/DatasetModule/DatasetDetails/DatasetDetails";
import DatasetPrompts from "./pages/DatasetModule/DatasetPrompts/DatasetPrompts";
import Dashboard from "./pages/Dashboard/Dashboard";
import Evaluate from "./pages/GenAi_Evaluation/Evaluate";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CreateConfiguration from "./pages/GenAi_Evaluation/CreateConfiguration/CreateConfiguration";
import RunConfiguration from "./pages/GenAi_Evaluation/RunConfiguration/RunConfiguration";
import EvaluationSummary from "./pages/GenAi_Evaluation/EvaluationSummary/EvaluationSummary";
import EvaluationDetails from "./pages/GenAi_Evaluation/EvaluationDetails/EvaluationDetails";
import Model from "./pages/Model/Model";
import SumEvaluationDetails from "./pages/GenAi_Evaluation/EvaluationDetails/SumEvaluationDetails";
import MetricDetail from "./pages/GenAi_Evaluation/EvaluationDetails/MetricDetail";
import { LoadingProvider } from "./_context/LoadingContext";
import GlobalLoader from "./components/GloabalLoader";

// Pages
const Register = React.lazy(() => import("./pages/Register"));
const Page404 = React.lazy(() => import("./pages/Page404"));
const Page500 = React.lazy(() => import("./pages/Page500"));
const Login = React.lazy(() => import("./pages/Login"));

const theme = createTheme({
  palette: {
    primary: {
      main: "#4546D9",
    },
  },
});

const router = createBrowserRouter([
  {
    path: "/login",
    // errorElement: <ErrorPage />,
    element: <Login />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/404",
    element: <Page404 />,
  },
  {
    path: "/500",
    element: <Page500 />,
  },
  {
    path: "/",
    loader: () => {
      return redirect("/genai-assurance/genai_dataset");
    },
  },
  {
    path: "/genai-assurance",
    element: <Layout />,
    children: [
      {
        path: "",
        loader: () => {
          return redirect("genai_dataset");
        },
      },
      {
        path: "overview",
        element: <Overview />,
      },
      {
        path: "genai_dataset",
        element: <Dataset />,
      },
      {
        path: "genai_dashboard",
        element: <Dashboard />,
      },
      {
        path: "genai_dataset/:id",
        element: <DatasetDetails />,
      },
      {
        path: "genai_dataset/:id/prompts",
        element: <DatasetPrompts />,
      },
      {
        path: "genai_evaluate",
        element: <Evaluate />,
      },
      {
        path: "genai_evaluate/configuration",
        element: <CreateConfiguration />,
      },
      {
        path: "genai_evaluate/configuration/:id",
        element: <CreateConfiguration />,
      },
      {
        path: "genai_evaluate/runConfiguration/:id",
        element: <RunConfiguration />,
      },
      {
        path: "genai_evaluate/evaluation_summary/:id",
        element: <EvaluationSummary />,
      },
      {
        path: "genai_evaluate/evaluation_summary/:id/details/:subId",
        element: <EvaluationDetails />,
      },
      {
        path: "genai_evaluate/evaluation_summary/:id/sum-details/:subId",
        element: <SumEvaluationDetails />,
      },
      {
        path: "genai_evaluate/evaluation_summary/:id/sum-details/:subId/metric-details",
        element: <MetricDetail />,
      },
      {
        path: "genai_model",
        element: <Model />,
      },
    ],
  },
  {
    path: "/*",
    element: <Page404 />,
  },
]);

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { logginStatus: true, sessionTimeOutModal: false };
    this.events = [
      "load",
      "mousemove",
      "mousedown",
      "click",
      "scroll",
      "keypress",
    ];
    this.warn = this.warn.bind(this);
    this.logout = this.logout.bind(this);
    this.resetTimeout = this.resetTimeout.bind(this);
    this.clearTimeoutFunction = this.clearTimeoutFunction.bind(this);
    this.toggleSessionTimeOutModal = this.toggleSessionTimeOutModal.bind(this);
  }

  componentDidMount() {
    if (!window.location.pathname.includes("/login")) {
      this.events.forEach((event) =>
        window.addEventListener(event, this.resetTimeout)
      );
    }
  }

  componentWillUnmount() {
    if (!window.location.pathname.includes("/login")) {
      this.events.forEach((event) =>
        window.removeEventListener(event, this.resetTimeout)
      );
    }
  }

  clearTimeoutFunction() {
    if (this.warnTimeout) {
      clearTimeout(this.warnTimeout);
    }

    if (this.logoutTimeout) {
      clearTimeout(this.logoutTimeout);
    }
  }

  resetTimeout() {
    this.clearTimeoutFunction();
    // this.setTimeoutFunction();
  }

  toggleSessionTimeOutModal() {
    this.setState((prevState) => ({
      sessionTimeOutModal: !prevState.sessionTimeOutModal,
    }));
  }

  warn() {
    if (!window.location.pathname.includes("/login")) {
      this.toggleSessionTimeOutModal();
    } else {
      this.resetTimeout();
    }
  }

  confirmReset() {
    this.setState({
      sessionTimeOutModal: false,
    });
    userService.generateToken().then(
      (data) => {
        this.resetTimeout();
      },
      (error) => {
        this.props.history.push("/login");
      }
    );
  }

  logout() {
    this.setState({
      sessionTimeOutModal: false,
    });
    if (!window.location.pathname.includes("/login")) {
      localStorage.removeItem("user");
      localStorage.setItem(
        "sessionExpire",
        "Session is expired. Please login again."
      );
      this.setState({ logginStatus: false });
    }
    this.resetTimeout();
  }

  render() {
    return (
      <div>
        <ThemeProvider theme={theme}>
          <LoadingProvider>
            <GlobalLoader />
            <RouterProvider router={router}></RouterProvider>
          </LoadingProvider>
          <Modal
            isOpen={this.state.sessionTimeOutModal}
            toggle={this.toggleSessionTimeOutModal}
            className="modal-warning"
          >
            <ModalHeader toggle={this.toggleSessionTimeOutModal}>
              Session Timeout Warning
            </ModalHeader>
            <ModalBody>
              Your session is going to be expired soon. Do you wish to continue
              here?
            </ModalBody>
            <ModalFooter>
              <Button color="secondary" onClick={this.confirmReset}>
                Yes
              </Button>{" "}
              <Button color="danger" onClick={this.logout}>
                No
              </Button>
            </ModalFooter>
          </Modal>
        </ThemeProvider>
      </div>
    );
  }
}

export default App;
