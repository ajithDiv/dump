// src/api/axiosInstance.js

import axios from 'axios';

import { showLoader, hideLoader } from '../_services/loadingService';

let activeRequests = 0;

const api = axios.create({

    baseURL: `http://10.120.100.84:5000`, // Replace with your actual base URL

});

api.interceptors.request.use((config) => {
    alert("asas")
    activeRequests++;

    showLoader();

    return config;

});

api.interceptors.response.use(

    (response) => {

        activeRequests--;

        if (activeRequests === 0) hideLoader();

        return response;

    },

    (error) => {

        activeRequests--;

        if (activeRequests === 0) hideLoader();

        return Promise.reject(error);

    }

);

export default api;
