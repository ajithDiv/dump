import React, { useEffect, useState } from "react";
import {
    MenuItem,
    Select,
    InputLabel,
    FormControl,
    OutlinedInput,
    Checkbox,
    ListItemText,
    Box,
    Grid,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow
} from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";
import ChartComponent from "./ChartComponent";
import MetricsTable from "./MetricsTable";
import mockData from './mockData.json'
// import data from "./data.json"; // your sample JSON placed here

const OverallDashboard = ({ data }) => {
    const [datasets, setDatasets] = useState([]);
    const [selectedDataset, setSelectedDataset] = useState("");
    const [configs, setConfigs] = useState([]);
    const [selectedConfig, setSelectedConfig] = useState("");
    const [runs, setRuns] = useState([]);
    const [selectedRuns, setSelectedRuns] = useState([]);
    const [metrics, setMetrics] = useState([]);
    const [selectedMetrics, setSelectedMetrics] = useState([]);

    const [isExpanded, setIsExpanded] = useState(false);
    // const runs = Object.keys(mockData[0]).filter(k => k !== 'Metric Name');
    const colorMap = runs.reduce((acc, run, index) => {
        acc[run] = `hsl(${index * 50}, 70%, 50%)`;
        return acc;
    }, {});
    // Load initial datasets
    useEffect(() => {
        const uniqueDatasets = [...new Set(data.map((d) => d.datasetName))];
        setDatasets(uniqueDatasets);
    }, []);

    // Update configs when dataset changes
    useEffect(() => {
        const filteredConfigs = data
            .filter((d) => d.datasetName === selectedDataset)
            .map((d) => d.configurationName);
        setConfigs([...new Set(filteredConfigs)]);
        setSelectedConfig("");
        setSelectedRuns([]);
        setSelectedMetrics([]);
    }, [selectedDataset]);

    // Update runs when config changes
    useEffect(() => {
        const filteredRuns = data.filter(
            (d) =>
                d.datasetName === selectedDataset &&
                d.configurationName === selectedConfig
        );
        const names = filteredRuns.map((d) => d.run_name).filter(Boolean);
        setRuns(names);
        setSelectedRuns([]);
        setSelectedMetrics([]);
    }, [selectedConfig]);

    // Update metrics when run selection changes
    useEffect(() => {
        const selectedRunObjs = data.filter(
            (d, i) =>
                d.datasetName === selectedDataset &&
                d.configurationName === selectedConfig &&
                (selectedRuns.includes(d.run_name) || selectedRuns.includes(`Run-${i + 1}`))
        );
        const allMetrics = new Set();
        selectedRunObjs.forEach((run) => {
            run.evaluation_metrics_status?.forEach((m) => allMetrics.add(m.metric));
        });
        setMetrics([...allMetrics]);
    }, [selectedRuns]);

    // Get Graph data per run
    const getChartDataForRun = () => {

        const output = [];
        selectedRuns.forEach(run => {
            const entry = { runName: run };
            const record = data.find(d => d.run_name === run);
            if (record) {
                selectedMetrics.forEach(metric => {
                    const m = record.evaluation_metrics_status.find(
                        item => item.metric === metric
                    );
                    if (m) {
                        entry[metric] = m["ActualValue"]
                    }
                });
            }
            output.push(entry);
        });
        return output;



    };

    // Table Rows
    const tableRows = selectedMetrics.map((metric) => {
        const row = {
            metric,
            threshold: ""
        };

        selectedRuns.forEach((runLabel) => {
            const index = runs.indexOf(runLabel);
            const record = data.find(
                (_, i) =>
                    _.datasetName === selectedDataset &&
                    _.configurationName === selectedConfig &&
                    _.run_name?.trim().toLowerCase() === runLabel.trim().toLowerCase()
            );

            const thresholdObj = record?.evaluation_metrics_threshold_status?.find(
                (m) => m.metric === metric
            );

            if (!row.threshold && thresholdObj?.ThresholdValue !== undefined) {
                row.threshold = thresholdObj.ThresholdValue;
            }

            row[runLabel] =
                thresholdObj?.ActualValue !== undefined
                    ? `${(thresholdObj.TotalPassed || 0).toFixed(1)}%`
                    : "-";
        });

        return row;
    });

    return (
        <Box p={3}>
            <Grid container spacing={2}>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Dataset</InputLabel>
                        <Select
                            value={selectedDataset}
                            onChange={(e) => setSelectedDataset(e.target.value)}
                            label="Dataset"
                        >
                            {datasets.map((ds) => (
                                <MenuItem key={ds} value={ds}>
                                    {ds}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Configuration</InputLabel>
                        <Select
                            value={selectedConfig}
                            onChange={(e) => setSelectedConfig(e.target.value)}
                            label="Configuration"
                            disabled={!selectedDataset}
                        >
                            {configs.map((cfg) => (
                                <MenuItem key={cfg} value={cfg}>
                                    {cfg}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Run Name</InputLabel>
                        <Select
                            multiple
                            value={selectedRuns}
                            onChange={(e) => setSelectedRuns(e.target.value)}
                            input={<OutlinedInput label="Run Name" />}
                            renderValue={(selected) => selected.join(", ")}
                            disabled={!selectedConfig}
                        >
                            {runs.map((run) => (
                                <MenuItem key={run} value={run}>
                                    <Checkbox checked={selectedRuns.indexOf(run) > -1} />
                                    <ListItemText primary={run} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Metrics</InputLabel>
                        <Select
                            multiple
                            value={selectedMetrics}
                            onChange={(e) => setSelectedMetrics(e.target.value)}
                            input={<OutlinedInput label="Metrics" />}
                            renderValue={(selected) => selected.join(", ")}
                            disabled={selectedRuns.length === 0}
                        >
                            {metrics.map((metric) => (
                                <MenuItem key={metric} value={metric}>
                                    <Checkbox checked={selectedMetrics.indexOf(metric) > -1} />
                                    <ListItemText primary={metric} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>

            <Box>
                <div className="main-layout">
                    {/* Left: Chart */}
                    <div className="chart-area">
                        <div className="chart-header">
                            <h3>Run/Metrics Overview</h3>
                        </div>
                        <ChartComponent data={getChartDataForRun()} selectedMetrics={selectedMetrics} />
                    </div>


                    <div
                        className={`table-panel ${isExpanded ? 'expanded' : 'collapsed'}`}
                    >
                        <div className="table-head">
                            <div className="toggle-btn" onClick={() => setIsExpanded(!isExpanded)}>
                                {isExpanded ? '››' : '‹‹'}
                            </div>
                            <h3>Table View</h3>
                        </div>
                        <MetricsTable data={mockData} runs={runs} colorMap={colorMap} isExpanded={isExpanded} />
                    </div>
                </div>
            </Box>
        </Box>
    );
};

export default OverallDashboard;