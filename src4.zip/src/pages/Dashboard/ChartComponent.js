import React from 'react';

import {

    LineChart, Line, XAxis, YAxis, CartesianGrid,

    Tooltip, Legend, ResponsiveContainer

} from 'recharts';

const ChartComponent = ({ data, selectedMetrics }) => {
    console.log(data, 'grapgh.......')
    return (
        <div style={{ width: '99%', height: 380 }}>
            <ResponsiveContainer width="100%" height={350}>
                <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="runName" label={{ value: 'Run Name', position: 'insideBottom', offset: -5 }} />
                    <YAxis label={{ value: 'Executions', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: '12px', top: 0, right: 0 }} />
                    {selectedMetrics.map((metric, index) => (
                        <Line
                            key={metric}
                            type="monotone"
                            dataKey={metric}
                            stroke={`hsl(${index * 60}, 70%, 50%)`}
                            strokeWidth={2}
                            dot={{ r: 3 }}
                        />
                    ))}
                </LineChart>
            </ResponsiveContainer>
        </div>

    );

};

export default ChartComponent;
