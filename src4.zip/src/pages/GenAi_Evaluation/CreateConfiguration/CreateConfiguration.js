import {
  Autocomplete,
  Box,
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  IconButton,
  InputBase,
  InputLabel,
  ListItemText,
  MenuItem,
  Modal,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Slide,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { alpha, styled } from "@mui/material/styles";
import Switch, { SwitchProps } from "@mui/material/Switch";
import optionIcon from "../../../assets/genaiIcons/more_vert.png";
import Slider from "@mui/material/Slider";
import MuiInput from "@mui/material/Input";
import React, { useContext, useEffect, useRef, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import CloseIcon from "@mui/icons-material/Close";
import starIcon from "../../../assets/genaiIcons/star.png";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import AddBoxOutlinedIcon from "@mui/icons-material/AddBoxOutlined";

import styles from "./CreateConfiguration.module.css";
import {
  createConfiguration,
  getAllMetrices,
  getAllMetricesById,
  updateConfiguration,
} from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import { useNavigate, useParams } from "react-router-dom";
import { AddCircleOutline } from "@mui/icons-material";
import Confirmation from "../../../components/Confirmation/Confirmation";
import PromptTemplate from "./PromptTemplate";
import CustomMetric from "./CustomMetric";

const Android12Switch = styled(Switch)(({ theme }) => ({
  padding: 8,
  // '& .MuiSwitch-switchBase.Mui-checked': {
  //   color: "#0FC7C7",
  //   '&:hover': {
  //     backgroundColor: alpha("#0FC7C7", theme.palette.action.hoverOpacity),
  //   },
  // },
  "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
    backgroundColor: "#0FC7C7",
  },
  "& .MuiSwitch-track": {
    boxShadow: "-1px -1px 2px 0px #000000A6 inset",
    borderRadius: 22 / 2,
    "&::before, &::after": {
      content: '""',
      position: "absolute",
      top: "50%",
      transform: "translateY(-50%)",
      width: 16,
      height: 16,
      // color: "#0FC7C7",
      // backgroundColor: "#0FC7C7",
    },
    "&::before": {
      // backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
      //   /*theme.palette.getContrastText(theme.palette.primary.main)*/ "#0FC7C7",
      // )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      left: 12,
      // backgroundColor: "#0FC7C7",
    },
    "&::after": {
      // backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
      //   /*theme.palette.getContrastText(theme.palette.primary.main)*/ "#0FC7C7",
      // )}" d="M19,13H5V11H19V13Z" /></svg>')`,
      right: 12,
      // backgroundColor: "#0FC7C7",
    },
  },
  "& .MuiSwitch-thumb": {
    // boxShadow: 'none',
    width: 16,
    height: 16,
    margin: 2,
    backgroundColor: "#0FC7C7",
    boxShadow: "2px 2px 3px 0px #00000040 inset",
  },
}));

const Input = styled(TextField)`
  width: 3rem;
`;

//   styled(MuiInput)`
//   width: 42px;
// `;

const GradientSlider = styled(Slider)({
  "& .MuiSlider-track": {
    background:
      "linear-gradient(90.01deg, #F96747 1.52%, #9100EA 91.23%, #0FC7C7 184.61%)",
    border: "none",
  },
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const INTIAL_CUSTOM_METRIC_DATA = {
  name: "",
  value: "",
  description: "",
  level: "1",
  prompts: [],
  enabled: false,
  conditions: [],
};

const piiValues = [
  "CREDIT_CARD",
  "CRYPTO",
  "DATE_TIME",
  "EMAIL_ADDRESS",
  "IBAN_CODE",
  "IP_ADDRESS",
  "NRP",
  "LOCATION",
  "PERSON",
  "PHONE_NUMBER",
  "MEDICAL_LICENSE",
  "URL",
];

const CreateConfiguration = () => {
  const ctx = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [isEdit, setIsEdit] = useState(false);
  const [configurationName, setConfigurationName] = useState("");
  const [configurationDescription, setConfigurationDescription] = useState("");
  const [metrices, setMetrices] = useState([]);
  const [value, setValue] = React.useState(10);
  const [selectedGroupIndex, setSelectedGroupIndex] = useState(-1);
  const [searchMetrice, setSearchMetrice] = useState("");
  const [open, setOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [jailBreakModal, setJailBreakModal] = useState(false);
  const [templateCount, setTemplateCount] = useState(5);
  const [selectedPiiValues, setSelectedPiiValues] = useState([]);
  const [useCase, setUseCase] = useState("");
  const [redTeamModal, setRedTeamModal] = useState(false);
  const [piiModal, setPiiModal] = useState(false);
  const [testcase, setTestcase] = useState("");
  const [additionalContext, setAdditionalContext] = useState("");
  const [adversialModal, setAdversialModal] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [customMetricData, setCustomMetricData] = useState(
    INTIAL_CUSTOM_METRIC_DATA
  );
  const [coverageModal, setCoverageModal] = useState(false);
  const [topics, setTopics] = useState([]);
  // const [topicsText, setTopicsText] = useState({
  //   topic: "",
  //   subTopic: "",
  //   subSubTopic: "",
  // });
  const [selectedTopic, setSelectedTopic] = useState({
    topic: "",
    subTopic: "",
  });
  const [level, setLevel] = useState(2);
  const [displayTopics, setDisplayTopics] = useState([
    { topic: "", subTopic: "", subSubTopic: "" },
  ]);
  const [hoverTopic, setHoverTopic] = useState(-1);

  const navigate = useNavigate();
  const params = useParams();

  const toggleDelete = () => {
    setConfirmDelete((prev) => !prev);
  };

  const openCustomMetricModal = (data) => {
    setCustomMetricData({ ...data });
    setOpen(true);
  };

  const closeCustomMetricModal = () => {
    setOpen(false);
  };

  const handleChangeConfigurationName = (event) => {
    setConfigurationName(event.target.value);
  };

  const handleChangeConfigurationDescription = (event) => {
    setConfigurationDescription(event.target.value);
  };

  const handleChangeSelectedGroupIndex = (groupIndex) => {
    setSelectedGroupIndex(groupIndex);
  };

  const handleChangeSearchMetrice = (event) => {
    setSearchMetrice(event.target.value);
  };

  const handleInverseChange = (event, groupIndex, index) => {
    setMetrices((prev) => {
      let copy = [...prev];
      copy[groupIndex].metrices[index].inverse = event.target.checked;
      return copy;
    });
  };

  const handleSliderChange = (event, groupIndex, index) => {
    setMetrices((prev) => {
      let copy = [...prev];
      copy[groupIndex].metrices[index].thresholdValue = +event.target.value;
      return copy;
    });
  };

  const handleSwitchChange = (event, groupIndex, index) => {
    setMetrices((prev) => {
      let copy = [...prev];
      copy[groupIndex].metrices[index].enabled = event.target.checked;
      return copy;
    });
  };

  const handleSubmit = () => {
    metrices.map((item) => {
      item.metrices.map((metric) => {
        if (metric.name === "Jailbreak") {
          metric["usecase"] = useCase;
          metric["noOfTemplates"] = templateCount;
        } else if (metric.name === "Adversarial Attack") {
          metric["prompt"] = prompt;
        } else if (metric.name === "Red Teaming") {
          metric["additional_context"] = additionalContext;
          metric["testcase"] = testcase;
        } else if (metric.name === "Coverage") {
          metric["coverage_topics"] = {level: level, data: topics}
        }
      });
    });
    const data = {
      name: configurationName,
      description: configurationDescription,
      metrices_data: metrices,
      createdBy: ctx.username,
      projectName: ctx.projectName,
    };
    const updateData = {
      metrices_data: metrices,
    }
    console.log(data);
    if (params["id"]) {
      updateConfiguration(updateData, params["id"]).then((result) => {
        toggleDelete();
        navigate("/genai-assurance/genai_evaluate");
      });
    } else {
      createConfiguration(data).then((result) => {
        toggleDelete();
        navigate("/genai-assurance/genai_evaluate");
      });
    }
  };

  const handleInputChange = (event) => {
    setValue(event.target.value === "" ? 0 : Number(event.target.value));
  };

  const handleBlur = () => {
    if (value < 0) {
      setValue(0);
    } else if (value > 10) {
      setValue(10);
    }
  };

  useEffect(() => {
    if (params["id"]) {
      getAllMetricesById(params["id"]).then((result) => {
        setMetrices(result[0].metrices_data);
        setConfigurationName(result[0].name);
        setConfigurationDescription(result[0].desc);
        setIsEdit(true);
        setLoading(false);
      });
    } else {
      getAllMetrices(ctx.projectSubType).then((result, error) => {
        console.log(JSON.parse(result.metrics));
        setMetrices(JSON.parse(result.metrics));
        setLoading(false);
      });
    }
  }, []);

  return (
    <div style={{ margin: "1rem" }}>
      <Stack alignItems="flex-start" gap="1rem">
        <Stack direction="row" alignItems="center" spacing={2}>
          <FormLabel sx={{ width: "15rem" }}>Configuration Name </FormLabel>
          <FormLabel>:</FormLabel>
          <FormControl sx={{ m: 1, minWidth: 300 }}>
            <TextField
              id="outlined-basic"
              variant="outlined"
              value={configurationName}
              onChange={handleChangeConfigurationName}
            />
          </FormControl>
        </Stack>
        <Stack direction="row" alignItems="center" spacing={2}>
          <FormLabel sx={{ width: "15rem" }}>
            Configuration Description{" "}
          </FormLabel>
          <FormLabel>:</FormLabel>
          <FormControl sx={{ m: 1, minWidth: 300, maxWidth: 500 }}>
            <TextField
              id="outlined-basic"
              variant="outlined"
              value={configurationDescription}
              onChange={handleChangeConfigurationDescription}
              multiline
              minRows={2}
            />
          </FormControl>
        </Stack>

        <FormLabel>
          <Stack direction="row" alignItems="baseline">
            <Typography fontWeight={700}>Metrices &nbsp;</Typography>
            <Typography fontSize="10px" fontWeight="500" fontStyle={"italic"}>
              ( <img src={starIcon} width="10px" alt="star" /> &nbsp;
            </Typography>
            <Typography fontSize="10px" fontWeight="500" fontStyle={"italic"}>
              - LLM as Judge Metrices)
            </Typography>
          </Stack>
        </FormLabel>
        <Stack
          direction={"row"}
          flexWrap="wrap"
          justifyContent="space-between"
          alignItems="center"
          width="100%"
        >
          <Stack direction={"row"} width="60%" flexWrap="wrap" gap={"0.25rem"}>
            <Chip
              style={{ fontSize: "12px", fontWeight: "600" }}
              clickable
              onClick={() => handleChangeSelectedGroupIndex(-1)}
              label={
                " All " +
                "(" +
                metrices.reduce(
                  (prev, item) => prev + item.metrices.length,
                  0
                ) +
                ")"
              }
              variant="outlined"
              color={-1 === selectedGroupIndex ? "primary" : "default"}
            />
            {metrices.map((metricGroup, groupIndex) => (
              <Chip
                style={{ fontSize: "12px", fontWeight: "600" }}
                clickable
                onClick={() => handleChangeSelectedGroupIndex(groupIndex)}
                label={
                  (metricGroup.name === "Trustworthy Assurance"
                    ? "Trustworthy"
                    : metricGroup.name) +
                  "(" +
                  metricGroup.metrices.length +
                  ")"
                }
                variant="outlined"
                color={
                  groupIndex === selectedGroupIndex ? "primary" : "default"
                }
              />
            ))}
          </Stack>
          <Stack
            direction="row"
            width="35%"
            justifyContent="flex-end"
            gap="0.5rem"
          >
            <Paper
              component="form"
              sx={{
                display: "flex",
                alignItems: "center",
                width: 175,
              }}
            >
              <IconButton sx={{ p: "5px" }} aria-label="menu">
                <SearchIcon />
              </IconButton>
              <InputBase
                sx={{ ml: 1, flex: 1 }}
                placeholder="Search Metrices"
                value={searchMetrice}
                onChange={handleChangeSearchMetrice}
                //   inputProps={{ "aria-label": "search google maps" }}
              />
            </Paper>
            <Button
              variant="contained"
              onClick={() => {
                setCustomMetricData(INTIAL_CUSTOM_METRIC_DATA);
                setOpen(true);
              }}
            >
              Custom Metric
            </Button>
          </Stack>
        </Stack>

        <Stack direction="row" width={"100%"} flexWrap={"wrap"} gap="1rem">
          {loading === true && (
            <Stack width="100%" direction="row" justifyContent="center">
              <CircularProgress />
            </Stack>
          )}
          {loading === false &&
            metrices.map((metricGroup, groupIndex) =>
              metricGroup.metrices.map(
                (item, index) =>
                  (selectedGroupIndex === -1 ||
                    selectedGroupIndex === groupIndex) &&
                  (searchMetrice === "" ||
                    item.name
                      .toLowerCase()
                      .includes(searchMetrice.toLowerCase())) && (
                    <Paper
                      style={{
                        position: "relative",
                        backgroundColor: item.enabled ? "" : "#f0f0f0",
                        overflow: "hidden",
                      }}
                      className={styles.metriceBox}
                    >
                      {Object.keys(item).indexOf("tag") > -1 && (
                        <div
                          style={{
                            fontSize: "8px",
                            fontWeight: "bold",
                            backgroundColor: "#0fc7c7",
                            position: "absolute",
                            width: "5rem",
                            rotate: "-45deg",
                            translate: "-40%",
                            paddingLeft: "2rem",
                            // textAlign: "center",
                          }}
                        >
                          {/* {item.tag} */}
                          {item.tag.length < 6 ? (
                            <>&nbsp; {item.tag}</>
                          ) : (
                            item.tag
                          )}
                        </div>
                      )}
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        marginLeft={
                          Object.keys(item).indexOf("tag") > -1 ? "1rem" : "0"
                        }
                      >
                        <Stack direction="row" alignItems="center">
                          {/* Updated 1 week ago */}
                          {item["Is LLM"] && (
                            <img src={starIcon} width="12px" alt="star" />
                          )}
                          <Chip
                            style={{
                              marginLeft: "0.5rem",
                              border: "1px solid #0fc7c7",
                              color: "#0fc7c7",
                              fontSize: "0.5rem",
                              fontWeight: "500",
                              height: "1rem",
                            }}
                            label={
                              metricGroup.name.length > 25
                                ? metricGroup.name.substr(0, 25) + "..."
                                : metricGroup.name
                            }
                            size="small"
                            variant="outlined"
                          />
                        </Stack>
                        <Stack
                          direction="row"
                          justifyContent="flex-end"
                          gap={0}
                          alignItems="center"
                        >
                          <FormControlLabel
                            style={{ margin: 0 }}
                            className={styles.switchBox}
                            control={
                              <Android12Switch
                                checked={item.enabled}
                                value={item.enabled}
                                onChange={(e) =>
                                  handleSwitchChange(
                                    e,
                                    selectedGroupIndex === -1
                                      ? groupIndex
                                      : selectedGroupIndex,
                                    index
                                  )
                                }
                              />
                            }
                          />
                          <img
                            className={styles.optionsContainer}
                            src={optionIcon}
                            alt="Options"
                          />
                        </Stack>
                      </Stack>
                      <Stack
                        style={
                          metricGroup.name === "Custom Metrices" ||
                          [
                            "PII detection",
                            "Jailbreak",
                            "Adversarial Attack",
                            "Red Teaming",
                          ].indexOf(item.name) > -1
                            ? { cursor: "pointer" }
                            : null
                        }
                        onClick={
                          metricGroup.name === "Custom Metrices"
                            ? () => openCustomMetricModal(item)
                            : [
                                "PII detection",
                                "Jailbreak",
                                "Adversarial Attack",
                                "Red Teaming",
                              ].indexOf(item.name) > -1
                            ? () => {
                                if (item.name === "Red Teaming")
                                  setRedTeamModal(true);
                                else if (item.name === "Adversarial Attack")
                                  setAdversialModal(true);
                                else if (item.name === "PII detection")
                                  setPiiModal(true);
                                else setJailBreakModal(true);
                              }
                            : null
                        }
                        className={styles.heading}
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                      >
                        {item.name.length > 20 ? (
                          <Tooltip title={item.name}>
                            {item.name.substr(0, 20) + "..."}
                          </Tooltip>
                        ) : (
                          item.name
                        )}

                        {item.name === "Coverage" && (
                          <Tooltip title="Configure Topics">
                            <IconButton
                              style={{ padding: 0 }}
                              size="small"
                              onClick={() => setCoverageModal(true)}
                            >
                              <AccountTreeIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Stack>

                      <Stack
                        style={
                          metricGroup.name === "Custom Metrices" ||
                          [
                            "PII detection",
                            "Jailbreak",
                            "Adversarial Attack",
                            "Red Teaming",
                          ].indexOf(item.name) > -1
                            ? { cursor: "pointer" }
                            : null
                        }
                        onClick={
                          metricGroup.name === "Custom Metrices"
                            ? () => openCustomMetricModal(item)
                            : [
                                "PII detection",
                                "Jailbreak",
                                "Adversarial Attack",
                                "Red Teaming",
                              ].indexOf(item.name) > -1
                            ? () => {
                                if (item.name === "Red Teaming")
                                  setRedTeamModal(true);
                                else if (item.name === "Adversarial Attack")
                                  setAdversialModal(true);
                                else if (item.name === "PII detection")
                                  setPiiModal(true);
                                else setJailBreakModal(true);
                              }
                            : null
                        }
                        className={styles.description}
                      >
                        {item.description.length > 100 ? (
                          <Tooltip title={item.description}>
                            {item.description.substr(0, 100) + "..."}
                          </Tooltip>
                        ) : (
                          item.description
                        )}
                      </Stack>
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={item.inverse}
                            onChange={(e) =>
                              handleInverseChange(
                                e,
                                selectedGroupIndex === -1
                                  ? groupIndex
                                  : selectedGroupIndex,
                                index
                              )
                            }
                          />
                        }
                        label="Inverse"
                      />
                      <Stack>
                        <Box>
                          <Grid container spacing={2} alignItems="center">
                            <Grid item xs>
                              <GradientSlider
                                disabled={!item.enabled}
                                value={item.thresholdValue}
                                defaultValue={0.5}
                                step={0.1}
                                onChange={(e) =>
                                  handleSliderChange(
                                    e,
                                    selectedGroupIndex === -1
                                      ? groupIndex
                                      : selectedGroupIndex,
                                    index
                                  )
                                }
                                aria-labelledby="input-slider"
                                min={0}
                                max={1}
                                marks={[
                                  {
                                    value: 0,
                                    label: "0",
                                  },

                                  {
                                    value: 1,
                                    label: "1",
                                  },
                                ]}
                              />
                            </Grid>
                            <Grid item>
                              <Paper
                                elevation={3}
                                sx={{ p: 1, backgroundColor: "#FBFBFB" }}
                              >
                                {item.thresholdValue}
                              </Paper>
                              {/* <Input
                        style={{fontWeight: "500", fontSize: "1rem"}}
                        value={value}
                        size="small"
                        onChange={handleInputChange}
                        onBlur={handleBlur}
                        disabled
                        // inputProps={{
                        //   step: 10,
                        //   min: 0,
                        //   max: 100,
                        //   type: "number",
                        //   "aria-labelledby": "input-slider",
                        // }}
                      /> */}
                            </Grid>
                          </Grid>
                        </Box>
                      </Stack>
                    </Paper>
                  )
              )
            )}
        </Stack>

        <Stack width="100%" direction="row" justifyContent="center">
          <Button variant="contained" onClick={toggleDelete}>
           {isEdit ? "Update" : "Create"}
          </Button>
        </Stack>
      </Stack>
      {open && (
        <CustomMetric
          open={open}
          onClose={closeCustomMetricModal}
          customMetric={customMetricData}
        />
      )}

      <Confirmation
        open={confirmDelete}
        toggleConfirm={toggleDelete}
        handleSubmit={() => {
          handleSubmit();
          toggleDelete();
        }}
        message="Once you submit all the metrics values will be freezed for this
            Configuration. Do you want to proceed ?"
      />

      <Modal
        open={piiModal}
        onClose={() => setPiiModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "40rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Additional Inputs
            </Typography>
            <IconButton onClick={() => setPiiModal(false)}>
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Select PII</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: "50%" }}>
                <Select
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  multiple
                  value={selectedPiiValues}
                  onChange={(e) => {
                    setSelectedPiiValues(e.target.value);
                  }}
                  renderValue={(selected) => (
                    <div>
                      {selected.map((value) => (
                        <div key={value}>{value}</div>
                      ))}
                    </div>
                  )}
                >
                  {piiValues.map((value) => (
                    <MenuItem key={value} value={value}>
                      <Checkbox
                        checked={selectedPiiValues.indexOf(value) > -1}
                      />
                      <ListItemText primary={value} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>
          </div>
          <div className={styles.modalFooter}>
            <Button
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => setPiiModal(false)}
            >
              Save
            </Button>
          </div>
        </Box>
      </Modal>

      <Modal
        open={jailBreakModal}
        onClose={() => setJailBreakModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "40rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Additional Inputs
            </Typography>
            <IconButton onClick={() => setJailBreakModal(false)}>
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Number of Template</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: "30%" }}>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={templateCount}
                  onChange={(e) => setTemplateCount(e.target.value)}
                >
                  <MenuItem value={1}>1</MenuItem>
                  <MenuItem value={2}>2</MenuItem>
                  <MenuItem value={3}>3</MenuItem>
                  <MenuItem value={4}>4</MenuItem>
                  <MenuItem value={5}>5</MenuItem>
                </Select>
              </FormControl>
            </Stack>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Use Case</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, flex: 1 }}>
                <TextField
                  fullWidth
                  id="outlined-basic"
                  variant="outlined"
                  value={useCase}
                  onChange={(e) => setUseCase(e.target.value)}
                />
              </FormControl>
            </Stack>
          </div>
          <div className={styles.modalFooter}>
            <Button
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => setJailBreakModal(false)}
            >
              Save
            </Button>
          </div>
        </Box>
      </Modal>

      <Modal
        open={redTeamModal}
        onClose={() => setRedTeamModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "40rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Additional Inputs
            </Typography>
            <IconButton onClick={() => setRedTeamModal(false)}>
              {" "}
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Test Case</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: "100%" }}>
                <TextField
                  id="outlined-basic"
                  variant="outlined"
                  value={testcase}
                  onChange={(e) => setTestcase(e.target.value)}
                />
              </FormControl>
            </Stack>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Additional Context</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: "100%" }}>
                <TextField
                  fullWidth
                  id="outlined-basic"
                  variant="outlined"
                  value={additionalContext}
                  onChange={(e) => setAdditionalContext(e.target.value)}
                  multiline
                  minRows={2}
                />
              </FormControl>
            </Stack>
          </div>
          <div className={styles.modalFooter}>
            <Button
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => setRedTeamModal(false)}
            >
              Save
            </Button>
          </div>
        </Box>
      </Modal>

      <Modal
        open={adversialModal}
        onClose={() => setAdversialModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "40rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Additional Inputs
            </Typography>
            <IconButton onClick={() => setAdversialModal(false)}>
              {" "}
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Prompt</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: "100%" }}>
                <TextField
                  fullWidth
                  id="outlined-basic"
                  variant="outlined"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  multiline
                  minRows={2}
                />
              </FormControl>
            </Stack>
          </div>
          <div className={styles.modalFooter}>
            <Button
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => setAdversialModal(false)}
            >
              Save
            </Button>
          </div>
        </Box>
      </Modal>

      <Modal
        open={coverageModal}
        onClose={() => {
          setCoverageModal(false);
        }}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "80rem",
            bgcolor: "#EAF0F6",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "90vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} style={{ padding: "0.25rem" }}>
            <Stack
              direction="row"
              alignItems="center"
              justifyContent="space-between"
            >
              <Typography id="modal-modal-title" variant="h6" component="h2">
                Coverage Scope Mapper
              </Typography>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="end"
                gap="1rem"
                width="40%"
              >
                <InputLabel>Choose Template :</InputLabel>
                <FormControl style={{ width: "40%" }}>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={level}
                    size="small"
                    onChange={(e) => {
                      setLevel(e.target.value);
                    }}
                  >
                    <MenuItem value={2}>2-Tier Template</MenuItem>
                    <MenuItem value={3}>3-Tier Template</MenuItem>
                  </Select>
                </FormControl>
                <IconButton onClick={() => setCoverageModal(false)}>
                  {" "}
                  <CloseIcon />
                </IconButton>
              </Stack>
            </Stack>
          </Paper>
          <div className={styles.modalContent}>
            {displayTopics.map((it, ind) => (
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Paper
                  elevation={2}
                  style={{ padding: "0.5rem", width: "95%" }}
                  onMouseEnter={() => setHoverTopic(ind)}
                  onMouseLeave={() => setHoverTopic(-1)}
                >
                  <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Stack
                      direction="row"
                      width="95%"
                      gap="1%"
                      alignItems="center"
                    >
                      <TextField
                        sx={{ width: level === 3 ? "32%" : "45%" }}
                        id="outlined-basic"
                        variant="outlined"
                        size="small"
                        label="Topic"
                        value={displayTopics[ind].topic}
                        onChange={(e) =>
                          setDisplayTopics((prev) => {
                            let arr = [...prev];
                            arr[ind].topic = e.target.value;
                            return arr;
                          })
                        }
                      />
                      
                      <TextField
                        sx={{ width: level === 3 ? "32%" : "45%" }}
                        id="outlined-basic"
                        variant="outlined"
                        size="small"
                        label="SubTopic"
                        value={displayTopics[ind].subTopic}
                        onChange={(e) =>
                          setDisplayTopics((prev) => {
                            let arr = [...prev];
                            arr[ind].subTopic = e.target.value;
                            return arr;
                          })
                        }
                      />

                      {level === 3 && (
                        <TextField
                          style={{ width: "34%" }}
                          id="outlined-basic"
                          variant="outlined"
                          size="small"
                          label="Sub-SubTopic"
                          value={displayTopics[ind].subSubTopic}
                          onChange={(e) =>
                            setDisplayTopics((prev) => {
                              let arr = [...prev];
                              arr[ind].subSubTopic = e.target.value;
                              return arr;
                            })
                          }
                        />
                      )}
                    </Stack>

                    {hoverTopic === ind && (
                      <IconButton
                        aria-label="delete"
                        size="small"
                        color="error"
                        style={{ width: "4%" }}
                        onClick={() =>
                          setDisplayTopics((prev) => {
                            let arr = [
                              ...prev.slice(0, ind),
                              ...prev.slice(ind + 1),
                            ];
                            if (arr.length === 0) {
                              arr.push({
                                topic: "",
                                subTopic: "",
                                subSubTopic: "",
                              });
                            }
                            return arr;
                          })
                        }
                      >
                        <Tooltip title="Delete">
                          <DeleteIcon fontSize="medium" />
                        </Tooltip>
                      </IconButton>
                    )}
                    {hoverTopic !== ind && (
                      <MoreHorizIcon style={{ width: "5%" }} />
                    )}
                  </Stack>
                </Paper>
                {ind === displayTopics.length - 1 && (
                  <AddBoxOutlinedIcon
                    style={{ cursor: "pointer" }}
                    onClick={() =>
                      setDisplayTopics((prev) => [
                        ...prev,
                        { topic: "", subTopic: "", subSubTopic: "" },
                      ])
                    }
                  />
                )}
              </Stack>
            ))}
           
          </div>
          <Stack
            margin="0 0 0.5rem 0"
            width="100%"
            direction="row"
            alignItems="center"
            justifyContent="center"
          >
            <Button
              style={{ width: "5rem" }}
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => {
                let tpcArr = [];
                displayTopics.map((topicsText) => {
                  let index = -1,
                    subIndex = -1;
                  tpcArr.map((it, ind) => {
                    if (it.primary === topicsText.topic) {
                      index = ind;
                      it.value.map((tmp, subInd) => {
                        if (tmp.subTopic === topicsText.subTopic) {
                          subIndex = subInd;
                        }
                      });
                    }
                  });

                  if (index !== -1 && subIndex !== -1) {
                    if (level === 3) {
                      tpcArr[index].value[subIndex].value.push(
                        topicsText.subSubTopic
                      );
                    }
                  } else if (index === -1 && subIndex === -1) {
                    tpcArr.push({
                      primary: topicsText.topic,
                      value: [
                        {
                          subTopic: topicsText.subTopic,
                          value:
                            topicsText.subSubTopic === "" || level === 2
                              ? []
                              : [topicsText.subSubTopic],
                        },
                      ],
                    });
                  } else if (index !== -1) {
                    tpcArr[index].value.push({
                      subTopic: topicsText.subTopic,
                      value:
                        topicsText.subSubTopic === "" || level === 2
                          ? []
                          : [topicsText.subSubTopic],
                    });
                  }
                })
                setTopics(tpcArr)
              }}
              disabled={displayTopics.map(it => level===3 ? it.topic!=="" && it.subTopic!=="" && it.subSubTopic!=="" : it.topic!=="" && it.subTopic!=="").includes(false)}
            >
              Save
            </Button>
          </Stack>
        </Box>
      </Modal>
    </div>
  );
};

export default CreateConfiguration;
