import {
  Box,
  Button,
  Chip,
  FormControl,
  FormControlLabel,
  FormLabel,
  IconButton,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import React, { useContext, useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  completeEvaluation,
  getDatasetList,
  getModelDetails,
  runEvaluation,
  runEvaluation1,
} from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import { getAllModelConfigurations } from "../../../_services/model.service";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

const RunConfiguration = () => {
  const [datasetList, setDatasetList] = useState([]);
  const [dataset, setDataset] = useState("");
  const [modelDetails, setModelDetails] = useState([]);
  const [llmType, setLllmType] = useState("");
  const [llmName, setLlmName] = useState("");
  const [modelConfigurationList, setModelConfigurationList] = useState([]);
  const [selectedModelConfiguration, setSelectedModelConfiguration] =
    useState("");
  const [run_name, setRunName] = useState("");
  const [error, setError] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadMessage, setUploadMessage] = useState("");

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setUploadMessage("File uploaded successfully");
    }
  };

  const ctx = useContext(AuthContext);

  const { id } = useParams();

  const navigate = useNavigate();
  const { state } = useLocation();

  const handleChnangeDataset = (event) => {
    setDataset(event.target.value);
  };

  const handleChangeLlmType = (event) => {
    setLllmType(event.target.value);
  };

  const handleChangeLlmName = (event) => {
    setLlmName(event.target.value);
  };

  const handleSubmit = () => {
    const data1 = {
      datasetId: dataset,
      modelConfigurationId: selectedModelConfiguration,
      projectType: ctx.projectSubType,
      run_name: run_name
    };
    const data2 = {
      executionType: "genAIEvaluation",
      configId: id,
      executedBy: ctx.username,
      projectName: ctx.projectName,
      datasetId: dataset,
      model: llmName,
      projectType: ctx.projectSubType,
      run_name: run_name
    };

    runEvaluation1(data1).then((result1) => {
      completeEvaluation(data2).then((result2) => {
        // console.log(result2);
      });
    });

    navigate("/genai-assurance/genai_evaluate", { state: { tabIndex: 1 } });
  };

  const handleChange = (e) => {
    const value = e.target.value;
    setRunName(value);
    setError(value.trim() === ""); // Set error if input is empty
  };

  useEffect(() => {
    getDatasetList(ctx.projectName).then((result) => {
      setDatasetList(result.datasetInfoList);
    });
    getModelDetails().then((result) => {
      let data = JSON.parse(result.models);
      let modelList = [];
      data.map((item) => {
        item.Model.map((modelName) => {
          modelList.push(modelName);
        });
      });
      let modelSet = new Set(modelList);
      let uniqueList = [...modelSet];
      setModelDetails(uniqueList);
    });
    getAllModelConfigurations(ctx.projectName).then((result) => {
      setModelConfigurationList(result.modelConfigInfoList);
    });
  }, []);

  return (
    <div style={{ margin: "1rem" }}>
      <Paper style={{ padding: "1rem" }}>
        <Stack gap="1rem">
          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Configuration Name </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, minWidth: 300 }}>
              <TextField
                id="outlined-basic"
                variant="outlined"
                value={state.configurationName}
                disabled
              />
            </FormControl>
          </Stack>
          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Select Dataset </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, minWidth: 300 }}>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={dataset}
                onChange={handleChnangeDataset}
              >
                {datasetList.map((item) => (
                  <MenuItem value={item._id}>{item.datasetName}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Run Name </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, minWidth: 300 }}>
              <TextField
                id="outlined-basic"
                variant="outlined"
                value={run_name}
                onChange={handleChange}
                error={error}
                helperText={error ? "Run name cannot be empty" : ""}

              />
            </FormControl>
          </Stack>
          {ctx.projectSubType === "CODEGEN" && (
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>Upload Code Output</FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, minWidth: 300 }}>
                <input
                  accept="*"
                  style={{ display: "none" }}
                  id="icon-button-file"
                  type="file"
                  onChange={handleFileUpload}
                />
                <label htmlFor="icon-button-file">
                  <IconButton
                    color="primary"
                    aria-label="upload file"
                    component="span"
                  >
                    <CloudUploadIcon />
                  </IconButton>
                </label>
                {selectedFile && (
                  <Typography variant="body2">{selectedFile.name}</Typography>
                )}
                {uploadMessage && (
                  <Typography variant="body2" color="green">
                    {uploadMessage}
                  </Typography>
                )}
              </FormControl>
            </Stack>
          )}

          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>
              Select Model Configuration
            </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, minWidth: 300 }}>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={selectedModelConfiguration}
                onChange={(e) => setSelectedModelConfiguration(e.target.value)}
              >
                {modelConfigurationList.map((item) => (
                  <MenuItem value={item._id}>{item.configurationName}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          {/* <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>LLM Connectivity </FormLabel>
            <FormLabel>:</FormLabel>
            <RadioGroup
              row
              aria-labelledby="demo-row-radio-buttons-group-label"
              name="row-radio-buttons-group"
              value={llmType}
              onChange={handleChangeLlmType}
            >
              {modelDetails.map((item) => (
                <>
                  <FormControlLabel
                    value={item.Provider}
                    control={<Radio />}
                    label={item.Provider}
                  />
                </>
              ))}
            </RadioGroup>
          </Stack> */}

          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Evaluator LLM </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, minWidth: 300 }}>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={llmName}
                onChange={handleChangeLlmName}
              >
                {modelDetails.map((modelName) => (
                  <MenuItem value={modelName}>{modelName}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          <Stack width="50%" direction="row" justifyContent="center" gap="1rem">
            <Button variant="contained" onClick={handleSubmit}>
              Execute
            </Button>
            <Button
              variant="outlined"
              startIcon={<KeyboardBackspaceIcon />}
              onClick={() => navigate("/genai-assurance/genai_evaluate")}
            >
              Back
            </Button>
          </Stack>
        </Stack>
      </Paper>
    </div>
  );
};

export default RunConfiguration;
