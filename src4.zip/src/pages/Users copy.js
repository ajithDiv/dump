import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Badge, Button, ButtonGroup, Card, CardBody, CardHeader, Col, Row, Table, TabContent, TabPane, Modal, ModalBody, ModalFooter, ModalHeader, Nav, NavItem, NavLink, FormGroup, Label} from 'reactstrap';
import classNames from 'classnames';
import Tabs from 'react-bootstrap/Tabs';
import Tab from 'react-bootstrap/Tab';
import  Pagination  from '../../_helpers/Pagination'
import { userService, projectService , licenseService } from '../../_services';
// import usersData from './UsersData'
import DOMPurify from 'dompurify';
import { CircularProgress } from '@mui/material';

function UserRow(props) {
  const user = props.user;
  const key = props.index + 1;
  const userLink = `/settings/users/${user.username}`
  const edituserLink = `/settings/users/edit/${user.username}`

  const getBadge = (status) => {
    return status === 'Active' ? 'success' :
      status === 'Inactive' ? 'secondary' :
        status === 'Pending' ? 'warning' :
          status === 'Banned' ? 'danger' :
            'primary'
  }
  const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))

  return (
    <tr key={user.id}>
        <td scope="row">{user.index}</td>
        <td><Link to={userLink}>{user.firstName} {user.lastName}</Link></td>
        <td>{user.emailId}</td>
        <td>{user.username}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(user.created))}</td>
        { sanitizedUserName === 'admin' && 
          <td>
            <ButtonGroup>
              <Button size="sm" color="primary" style={{width: '30px', height: '30px'}}  tag={Link} to={edituserLink}><i className="icon-pencil pr-1"></i></Button>{' '}
              <Button disabled={user.username=="admin"} size="sm" color="danger" style={{width: '30px', height: '30px'}}  onClick={() => props.toggleDanger(user.id)} className="mr-1">
                <i className="fa fa-trash-o fa-lg" style={{paddingTop:'0rem', marginTop: '0rem !important'}}></i>
              </Button>
            </ButtonGroup> 
          </td>
        }
      </tr>
  )
}

function LicenseRow(props) {
  const license = props.license;
  const key = props.index + 1;
  return (
    <tr key={license.botID}>
        <td>{license.index}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(license.StartDate))}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(license.EndDate))}</td>
        <td>{license.Type}</td>

        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(license.uploadedDate))}</td>
          <td>{license.uploadedBy}</td>
      </tr>
  )
}


function ProjectRow(props) {
  const project = props.project;
  const projectLink = `/settings/projects/${project.projectName}`;
  const editProjectLink = `/settings/projects/edit/${project.projectName}`;
  const projectRoleList = props.projectUserRole;
  const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
  return (
    <tr key={project.id}>
        <td scope="row">{project.index}</td>
        <td><Link to={projectLink}>{project.projectName}</Link></td>
        <td>{project.projectDesc}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(project.created))}
        </td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(project.modified))}
        </td>
        <td>
        <Button size="sm" color="primary" style={{width: '30px', height: '30px'}}  tag={Link} to={editProjectLink} disabled = {!(projectRoleList[project.projectName] == 'superAdmin' || projectRoleList[project.projectName] == 'admin' || projectRoleList[project.projectName] == 'projectOwner' )}><i className="icon-pencil pr-1"></i></Button>
        <Button size="sm" color="danger" style={{width: '30px', height: '30px'}} disabled={sanitizedUserName !== 'admin'} onClick={() => props.toggleProjectDelete(project.projectName)} className="mr-1">
                <i className="fa fa-trash-o fa-lg" style={{paddingTop:'0rem', marginTop: '0rem !important'}}></i>
        </Button>
        </td>
      </tr>
  )
}

class Users extends Component {

  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.createUser = this.createUser.bind(this);
    this.toggleDanger = this.toggleDanger.bind(this);
    this.getAllUsers = this.getAllUsers.bind(this);
    this.deleteUser = this.deleteUser.bind(this)
    
    this.createProject = this.createProject.bind(this);
    this.getAllProjects = this.getAllProjects.bind(this);
    this.deleteProject = this.deleteProject.bind(this);
    this.toggleProjectDelete = this.toggleProjectDelete.bind(this)

    this.getLicenseDetails = this.getLicenseDetails.bind(this);

    var exampleItems = [...Array(11).keys()].map(i => ({ id: (i+1), name: 'Item ' + (i+1) }));

    this.state = {
      //activeTab: 'user',
      danger: false,
      isLoading: true,
      selectedUserId: '',
      userList: [],
      projectList: [],
      licenseList: [],
      selectedProjectName: '',
      projectDeleteFlag: false,
      exampleItems: exampleItems,
      pageOfUserItems: [],
      pageOfProjectItems: [],
      pageOfLicenseItems: [],
      licenseFile: [],
      fileUploaded: false,
      licenseUploadFlag:false,
      error:'',
      loading: false,
      currentUserProjectList: [],
      instanceValid: false,
      instanceError: '',
      assignedUserRole: '',
      projectUserRoleList: [],
      selectedUserPrivilege: '',
      userError: '',
    };
    this.fileUpload = this.fileUpload.bind(this);
    this.onChangeUserPage = this.onChangeUserPage.bind(this);
    this.onChangeProjectPage = this.onChangeProjectPage.bind(this);
    this.onChangeLicensePage = this.onChangeLicensePage.bind(this);
    this.handleErrorClose = this.handleErrorClose.bind(this);
  }

  onChangeUserPage(pageOfUserItems) {
    // update state with new page of items
    this.setState({ pageOfUserItems: pageOfUserItems });
  }

  onChangeLicensePage(pageOfLicenseItems) {
    // update state with new page of items
    this.setState({ pageOfLicenseItems: pageOfLicenseItems });
  }

  onChangeProjectPage(pageOfProjectItems) {
    // update state with new page of items
    this.setState({ pageOfProjectItems: pageOfProjectItems });
  }

  toggle(tab) {
    if (this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab,
      });
    }
  }
  
  toggleDanger(userid) {
    this.setState({
      danger: !this.state.danger,
      selectedUserId: userid
    });
  }

  componentDidMount() {
    this.setState({isLoading: true});
    const type = this.props.match.params.type;
    let selectedProjectName = DOMPurify.sanitize(localStorage.getItem('selectedProject'));
    const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
    userService.getUserDetails(sanitizedUserName).then(data => {
      this.setState({
        assignedUserRole: data.userRolesList[selectedProjectName][0],
        projectUserRoleList: data.userRolesList,
        selectedUserPrivilege: data.selectedRolePrivilege,
      })
      if(this.state.selectedUserPrivilege == 'readOnlyRole'){
        this.setState({
          userError: "You do not have permission to access this tab.",
          isLoading: false,
        })
      }
    })
    
    // if (type === 'home' || type === 'users') {
    //   this.setState({activeTab: 'user'});
    // } else if (type === 'projects'){
    //   this.setState({activeTab: 'project'});
    // }  else {
    //   this.setState({activeTab: 'license'});
    // }
    this.getAllUsers();
    this.getLicense();   
  }

  getLicense(){
    licenseService.checkInstanceValidity().then( data => {
      if(data){
       this.setState({
         instanceValid: true,
         instanceError: ''
       });
      } else{
        this.setState({
          instanceValid:false
        })
      }
      if(this.state.instanceValid){
        this.getLicenseDetails();
      } 
    }, error => {
      this.setState({
        instanceValid: false,
        instanceError: error
      });
    })
  }

  getAllUsers(){
    userService.getAllUsers().then( data => {
      let index = 1;
      let currentUserProjectList = [];
      const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
      data.map((user) => {
        user.index = index++;
        if (user.username === sanitizedUserName) {
          currentUserProjectList = Object.keys(user.userRolesList);
        }
      })
      this.setState({
        userList: data,
        currentUserProjectList: currentUserProjectList,
        isLoading: false
      })
      this.getAllProjects();
    });
  }

  createUser() {
    const { from } = { from: { pathname: "/settings/users/create/new" } };
    this.props.history.push(from);
  }

  deleteUser(userid) {
    userService.deleteUser(userid).then(
      data => {
        this.getAllUsers();
        this.setState({danger: !this.state.danger});
      },
      error => this.setState({ error, loading: false })
    );
  }

  getAllProjects(){
    projectService.getAllProjects().then( data => {
      let index = 1;
      data.map((project) => {
        project.index = index++;
        if (this.state.currentUserProjectList.length > 0) {
          project.currentList = this.state.currentUserProjectList;
        } 
      })
      this.setState({
        projectList: data, 
        isLoading: false
      })
    });
  }

  getLicenseDetails(){
    licenseService.getLicenseDetails().then( data => {
      let index = 1;
      data.BotDetails.map((license) => {
        license.index = index++;
      })
      this.setState({
        licenseList:  data.BotDetails, 
        isLoading: false
      })
    });
  }

  createProject() {
    const { from } = { from: { pathname: "/settings/projects/create/new" } };
    this.props.history.push(from);
  }

  deleteProject(projectName) {
    projectService.deleteProject(projectName).then(
      data => {
        this.getAllProjects();
        this.setState({projectDeleteFlag: !this.state.projectDeleteFlag});
        window.location.reload(false);
      },
      error => this.setState({ error, loading: false })
    );
  }

  toggleProjectDelete(projectName) {
    this.setState({
      projectDeleteFlag: !this.state.projectDeleteFlag,
      selectedProjectName: projectName
    });
  }

  toggleLicenseUpload(){
    this.setState({
      licenseUploadFlag: !this.state.licenseUploadFlag,
      fileUploaded: false,
      error: ''
    });
  }

  updateLicense() {
    if (this.state.fileUploaded) {
      this.setState({ loading: true });
      const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
      licenseService.uploadLicenseFile(this.state.licenseFile, sanitizedUserName).then(
        data => { 
          this.toggleLicenseUpload();
          // localStorage.removeItem('instanceError')
          // localStorage.setItem('instanceValid', true);
          this.setState({
            instanceValid: true,
            instanceError: ''
          })
          this.getLicenseDetails();
          const { from } = { from: { pathname: "/settings/license" } };
          this.props.history.push(from);
        },
        error => {
          this.setState({ error: 'Error while uploading license file: '+ error, loading: false, fileUploaded:false, licenseFile: [] });
        }
      );
    }    
  }

  fileUpload = (e) => {
    e.preventDefault();
    let file = e.target.files[0];
    if(file.name.includes('.txt')){
      this.setState({
        licenseFile: file,
        fileUploaded: true,
        loading:false,
        error:''
      })
    }else{
      this.setState({ error: 'Please upload a valid .txt file', loading: false, fileUploaded:false, licenseFile: [] });
    }

  }

  handleErrorClose() {
    this.setState({ error : '',loading : true });
  }


  render() {
    // const userList = usersData.filter((user) => user.id < 10)
    const {userList, projectList, isLoading, loading, error} = this.state;
    const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
    if (isLoading) {
      return <CircularProgress/>;
    }

    const userhtml = userList.map((user, index) => {
      const key = index + 1;
      const userLink = `/settings/users/${user.username}`
      const edituserLink = `/settings/users/edit/${user.username}`

      return <tr key={user.id}>
        <th scope="row"><Link to={userLink}>{key.toString()}</Link></th>
        <td><Link to={userLink}>{user.firstName} {user.lastName}</Link></td>
        <td>{user.emailId}</td>
        <td>{user.username}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(user.created))}</td>
          <td>
            <ButtonGroup>
              <Button size="sm" color="primary" style={{width: '30px', height: '30px'}}  tag={Link} to={edituserLink}><i className="icon-pencil pr-1"></i></Button>{' '}
              <Button size="sm" color="danger" style={{width: '30px', height: '30px'}}  onClick={() => this.toggleDanger(user.id)} className="mr-1">
                <i className="fa fa-trash-o fa-lg" style={{paddingTop:'0rem', marginTop: '0rem !important'}}></i>
              </Button>
            </ButtonGroup> 
          </td>
      </tr>
    });


    const projecthtml = projectList.map((project, index) => {
      const key = index + 1;
      const projectLink = `/settings/projects/${project.projectName}`
      const editProjectLink = `/settings/projects/edit/${project.projectName}`
      const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))

      return <tr key={project.id}>
        <th scope="row"><Link to={projectLink}>{key.toString()}</Link></th>
        <td><Link to={projectLink}>{project.projectName}</Link></td>
        <td>{project.projectDesc}</td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(project.created))}
        </td>
        <td>{new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: '2-digit'
          }).format(new Date(project.modified))}
        </td>
        { sanitizedUserName &&
          <td>
            <ButtonGroup>
              <Button size="sm" color="primary" style={{width: '30px', height: '30px'}}  tag={Link} to={editProjectLink} disabled = {this.state.assignedUserRole != 'superAdmin'} ><i className="icon-pencil pr-1"></i></Button>{' '}
              <Button size="sm" color="danger" style={{width: '30px', height: '30px'}} disabled = {this.state.assignedUserRole != 'superAdmin'}  onClick={() => this.toggleProjectDelete(project.projectName)} className="mr-1">
                <i className="fa fa-trash-o fa-lg" style={{paddingTop:'0rem', marginTop: '0rem !important'}}></i>
              </Button>
            </ButtonGroup> 
          </td>
        }
      </tr>
    });

    return (
      <div className="animated fadeIn">
        {
          this.state.userError &&
          <div className="alertmessage alert alert-danger">
              <a className="close">
                <span aria-hidden="true">&nbsp;&times;</span>
              </a>
              <span className="span-message">{this.state.userError}</span>
            </div>
        }
        { !this.state.userError &&
        <Card>
          <CardHeader>
            <i className="fa fa-align-justify"></i><strong>Settings</strong>
          </CardHeader>
          <CardBody>
            {
              <Tabs>
              {   localStorage.getItem('username') == 'admin' &&
                <Tab eventKey="user" title="Users" className={classNames({ active: this.state.activeTab === 'user' })}>
                <Row>
                  <Col xl={12}>
                    <Card>
                      <CardBody>
                        <Row className="align-items-right" style={{float: 'right'}}>
                          <Col col="6" sm="4" md="2" xl className="mb-3 mb-xl-0">
                            <Button block color="primary" style={{fontSize: '0.775rem', marginBottom: '10px'}}
                              onClick={() => {
                                this.createUser();
                              }}>Create User</Button>
                          </Col>
                        </Row>
                        <Table responsive hover>
                          <thead>
                            <tr>
                            <th scope="col">S.No.</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email ID</th>
                            <th scope="col">User Name</th>
                            <th scope="col">Created Date</th>
                            <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.pageOfUserItems.map((user, index) =>
                                <UserRow key={index} user={user} index={index} toggleDanger={(id) => this.toggleDanger(id)}/>
                            )}
                          </tbody>
                        </Table>
                        <Pagination items={this.state.userList} pageSize={5} onChangePage={this.onChangeUserPage} />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                </Tab>
            }
                <Tab eventKey="project" title="Projects" className={classNames({ active: this.state.activeTab === 'project' })}>
                <Row>
                  <Col xl={12}>
                    <Card>
                      <CardBody>
                        <Row className="align-items-right" style={{float: 'right'}}>
                          <Col col="6" sm="4" md="2" xl className="mb-3 mb-xl-0">
                            {
                              this.state.assignedUserRole == 'superAdmin' &&
                              <Button block color="primary" style={{fontSize: '0.775rem', marginBottom: '10px'}}
                              onClick={() => {
                                this.createProject();
                              }}>Create Project</Button>
                            }                            
                          </Col>
                        </Row>
                        <Table responsive hover>
                          <thead>
                            <tr>
                              <th scope="col">S.No.</th>
                              <th scope="col">Name</th>
                              <th scope="col">Description</th>
                              <th scope="col">Created Date</th>
                              <th scope="col">Modified Date</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.pageOfProjectItems.map((project, index) =>
                                <ProjectRow key={index} project={project} index={index} assignedUserRole = {this.state.assignedUserRole} projectUserRole = {this.state.projectUserRoleList} toggleProjectDelete={(id) => this.toggleProjectDelete(id)}/>
                            )}
                          </tbody>
                        </Table>
                        <Pagination items={this.state.projectList} pageSize={5} onChangePage={this.onChangeProjectPage} />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                </Tab>
                {  localStorage.getItem('username') == 'admin' &&
                <Tab eventKey="License" title="License" className={classNames({ active: this.state.activeTab === 'License' })}>
                <Row>
                  <Col xl={12}>
                    <Card>
                      <CardBody>
                        <Row className="align-items-right" style={{float: 'right'}}>
                          <Col col="6" sm="4" md="2" xl className="mb-3 mb-xl-0">
                            <Button block color="primary" style={{fontSize: '0.775rem', marginBottom: '10px'}}
                              onClick={() => {
                                this.toggleLicenseUpload();
                              }}>Upload License</Button>
                          </Col>
                        </Row>
                       
                        { !this.state.instanceValid && 
                        <Row> <b>{this.state.instanceError}</b> </Row> }
                        { this.state.instanceValid && 
                        <Table responsive hover>
                          <thead>
                            <tr>
                            <th scope="col">S.No.</th>
                            <th scope="col">License Start Date</th>
                            <th scope="col">License End Date</th>
                            <th scope="col">License Type</th>
                            <th scope="col">Uploaded Date</th>
                            <th scope="col">Uploaded by</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.pageOfLicenseItems.map((license, index) =>
                                <LicenseRow key={index} license={license} index={index} toggleDanger={(id) => this.toggleDanger(id)}/>
                            )}
                          </tbody>
                        </Table>
                        }
                        <Pagination items={this.state.licenseList} pageSize={5} onChangePage={this.onChangeLicensePage} />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                </Tab>
            }
              </Tabs>
            }            

            <Modal isOpen={this.state.danger} toggle={() => this.toggleDanger(this.state.selectedUserId)}
                       className={'modal-danger ' + this.props.className}>
              <ModalHeader toggle={() => this.toggleDanger(this.state.selectedUserId)}>Delete User</ModalHeader>
              <ModalBody>
                Are you sure want to delete user?
              </ModalBody>
              <ModalFooter>
                <Button color="danger" onClick={() => this.deleteUser(this.state.selectedUserId)}>Yes</Button>{' '}
                <Button color="secondary" onClick={() => this.toggleDanger(this.state.selectedUserId)}>Cancel</Button>
              </ModalFooter>
            </Modal>

            <Modal isOpen={this.state.projectDeleteFlag} toggle={() => this.toggleProjectDelete(this.state.selectedProjectName)}
                       className={'modal-danger ' + this.props.className}>
              <ModalHeader toggle={() => this.toggleProjectDelete(this.state.selectedProjectName)}>Delete Project</ModalHeader>
              <ModalBody>
                Are you sure want to delete project?
              </ModalBody>
              <ModalFooter>
                <Button color="danger" onClick={() => this.deleteProject(this.state.selectedProjectName)}>Yes</Button>{' '}
                <Button color="secondary" onClick={() => this.toggleProjectDelete(this.state.selectedProjectName)}>Cancel</Button>
              </ModalFooter>
            </Modal>

            <Modal isOpen={this.state.licenseUploadFlag} toggle={() => this.toggleLicenseUpload()}
                       className={'modal-primary ' + this.props.className}>
              <ModalHeader  style={{backgroundColor: '#0039a6'}} toggle={() => this.toggleLicenseUpload()}>Upload License</ModalHeader>
              {error && 
                  <div className="alertmessage alert alert-danger">
                    <a className="close" onClick={this.handleErrorClose}>
                        <span aria-hidden="true">&nbsp;&times;</span>
                    </a>
                    <span className="span-message">{error}</span>
                  </div>
                }
              <ModalBody>
              <FormGroup>
                      <Label htmlFor="file-input">License File</Label><br></br>
                      <input type="file" id="file" name="file" className="inputFile" inputProps={{ accept: '.txt' }}  accept=".txt" onChange={e =>  this.fileUpload(e)}/>
              </FormGroup>
              </ModalBody>
              <ModalFooter>
                <Button color="primary" onClick={() => this.updateLicense()} disabled={!this.state.fileUploaded}>Upload</Button>{' '}
                <Button color="secondary" onClick={() => this.toggleLicenseUpload()}>Cancel</Button>
              </ModalFooter>
            </Modal>

          </CardBody>
        </Card>

        }
      </div>
      
    )
  }
}

export default Users;

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.