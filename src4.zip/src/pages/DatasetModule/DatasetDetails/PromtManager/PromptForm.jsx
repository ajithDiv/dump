import React, { useState } from "react";
import "./PromptForm.css";

const PromptForm = (props) => {
  const defaultTopics = props.topics;
  const [defaultSubtopics,setSubTopics]= useState(props.subtopicsMap[props.topics[0].id]);

  const [topic, setTopic] = useState("Changes & Cancellations");
  const [customTopic, setCustomTopic] = useState("");
  const [description, setDescription] = useState("");
  const [subtopic, setSubtopic] = useState("Rebooking");
  const [customSubtopic, setCustomSubtopic] = useState("");
  const [examples, setExamples] = useState([{ original: "", augmented: "" }]);
  const [numPrompts, setNumPrompts] = useState("1750");
  const [minTokens, setMinTokens] = useState("0");
  const [maxTokens, setMaxTokens] = useState("100");
  const [keywords, setKeywords] = useState(["Keyword 01", "Keyword 02", "Keyword 03"]);
  const [errors, setErrors] = useState({});

  const handleExampleChange = (index, key, value) => {
    const newExamples = [...examples];
    newExamples[index][key] = value;
    setExamples(newExamples);
  };

  const addExample = () => {
    setExamples([...examples, { original: "", augmented: "" }]);
  };

  const validateForm = () => {
    const newErrors = {};
    if (topic === "Other" && !customTopic.trim()) newErrors.topic = "Topic is required";
    if (subtopic === "Other" && !customSubtopic.trim()) newErrors.subtopic = "Subtopic is required";
    if (!description.trim()) newErrors.description = "Description is required";

    examples.forEach((ex, i) => {
      if (!ex.original.trim() || !ex.augmented.trim()) {
        newErrors[`example-${i}`] = "Both fields required";
      }
    });

    if (!numPrompts || isNaN(numPrompts)) newErrors.numPrompts = "Valid number required";
    if (minTokens === "" || isNaN(minTokens)) newErrors.minTokens = "Required";
    if (maxTokens === "" || isNaN(maxTokens)) newErrors.maxTokens = "Required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleTopicChange =(value)=>{
    setSubTopics();
    setSubTopics(props.subtopicsMap[value]);
  }
  const handleSubmit = () => {
    if (validateForm()) {
      alert("Form is valid. Proceed to generate prompts.");
      // Proceed to next step or call mock API
    }
  };

  return (
    <div className="prompt-form-wrapper">
      <div className="prompt-form-card">
        <div className="prompt-form-card-1">
          <h2>Create New Prompt</h2>

          <div className="row">
            <div className="field">
              <label>Topic</label>
              <select value={topic} onChange={(e) => handleTopicChange(e.target.value)}>
                {defaultTopics.map((opt, idx) => <option value={opt.id} key={idx}>{opt.name}</option>)}
              </select>
              {topic === "t_other" && (
                <input placeholder="Enter Topic" value={customTopic} onChange={(e) => setCustomTopic(e.target.value)} />
              )}
              {errors.topic && <p className="error">{errors.topic}</p>}
            </div>

            <div className="field">
              <label>Sub Topic</label>
              <select value={subtopic} onChange={(e) => setSubtopic(e.target.value)}>
                {defaultSubtopics.map((opt, idx) => <option key={idx}>{opt}</option>)}
              </select>
              {subtopic === "Other" && (
                <input placeholder="Enter Subtopic" value={customSubtopic} onChange={(e) => setCustomSubtopic(e.target.value)} />
              )}
              {errors.subtopic && <p className="error">{errors.subtopic}</p>}
            </div>
          </div>

          <div className="field">
            <label>Description</label>
            <textarea placeholder="Type prompt description here..." value={description} onChange={(e) => setDescription(e.target.value)} />
            {errors.description && <p className="error">{errors.description}</p>}
          </div>

          <div className="field-group">
            <label>Provide Examples</label>
            {examples.map((ex, i) => (
              <div className="row" key={i}>
                <input
                  placeholder="Original Input"
                  value={ex.original}
                  onChange={(e) => handleExampleChange(i, "original", e.target.value)}
                />
                <input
                  placeholder="Augmented Input"
                  value={ex.augmented}
                  onChange={(e) => handleExampleChange(i, "augmented", e.target.value)}
                />
                {errors[`example-${i}`] && <p className="error">{errors[`example-${i}`]}</p>}
              </div>
            ))}
            <button className="add-btn" onClick={addExample}>+ Add New</button>
          </div>
        </div>


        <div className="row">
          <div className="field bottom-field">
            <h3>Promts</h3>
            <div className="promt-block">
              <label>No. of Prompts to be Generated</label>
              <input value={numPrompts} onChange={(e) => setNumPrompts(e.target.value)} />
              {errors.numPrompts && <p className="error">{errors.numPrompts}</p>}
            </div>
          </div>
          <div className="field bottom-field">
            <h3>Limit the Token of the Prompts generated</h3>
            <div className="token-block">
              <div className="">
                <label>Min Token</label>
                <input value={minTokens} onChange={(e) => setMinTokens(e.target.value)} />
                {errors.minTokens && <p className="error">{errors.minTokens}</p>}
              </div>
              <div className="">
                <label>Max Token</label>
                <input value={maxTokens} onChange={(e) => setMaxTokens(e.target.value)} />
                {errors.maxTokens && <p className="error">{errors.maxTokens}</p>}
              </div>
            </div>
          </div>
          <div className="field bottom-field">
            <h3>Refrain prompt generation with Keywords</h3>
            <div className="keywords">
              {keywords.map((k, i) => (
                <span key={i} className="keyword">{k}</span>
              ))}
            </div>
          </div>
        </div>



        <div className="footer-row">
          <button className="back-btn" onClick={() => props.onBack()}>← Back to Upload</button>
          <button className="generate-btn" onClick={() => { if (validateForm()) props.onNext(); }}>Generate Prompts</button>
        </div>
      </div>
    </div>
  );
};

export default PromptForm;