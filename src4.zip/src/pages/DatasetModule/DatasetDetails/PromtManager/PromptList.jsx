import React, { useState } from "react";
import "./PromptList.css";

const dummyPrompt = [
  {
    "id": "call_001",
    "topic": "Changes & Cancellations",
    "subtopic": "Cancellation Fees & Waivers",
    "conversation": [
      "Customer: Hi, I need to cancel my flight urgently due to a medical emergency in the family. Is it possible to waive the cancellation fee?",
      "Agent: I'm sorry to hear that. Could you please share your booking reference so I can check your details?",
      "Customer: Sure, it's FL123456.",
      "Agent: Thank you. I see the booking is for tomorrow from Delhi to Dubai. Do you have a medical certificate?",
      "Customer: Yes, I’ve got one from the hospital.",
      "Agent: Great. Please email it to medicaldocs@travelnow.com. Once verified, I’ll process the waiver.",
      "Customer: I just sent it.",
      "Agent: Got it. Based on the document, I’ve applied the waiver. You’ll receive a full refund in 5–7 working days.",
      "Customer: That’s very helpful, thank you.",
      "Agent: You’re welcome. Wishing your family good health."
    ]
  },
  {
    "id": "call_002",
    "topic": "Changes & Cancellations",
    "subtopic": "Cancellation Fees & Waivers",
    "conversation": [
      "Customer: Hello, I want to cancel my flight to Chennai due to the flood situation. Can the cancellation charge be waived?",
      "Agent: I understand. Safety comes first. Can you share your PNR number?",
      "Customer: It’s CJ78654.",
      "Agent: Thank you. We are offering waivers due to the floods. I’ll cancel your ticket and initiate a full refund.",
      "Customer: That’s great to hear. Do I need to send any proof?",
      "Agent: No, for affected regions like Chennai, no document is needed. You’ll get your refund in 3–5 business days.",
      "Customer: Thank you so much.",
      "Agent: You're welcome. Stay safe."
    ]
  },
  {
    "id": "call_003",
    "topic": "Changes & Cancellations",
    "subtopic": "Cancellation Fees & Waivers",
    "conversation": [
      "Customer: Hi, I booked a ticket to London, but my visa got rejected. Can I get a waiver on the cancellation fee?",
      "Agent: I’m sorry to hear that. May I have your booking ID?",
      "Customer: Yes, it’s UK998877.",
      "Agent: Thank you. We do allow waivers in case of visa rejection. Do you have the official rejection letter?",
      "Customer: Yes, I’ve already scanned it.",
      "Agent: Please email it to visa-support@airlink.com. Once verified, I’ll process the waiver.",
      "Customer: Done. Sent it now.",
      "Agent: Verified. I’ve canceled the booking and the full amount will be refunded to your card in 7 working days.",
      "Customer: That’s a relief. Thank you.",
      "Agent: Happy to help. Let us know if you rebook your travel."
    ]
  },
  {
    "id": "call_004",
    "topic": "Changes & Cancellations",
    "subtopic": "Cancellation Fees & Waivers",
    "conversation": [
      "Customer: Hello, I need to cancel my mother’s flight due to her sudden hospitalization. Can the cancellation fee be waived?",
      "Agent: I’m really sorry to hear that. Could you provide the booking reference?",
      "Customer: It’s REF202455.",
      "Agent: Thank you. I found the booking. If you can send the hospitalization certificate, I can escalate it for a waiver.",
      "Customer: Sure, emailing it now.",
      "Agent: Got it. The medical waiver has been approved. You’ll receive a full refund shortly.",
      "Customer: Thank you very much for the support.",
      "Agent: You’re welcome. I hope your mother recovers soon."
    ]
  },
  {
    "id": "call_005",
    "topic": "Changes & Cancellations",
    "subtopic": "Cancellation Fees & Waivers",
    "conversation": [
      "Customer: Hi, I have to cancel my upcoming flight due to a death in the family. Is there any possibility to waive the cancellation charges?",
      "Agent: I’m very sorry for your loss. Can you share your booking number?",
      "Customer: Yes, it’s MUM456321.",
      "Agent: I’ve located the booking. We do offer waivers in bereavement cases. Could you provide a death certificate or official note?",
      "Customer: Yes, I can send it right away.",
      "Agent: Please send it to care@farewave.com. Once I receive it, I’ll process the waiver.",
      "Customer: Sent.",
      "Agent: Confirmed. The waiver is approved and your full refund will be credited within 5 working days.",
      "Customer: I appreciate your help during this time.",
      "Agent: Our condolences again. We’re here if you need anything else."
    ]
  }
]

const PromptList = ({ onBack }) => {
  const [prompts, setPrompts] = useState(dummyPrompt);
  const [selected, setSelected] = useState(new Set());

  const toggleSelect = (index) => {
    const newSet = new Set(selected);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    setSelected(newSet);
  };

  return (
    <div className="prompt-list-wrapper">
      <div className="prompt-list-card">
        <h3>Prompts List ({prompts.length})</h3>
        {prompts.map((p, idx) => (
          <div key={idx} className="prompt-item">
            <input
              type="checkbox"
              checked={selected.has(idx)}
              onChange={() => toggleSelect(idx)}
            />
            <div className="prompt-content">
              <div className="prompt-text">
                <strong>{p.id}</strong> {p.conversation+""}
              </div>
              <div className="prompt-tags">Topic:
                <span  className="tag">{p.topic}</span> &nbsp; Sub Topic:
                <span  className="tag">{p.subtopic}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="prompt-list-footer">
        <div className="selected-info">
          <span>Selected ({selected.size}):</span>
          {[...selected].map(i => (
            <span key={i} className="pill">{prompts[i].id}</span>
          ))}
        </div>
        <div className="actions">
          <button className="back-btn" onClick={onBack}>← Back</button>
          <button className="generate-btn">Push to Datasets</button>
        </div>
      </div>
    </div>
  );
};

export default PromptList;