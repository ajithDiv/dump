import React, { useEffect, useState } from "react";
import UploadScreen from "./UploadScreen";
import PromptForm from "./PromptForm";
import PromptReview from "./PromptReview";
import PromptList from "./PromptList";

import mockData from "./mockData.json";

const PromptManager = () => {
  const [screen, setScreen] = useState("upload");
  const [topics, setTopics] = useState([]);
  const [subtopicsMap, setSubtopicsMap] = useState({});
  const [prompts, setPrompts] = useState([]);

  useEffect(() => {
    setTopics(mockData.topics);
    setSubtopicsMap(mockData.subtopics);
    setPrompts(mockData.prompts);
  }, []);

  const renderScreen = () => {
    switch (screen) {
      case "upload":
        return (<UploadScreen onNext={() => setScreen("form")} />);
      case "form":
        return (
          <PromptForm
            onBack={() => setScreen("upload")}
            onNext={() => setScreen("review")}
            topics={topics}
            subtopicsMap={subtopicsMap}
          />
        );
      case "review":
        return (
          <PromptReview
            onBack={() => setScreen("form")}
            onNext={() => setScreen("list")}
            prompt={prompts[0]}
          />
        );
      case "list":
        return <PromptList onBack={() => setScreen("review")} prompts={prompts} />;
      default:
        return null;
    }
  };

  return <div>{renderScreen()}</div>;
};

export default PromptManager;