import React, { useContext, useEffect, useState } from 'react';
import AddGroupModal from './AddGroupModal';
import CreateAugmentationModal from './CreateAugmentationModal';
import './AugmentationPanel.css';
import GroupMultiSelectDropdown from './GroupMultiSelectDropdown';
import { AuthContext } from "../../../../globals/AuthContext";
import { createNewGroup, getAugmentations } from '../../../../_services/genai_dataset.service';
const initialAugmentations = [
    { name: 'Text to Number', groups: ['Finance', 'Math'] },
    { name: 'Word Deletion', groups: ['Editorial'] },
    { name: 'Abbreviation', groups: ['Medical'] },
    { name: 'Paraphrasing', groups: ['Editorial', 'Marketing'] },
    { name: 'Verbose', groups: ['Legal'] },
    { name: 'Brevit', groups: ['Marketing', 'Speridian'] },
    { name: 'Lorem Ipsum X', groups: ['Legal'] },
    { name: 'Number to Word', groups: ['Finance', 'Math', 'New Group'] }
];


const AugmentationPanel = ({ data, updateSelectedAugmentations, datasetId }) => {
    // const { data } = props;
    // const defaultGroups = [
    //     "All",
    //     ...new Set(initialAugmentations.flatMap(aug => aug.groups))
    // ];
    const [groups, setGroups] = useState(['All']);
    const [augmentations, setAugmentations] = useState([]);
    const [selectedGroups, setSelectedGroups] = useState(['All']);
    const [selectedAugmentations, setSelectedAugmentations] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [showAddGroupModal, setShowAddGroupModal] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const ctx = useContext(AuthContext);
    useEffect(() => {

        if (data && Array.isArray(data) && data.length > 0) {
            const uniqueGroups = [
                ...new Set(data.flatMap(aug => aug.groups))];
            setGroups(uniqueGroups)
            const unique = new Map();
            for (const item of data) {
                const existing = unique.get(item.name);
                if (!existing) {
                    unique.set(item.name, item);
                } else if (existing.groups.includes("ALL") && !item.groups.includes("ALL")) {
                    // Prefer non-ALL over ALL
                    unique.set(item.name, item);
                }
                // Else, keep the existing one
            }
            const result = Array.from(unique.values())
            setAugmentations(result)
        }

    }, [data])
    const removeGroup = (groupToRemove) => {
        const updated = selectedGroups.filter(g => g !== groupToRemove);
        setSelectedGroups(updated.length ? updated : ['All']);
        setSelectedAugmentations([]);
        updateSelectedAugmentations([])
    };
    const handleAugmentationToggle = (name) => {
        setSelectedAugmentations(prev =>
            prev.includes(name)
                ? prev.filter(n => n !== name)
                : [...prev, name]
        );
        updateSelectedAugmentations(selectedAugmentations.includes(name)
        ? selectedAugmentations.filter(n => n !== name)
        : [...selectedAugmentations, name])
    };
    const getFilteredAugmentations = () => {
        const filtered = selectedGroups.includes('All')
            ? augmentations
            : augmentations.filter(aug => aug.groups.some(g => selectedGroups.includes(g)));
        return filtered.filter(aug =>
            aug.name? aug.name.toLowerCase().includes(searchTerm.toLowerCase()):"null"
        );
    };
    const handleAddGroupSubmit = ({ name, description }) => {
        setGroups(prev => [...prev, name]);
        const updated = augmentations.map(aug =>
            selectedAugmentations.includes(aug.name)
                ? { ...aug, groups: [...new Set([...aug.groups, name])] }
                : aug
        );
        // const augs = selectedAugmentations.map(item => item.name)
        const req = {
            "projectName": ctx.projectSubType,
            "group_name": name,
            "description": description,
            "augmentations": selectedAugmentations

        }
        createNewGroup(req)
        setAugmentations(updated);
        setSelectedAugmentations([]);
        updateSelectedAugmentations([])
        setSelectedGroups([name]);
        setShowAddGroupModal(false)
    };
    const handleCreateNewSave = (newAug) => {
        setAugmentations(prev => [
            ...prev,
            { name: newAug.name, groups: ['All'] }
        ]);
        setShowCreateModal(false);
    };
    return (
        <div className="augmentations-container">
            <div className="top-panel">
                <div className="left-section">
                    <label>Augmentations</label>
                    <GroupMultiSelectDropdown
                        options={groups}
                        selected={selectedGroups}
                        onApply={(newSelection) => {
                            setSelectedGroups(newSelection);
                            setSelectedAugmentations([]);
                            updateSelectedAugmentations([])
                        }}
                    />
                </div>
                <div className="right-section">
                    <input
                        type="text"
                        placeholder="Search here..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <button className="create-new" onClick={() => setShowCreateModal(true)}>
                        Create New
                    </button>
                </div>
            </div>
            {selectedGroups.length > 0 && selectedGroups[0] !== 'All' && (
                <div className="selected-groups">
                    {selectedGroups.filter(g => g !== 'All').map((group, idx) => (
                        <div className='selected-group-pills'>
                            <span key={idx} className="group-pill">
                                {group}
                            </span>
                            <span onClick={() => removeGroup(group)} className="close-btn">×</span>
                        </div>
                    ))}
                </div>)}
            <div className="augmentations-grid">
                {getFilteredAugmentations().map((aug, idx) => (
                    <label key={idx} className="checkbox-pill">
                        <input
                            type="checkbox"
                            checked={selectedAugmentations.includes(aug.name)}
                            onChange={() => handleAugmentationToggle(aug.name)}
                        />
                        {aug.name}
                    </label>
                ))}
            </div>
            {selectedAugmentations.length > 0 && (<div className='selected-group'>
                {selectedAugmentations.length > 0 && (
                    <div className="selected-items">
                        {selectedAugmentations.map((name, i) => (
                            <span key={i} className="selected-pill">
                                {name}
                                <button onClick={() => handleAugmentationToggle(name)}>×</button>
                            </span>
                        ))}
                    </div>
                )}
                {selectedAugmentations.length > 1 && (
                    <div className="add-group-panel">
                        <button className="add-group" onClick={() => setShowAddGroupModal(true)}>
                            Add Group
                        </button>
                    </div>
                )}
            </div>)}
            {showAddGroupModal && (
                <AddGroupModal
                    existingGroups={groups}
                    onClose={() => setShowAddGroupModal(false)}
                    onSubmit={handleAddGroupSubmit}
                />
            )}
            {showCreateModal && (
                <CreateAugmentationModal
                    onClose={() => setShowCreateModal(false)}
                    onSave={handleCreateNewSave}
                    datasetId={datasetId}
                    existingAugmentNames={augmentations.map(a => a.name)}
                />
            )}
        </div>
    );
};
export default AugmentationPanel;