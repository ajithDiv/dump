import React from 'react';

import {

    LineChart, Line, XAxis, YAxis, CartesianGrid,

    Tooltip, Legend, ResponsiveContainer

} from 'recharts';

const ChartComponent = ({ data, runs, colorMap }) => {

    return (
        <div style={{ width: '99%', height: 380 }}>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart

                    data={data}

                    margin={{ top: 20, right: 20, left: 40, bottom: 40 }}
                >
                    <CartesianGrid strokeDasharray="3 3" />

                    {/* X-axis with centered label */}
                    <XAxis

                        dataKey="Metric Name"

                        label={{

                            value: 'Executions',

                            position: 'insideBottom',

                            offset: -10,

                            dy: 5,

                            style: { textAnchor: 'middle', fontSize: 12 }

                        }}

                    />

                    {/* Y-axis with centered label */}
                    <YAxis

                        label={{

                            value: 'Record Count',

                            angle: -90,

                            position: 'insideLeft',

                            dx: 5,

                            style: { textAnchor: 'middle', fontSize: 12 }

                        }}

                    />
                    <Tooltip />

                    {/* Legend - top right, small font */}
                    <Legend

                        align="right"

                        verticalAlign="top"

                        iconType="line"

                        wrapperStyle={{

                            fontSize: 12,

                            paddingTop: '5px',

                            paddingRight: '10px'

                        }}

                    />

                    {/* Plot each run */}

                    {runs.map(run => (
                        <Line

                            key={run}

                            type="monotone"

                            dataKey={run}

                            stroke={colorMap[run]}

                            strokeWidth={2}

                            dot={{ r: 3 }}

                            activeDot={{ r: 5 }}

                        />

                    ))}
                </LineChart>
            </ResponsiveContainer>
        </div>

    );

};

export default ChartComponent;
