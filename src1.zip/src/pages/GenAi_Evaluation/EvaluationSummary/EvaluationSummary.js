import React, { useContext, useEffect } from "react";
import { useState } from "react";
import TelemetryMetrices from "../../../components/GenAi_Evaluation/TelemetryMetrices/TelemetryMetrices";
import PerformanceMetrics from "../../../components/GenAi_Evaluation/PerformanceMetrics/PerformanceMetrics";
import { useParams } from "react-router-dom";
import {
  getCoverageDetails,
  getEvaluationData,
} from "../../../_services/genai_evaluation.service";
import TelemetryDetails from "../../../components/GenAi_Evaluation/TelemetryDetails/TelemetryDetails";
import Insights from "../../../components/GenAi_Evaluation/Insights/Insights";
import { AuthContext } from "../../../globals/AuthContext";
import Coverage from "../../../components/GenAi_Evaluation/Coverage/Coverage";

const EvaluationSummary = () => {
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState("Telemetry Granular");
  const [evaluationData, setEvaluationData] = useState({
    evaluation: [],
    evaluation_records: [],
  });
  const [coverageDetails, setCoverageDetails] = useState([]);

  const ctx = useContext(AuthContext);

  let tabMenu =
    ctx.projectSubType === "SUM" || ctx.projectSubType === "CODEGEN"
      ? [
          "Execution Dashboard",
          "Telemetry Granular",
          "Telemetry Details",
          "Insights Failure",
          "Coverage",
        ]
      : [
          "Execution Dashboard",
          "Telemetry Granular",
          "Telemetry Details",
          "Insights",
        ];

  const handleTabSelection = (menu) => {
    setSelectedTab(menu);
  };
  const { id } = useParams();

  useEffect(() => {
    getEvaluationData(id).then((result) => {
      setLoading(false);
      setEvaluationData(result.output);
    });
  }, []);

  useEffect(() => {
    getCoverageDetails(id).then((result) => {
      setLoading(false);

      if (result?.output?.coverage) {
        setCoverageDetails(result.output.coverage);
      } else {
        setCoverageDetails([]);
      }
    });
  }, []);

  return (
    <div>
      <div
        style={{
          backgroundColor: "#FEF2FA",
          borderBottom: "1px solid #C8C4D9",
          color: "gray",
        }}
      >
        {tabMenu.map((menu) => (
          <h5
            style={{
              display: "inline-block",
              margin: "0",
              padding: "8px",
              borderRight: "1px solid #C8C4D9",
              color: selectedTab === menu ? "#4546D9" : "#434343",
              borderBottom: selectedTab === menu ? "2px solid #4546D9" : null,
              fontSize: "1rem",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => handleTabSelection(menu)}
          >
            {menu}
          </h5>
        ))}
      </div>

      <div style={{ padding: "1rem" }}>
        {selectedTab === "Telemetry Granular" && (
          <TelemetryMetrices
            loading={loading}
            evaluationData={evaluationData}
          />
        )}
        {selectedTab === "Execution Dashboard" && (
          <PerformanceMetrics
            loading={loading}
            evaluationData={evaluationData}
          />
        )}
        {selectedTab === "Telemetry Details" && (
          <TelemetryDetails loading={loading} evaluationData={evaluationData} />
        )}
        {selectedTab === "Insights Failure" && <Insights loading={loading} />}
        {selectedTab === "Coverage" && (
          <Coverage loading={loading} coverageDetails={coverageDetails} />
        )}
      </div>
    </div>
  );
};

export default EvaluationSummary;
