// loadingService.ts
let _setLoading = () => { };
export const setGlobalLoadingSetter = (fn) => {
    _setLoading = fn;
};
export const showLoader = () => _setLoading(true);
export const hideLoader = () => _setLoading(false);