import { authHeader, handleResponse } from '../_helpers';

export const projectService = {
    getAllProjects,
    createProject,
    getProjectDetails,
    gcpDataFilePath,
    getSpeechConfigurationDetailsAPI,
    deleteProject,
    updateProject,
    logout
};

function createProject(project) {
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
        body: project
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/user`, requestOptions)
        .then(handleResponse);
}

function gcpDataFilePath(projectName,gcpDataFile) {
    const formdata = new FormData();
    formdata.append('file', gcpDataFile);
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Authorization': authHeader()
         },
        body: formdata
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/createGcpDataFilePath/`+ projectName, requestOptions).then(handleResponse);
}

function updateProject(project) {
    const requestOptions = {
        method: 'PUT',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
        body: project
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/user`, requestOptions)
        .then(response => {
            if(response.status === 200) {
                return response;
            } else {
                return Promise.reject('Error while creating a project.');
            }
        })
}

function getAllProjects() {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project`, requestOptions).then(handleResponse);
}

function getProjectDetails(projectname) {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/name/`+ projectname, requestOptions).then(handleResponse);
}

function getSpeechConfigurationDetailsAPI(projectName) {
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/speechDetails/`+ projectName, requestOptions).then(handleResponse);
}

function deleteProject(projectname) {
    const requestOptions = {
        method: 'DELETE',
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/project/name/`+ projectname, requestOptions).then(handleResponse);
}

function logout() {
    localStorage.removeItem('user');
}

function handleResponse1(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logout();
                window.location.reload(true);
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.