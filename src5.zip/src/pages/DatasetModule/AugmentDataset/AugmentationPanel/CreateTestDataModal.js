import React, { useState } from 'react';
import PromptManager from '../../DatasetDetails/PromtManager/PromptManager';

import './AugmentationPanel.css';

const CreateTestDataModal = ({ existingGroups, onClose, onSubmit }) => {

    const [groupName, setGroupName] = useState('');

    const [description, setDescription] = useState('');

    const [errors, setErrors] = useState({});

    const validate = () => {

        const newErrors = {};

        if (!groupName.trim()) newErrors.groupName = 'Group name is required';

        else if (existingGroups.includes(groupName.trim()))

            newErrors.groupName = 'Group name already exists';

        if (!description.trim()) newErrors.description = 'Description is required';

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;

    };

    const handleSubmit = () => {

        if (validate()) {

            onSubmit({ name: groupName.trim(), description: description.trim() });

            setGroupName('');

            setDescription('');

        }

    };

    return (
        <div className="modal-overlay slide-in-right">
            <div className="modal wide">
                <h3>Create New Group</h3>
                <PromptManager></PromptManager>
            </div>
        </div>

    );

};

export default CreateTestDataModal;
