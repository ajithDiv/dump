import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  IconButton,
  InputLabel,
  ListItemText,
  MenuItem,
  Modal,
  OutlinedInput,
  Pagination,
  PaginationItem,
  Paper,
  Select,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import CloseIcon from "@mui/icons-material/Close";
import { DataGrid } from "@mui/x-data-grid";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import styles from "./AugmentDataset.module.css";
import {
  addAugmentations,
  generateAugmentations,
  getAugmentations,
  getAugmentationTypes,
  getDatasetById,
  getInputs,
} from "../../../_services/genai_dataset.service";
import { useParams } from "react-router-dom";
import { AuthContext } from "../../../globals/AuthContext";
import dummyP2I from "../../../assets/img/dummyP2I.png";
import { AugmentationData } from "../../../HardCodeData";
import { range } from "@mui/x-data-grid/internals";
import VisibilityIcon from "@mui/icons-material/Visibility";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import stars from "../../../assets/genaiIcons/stars.png";
import AugmentationPanel from "./AugmentationPanel/AugmentationPanel";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
      overflowX: "auto",
    },
  },
};

export const DisplayStringWithLineBreaks = ({ text }) => {
  const lines = text.split("\n");
  return (
    <div>
      {lines.map((line, index) => (
        <>
          <div style={{ paddingBottom: "0rem" }} key={index}>
            {line}
          </div>
          <br />
        </>
      ))}
    </div>
  );
};

export const DisplayHighlightedStringWithLineBreaks = ({
  text,
  highlight = [],
}) => {
  const lines = text.split("\n");
  if (highlight.length === 0) {
    return (
      <div>
        {lines.map((line, index) => (
          <div style={{ paddingBottom: "0.5rem" }} key={index}>
            {line}
          </div>
        ))}
      </div>
    );
  }

  let parts = []; // Array to hold segments of the text
  let lastIndex = 0; // Track the end of the last processed part

  const addPart = (start, end, color) => {
    if (start > lastIndex) {
      // Add unhighlighted part
      parts.push({
        text: text.slice(lastIndex, start),
        color: null,
      });
    }
    // Add highlighted part
    parts.push({ text: text.slice(start, end), color });
    lastIndex = end; // Update lastIndex to the end of this part
  };

  // const redHighlights = highlights.red || [];
  // const greenHighlights = highlights.green || [];

  // Combine and sort ranges
  const allHighlights = [
    // ...redHighlights.map((range) => ({ range, color: "#FFE0E0" })),
    // ...greenHighlights.map((range) => ({ range, color: "#ADEDEA" })),
    ...highlight.map((range) => ({ range, color: "#ADEDEA" })),
  ];
  allHighlights.sort((a, b) => a.range[0] - b.range[0]);

  // Process each highlight range
  allHighlights.forEach(({ range: [start, end], color }) => {
    addPart(start, end, color);
  });

  // Add any remaining unhighlighted text
  if (lastIndex < text.length) {
    parts.push({
      text: text.slice(lastIndex),
      color: null,
    });
  }

  // Convert parts to <span> elements
  return parts.map((part, index) => (
    <span key={index} style={{ backgroundColor: part.color }}>
      {part.text.split("\n").map((item, ind) => (
        <>
          {ind > 0 && (
            <>
              <br />
              <br />
            </>
          )}{" "}
          {item}{" "}
        </>
      ))}
    </span>
  ));
};

const AugmentDataset = (props) => {
  const [selectedPrompts, setSelectedPrompts] = useState([]);
  const [selectedAugmentations, setSelectedAugmentations] = useState([]);
  const [selectedAugmentationCategory, setSelectedAugmentationCategory] =
    useState("Prompt");
  const [augmentationListForCodeGen, setAugmentationListForCodeGen] = useState(
    []
  );
  const [generatedPrompts, setGeneratedPrompts] = useState([]);
  const [selectedGeneratedPrompts, setSelectedGeneratedPrompts] = useState([]);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [open, setOpen] = useState(false);
  const [modalPage, setModalPage] = useState(0);
  const [modalRowPage, setModalRowPage] = useState(5);
  const [show, setShow] = useState(false);
  const [inputs, setInputs] = useState([]);
  const [augmentations, setAugmentations] = useState([]);
  const [cusAugmentations, setCusAugmentations] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [snackOpen, setSnackOpen] = useState(false);
  const [files, setFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [openHighlight, setOpenHighlight] = useState(false);
  const [selectedAugmentedInput, setSelectedAugmentedInput] = useState("");
  const [highlight, setHighlight] = useState([]);
  const [compareView, setCompareView] = useState(false);
  const [currentData, setCurrentData] = useState({});

  const parameters = useParams();
  const ctx = useContext(AuthContext);

  const columns = [
    { field: "id", headerName: "ID", width: 50 },
    { field: "input", headerName: "Input", width: 350 },
    ctx.projectSubType === "P2I"
      ? {
        field: "augmentedInput",
        headerName: "Augmented Input",
        width: 350,
        height: 100,
        renderCell: (params) => <img src={params.value} alt={"dumP2I"} />,
      }
      : (ctx.projectSubType === "SUM" || ctx.projectSubType === "CODEGEN")
        ? {
          field: "augmentedInput",
          headerName: "Augmented Input",
          width: 350,
          height: 100,
          renderCell: (params) => (
            <Button
              size="small"
              endIcon={<VisibilityIcon />}
              variant="outlined"
              onClick={() => {
                setHighlight(params.row.range.blue);
                setSelectedAugmentedInput(params.value);
                setOpenHighlight(true);
              }}
              style={{ textDecoration: "underline" }}
            >
              View Output
            </Button>
          ),
        }
        : { field: "augmentedInput", headerName: "Augmented Input", width: 350 },
    { field: "augmentedType", headerName: "Augmented Type", width: 150 },
  ];

  const augmentationList =
    ctx.projectSubType !== "SUM"
      ? [
        "Text to Number",
        "Number to Word",
        "Word Deletion",
        "Abbreviation",
        "Brevity",
        "Language Synonyms Replacement",
        "Spelling Error",
        "Mutation",
        "Paraphrasing",
        "Paraphrasing(T)",
        "Date Change",
        "Homophones",
        "Verbose",
        "Taboo",
        "Backtranslate",
        "Mark for Adversarial Attack",
      ]
      : [
        "Shuffle",
        "Broken English",
        "Synonym Replacement",
        "Excited Tone",
        "Sad Tone",
        "Rude Tone",
        "Sarcastic Tone",
        "Paraphrase",
        "Verbosity",
        "Word to Number",
        "Brevity",
        "Non Lexical Fillers",
        "Alter Key Entities",
        "Number to Word",
        "Informal",
        "Short Duration Call",
        "Medium Duration Call",
        "Long Duration Call",
        "Multilingual",
        "String Repeat",
        "Slang",
        "Induce PII",
        "Induce Unethical",
        "Induce Toxicity",
        "Background Conversation Noise",
        "Induce Extreme Toxicity",
        "Induce Misogyny",
        "Induce Stereotype",
        "Induce Extreme Unethical",
        "Induce Insensitivity",
        "Induce Criminality",
        "Boston Dialect",
        "NYC Dialect",
        "Philly Baltimore Dialect",
        "Deep South Texas Dialect",
        "California Pnw Dialect"
      ];

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleModalChangePage = (event, newpage) => {
    setModalPage(newpage);
  };

  const handleModalChangeRowsPerPage = (event) => {
    setModalRowPage(parseInt(event.target.value, 10));
    setModalPage(0);
  };

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setSelectedPrompts((prev) => {
      // On autofill we get a stringified value.
      let newState = typeof value === "string" ? value.split(",") : value;

      if (newState.indexOf("All Inputs") > -1) {
        if (newState[newState.length - 1] === "All Inputs") {
          return ["All Inputs"];
        } else {
          let arr = [];
          inputs.map((item) => {
            if (newState.indexOf(item.question) === -1) {
              arr.push(item.question);
            }
          });
          return arr;
        }
      }
      if (newState.length === inputs.length) {
        return ["All Inputs"];
      }
      return newState;
    });
  };

  const handleFileChange = (event) => {
    const {
      target: { value },
    } = event;
    setSelectedFiles((prev) => {
      // On autofill we get a stringified value.
      let newState = typeof value === "string" ? value.split(",") : value;

      if (newState.indexOf("All Files") > -1) {
        if (newState[newState.length - 1] === "All Files") {
          return ["All Files"];
        } else {
          let arr = [];
          files.map((item) => {
            if (newState.indexOf(item.label) === -1) {
              arr.push(item.label);
            }
          });
          return arr;
        }
      }
      if (newState.length === files.length) {
        return ["All Files"];
      }
      return newState;
    });
  };

  const handleChangeAugmentations = (event) => {
    const {
      target: { value },
    } = event;
    setSelectedAugmentations(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
    setSelectedAugmentations((prev) => {
      return prev.filter((item) => item !== undefined);
    });
  };

  const handleChangeAugmentationCategory = (event) => {
    setSelectedAugmentationCategory(event.target.value);
  };

  const addGeneratedPrompt = (item, index) => {
    setSelectedGeneratedPrompts((prev) => {
      let copy = [...prev];
      copy.push(item.prompt);
      return copy;
    });
    setGeneratedPrompts((prev) => {
      let copy = [...prev];
      copy[index].selected = true;
      return copy;
    });
  };

  const removeGeneratedPrompt = (item, index) => {
    setSelectedGeneratedPrompts((prev) =>
      prev.filter((val, ind) => val !== item.prompt)
    );
    setGeneratedPrompts((prev) => {
      let copy = prev;
      copy[index].selected = false;
      return copy;
    });
  };

  const removeSelectedPrompt = (item) => {
    setSelectedGeneratedPrompts((prev) =>
      prev.filter((val, ind) => val !== item)
    );
    setGeneratedPrompts((prev) => {
      let copy = [...prev];
      copy.map((val) => {
        if (val.prompt === item) {
          val.selected = false;
        }
        return;
      });
      return copy;
    });
  };

  const toggleModal = () => {
    setOpen((prev) => !prev);
  };

  const generateInputAugmentations = () => {
    // if (ctx.projectSubType === "SUM") {
    //   setGeneratedPrompts(
    //     AugmentationData.augmentations.map((item, index) => {
    //       item.id = index + 1;
    //       return item;
    //     })
    //   );
    //   setShow(true);
    //   return;
    // }
    let arr = [];
    const techniques = [];
    const custom_metrics = [];
    for (const item of selectedAugmentations) {
      if (cusAugmentations.includes(item)) {
        custom_metrics.push(item)
      } else {
        techniques.push(item)
      }
    }

    inputs.map((item) => {
      if (
        selectedPrompts.indexOf(item.question) > -1 ||
        selectedPrompts.indexOf("All Inputs") > -1
      ) {
        arr.push(item.question);
      }
    });
    let data = {
      inputs: arr,
      techniques: techniques,
      flow_type: "RAG",
      datasetId: parameters.id,
      custom_metrics: custom_metrics,
      custom: custom_metrics.length > 0 ? true : false,
      projectType: ctx.projectSubType,
    };

    if (ctx.projectSubType === "CODEGEN") {
      data.augmentationCategory = selectedAugmentationCategory;
    }

    if (props.projectType === "NON-RAG") {
      let arr = [];
      files.map((item) => {
        if (
          selectedFiles.indexOf(item.label) > -1 ||
          selectedFiles.indexOf("All Files") > -1
        ) {
          arr.push(item.value);
        }
      });


      data = {
        inputs: arr,
        techniques: techniques,
        flow_type: "NON-RAG",
        datasetId: parameters.id,
        custom: custom_metrics.length > 0 ? true : false,
        custom_metrics: custom_metrics,
        projectType: ctx.projectSubType,
      };
    }
    setLoading(true);
    generateAugmentations(data).then((result) => {
      const arr1 = result.augmentations.map((item, index) => {
        item.id = index + 1;
        return item;
      })
      const arr2 = result.customAugmentations.map((item, index) => {
        item.id = arr1.length + index + 1;
        return item;
      })
      // console.log([...arr1, ...arr2])
      setGeneratedPrompts(
        [...arr1, ...arr2]
      );
      setShow(true);
      setLoading(false);
    });
  };

  const pushAugmentations = () => {
    let data = [];
    if (props.projectType === "RAG") {
      if (ctx.projectSubType === "CODEGEN") {
        selectedRows.map((row) => {
          let flag = true;
          inputs.map((inp) => {
            if (selectedAugmentationCategory === "Code") {
              if (flag && inp.answer === row.input) {
                let temp = { ...inp };
                delete temp["_id"];
                temp["answer"] = row.augmentedInput;
                temp["source"] = "Augmented";
                temp["augmentedType"] = row.augmentedType;
                data.push(temp);
                flag = false;
              }
            } else {
              if (flag && inp.question === row.input) {
                let temp = { ...inp };
                delete temp["_id"];
                temp["answer"] = row.augmentedInput;
                temp["source"] = "Augmented";
                temp["augmentedType"] = row.augmentedType;
                data.push(temp);
                flag = false;
              }
            }
          });
        });
      } else {
        selectedRows.map((row) => {
          let flag = true;
          inputs.map((inp) => {
            if (flag && inp.question === row.input) {
              let temp = { ...inp };
              delete temp["_id"];
              temp["question"] = row.augmentedInput;
              temp["source"] = "Augmented";
              temp["augmentedType"] = row.augmentedType;
              data.push(temp);
              flag = false;
            }
          });
        });
      }
    } else {
      selectedRows.map((row) => {
        data.push({
          question: row.augmentedInput,
          source: "Augmented",
          augmentedType: row.augmentedType,
          answer: "",
          context: [],
          datasetId: parameters.id,
        });
      });
    }

    addAugmentations({
      augmentations: data,
      projectType: ctx.projectSubType,
    }).then((result) => {
      setSnackOpen(true);
    });
  };

  const getHighlightedText = () => {
    let parts = []; // Array to hold segments of the text
    let lastIndex = 0; // Track the end of the last processed part

    const addPart = (start, end, color) => {
      if (start > lastIndex) {
        // Add unhighlighted part
        parts.push({
          text: selectedAugmentedInput.slice(lastIndex, start),
          color: null,
        });
      }
      // Add highlighted part
      parts.push({ text: selectedAugmentedInput.slice(start, end), color });
      lastIndex = end; // Update lastIndex to the end of this part
    };

    // const redHighlights = highlights.red || [];
    // const greenHighlights = highlights.green || [];

    // Combine and sort ranges
    const allHighlights = [
      // ...redHighlights.map((range) => ({ range, color: "#FFE0E0" })),
      // ...greenHighlights.map((range) => ({ range, color: "#ADEDEA" })),
      ...highlight.map((range) => ({ range, color: "#ADEDEA" })),
    ];
    allHighlights.sort((a, b) => a.range[0] - b.range[0]);

    // Process each highlight range
    allHighlights.forEach(({ range: [start, end], color }) => {
      addPart(start, end, color);
    });

    // Add any remaining unhighlighted text
    if (lastIndex < selectedAugmentedInput.length) {
      parts.push({
        text: selectedAugmentedInput.slice(lastIndex),
        color: null,
      });
    }

    // Convert parts to <span> elements
    return parts.map((part, index) => (
      <span key={index} style={{ backgroundColor: part.color }}>
        {part.text}
      </span>
    ));
  };

  useEffect(() => {
    if (props.projectType === "RAG") {
      getInputs(parameters.id, ctx.projectSubType).then((result) => {
        setInputs(result.inputs);
        // if (ctx.projectSubType === "SUM") {
        //   let unique = new Set();
        //   AugmentationData.augmentations.map((item) => {
        //     unique.add(item.input);
        //   });
        //   setInputs([...unique].map((item) => ({ question: item })));
        // }
      });
      getAugmentations(ctx.projectSubType).then((result) => {
        let allAug = result.augmentation_details[0].all_augmentations.map(item => ({
          "name": item,
          groups: ["All"]
        }));
        setCusAugmentations(result.augmentation_details[0].custom_augmentations)
        setAugmentations(result.augmentation_details[0].augmentations.concat(allAug));
      })
    } else {
      getDatasetById(parameters.id).then((result) => {
        let arr = [];
        result.data.file_metadata.map((item) => {
          arr.push({
            label: item.file_name,
            value: item.file_path,
          });
        });
        setFiles(arr);
      });
    }
  }, []);

  // useEffect(() => {
  //   if (ctx.projectSubType === "CODEGEN") {
  //     setSelectedAugmentations([]);
  //     getAugmentationTypes(
  //       selectedAugmentationCategory.toLocaleLowerCase(),
  //       ctx.projectSubType
  //     ).then((result) => {
  //       setAugmentationListForCodeGen(result.augmentTypes);
  //     });
  // setAugmentationListForCodeGen(
  //   selectedAugmentationCategory === "Code"
  //     ? [
  //         {
  //           augType: "Syntax-Level Augmentations",
  //           subAugType: [
  //             "Introduce Special Characters",
  //             "Change Function/Variable Case",
  //             "Induce Whitespaces",
  //             "Missing Semicolons/Brackets",
  //             "Use Reserved Keywords as Function names",
  //           ],
  //         },
  //         {
  //           augType: "Security and Performance Augmentations",
  //           subAugType: [
  //             "Hardcode Sensitive Data",
  //             "Introduce Infinite Loops",
  //           ],
  //         },
  //         {
  //           augType: "Structural-Level Augmentations",
  //           subAugType: [
  //             "Rearrange Code Blocks",
  //             "Add Dead Code",
  //             "Comment Out Critical Code",
  //             "Duplicate Code Snippets",
  //           ],
  //         },
  //         {
  //           augType: "Code Generation Augmentation",
  //           subAugType: [
  //             "Remove one complete file/Remove one section of file",
  //           ],
  //         },
  //         {
  //           augType: "Dependency-Level Augmentations",
  //           subAugType: [
  //             "Change Library Versions",
  //             "Change/Break Import",
  //             "Introduce Unused Dependencies",
  //           ],
  //         },
  //         {
  //           augType: "Logical-Level Augmentations",
  //           subAugType: [
  //             "Remove Return Statements",
  //             "Reverse Logic: Change > to < or == to !=",
  //           ],
  //         },
  //         {
  //           augType: "Multi-Programming Language Augmentations",
  //           subAugType: [
  //             "Combine or embed snippets from different programming languages in one file",
  //           ],
  //         },
  //       ]
  //     : [
  //         "Simple",
  //         "Medium",
  //         "Complex",
  //         "Paraphrasing",
  //         "Synonym replacement",
  //         "Brevity",
  //         "Verbosity",
  //         "Broken English",
  //         "Multilingual",
  //         "Rude Tone",
  //         "Sarcastic tone",
  //         "Word to Number",
  //         "Number to Word",
  //         "Alter Key Entities",
  //         "String Repeat",
  //         "Case Sensitivity",
  //         "Language Augmentations",
  //       ]
  // );
  // }
  // }, [selectedAugmentationCategory]);

  return (
    <div style={{ margin: "1rem" }}>
      <Snackbar
        open={snackOpen}
        autoHideDuration={6000}
        onClose={() => setSnackOpen(false)}
        message="Augmentations pushed to dataset successfully."
      />
      <Paper style={{ padding: "1rem" }}>
        <Stack gap={"1rem"}>
          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Select Inputs </FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, width: 700 }}>
              {props.projectType === "RAG" ? (
                <Select
                  fullWidth
                  displayEmpty
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  multiple
                  value={selectedPrompts}
                  onChange={handleChange}
                  // input={<OutlinedInput label="Select Inputs" />}
                  renderValue={(selected) => {
                    if (selected.length === 0) {
                      return <em>Select Inputs</em>;
                    }
                    return (
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {selected.map((value) => (
                          <Chip key={value} label={value} />
                        ))}
                      </Box>
                    );
                  }}
                  MenuProps={MenuProps}
                >
                  <MenuItem value="All Inputs">
                    <Checkbox
                      checked={selectedPrompts.indexOf("All Inputs") > -1}
                    />
                    <ListItemText primary={"All Inputs"} />
                  </MenuItem>
                  {inputs.map((item) => (
                    <MenuItem key={item.question} value={item.question}>
                      <Checkbox
                        checked={
                          selectedPrompts.indexOf(item.question) > -1 ||
                          selectedPrompts.indexOf("All Inputs") > -1
                        }
                      />
                      <ListItemText
                        primary={
                          (ctx.projectSubType === "SUM"
                            ? item.identifier + " - "
                            : "") + item.question
                        }
                      />
                    </MenuItem>
                  ))}
                </Select>
              ) : (
                <Select
                  fullWidth
                  displayEmpty
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  multiple
                  value={selectedFiles}
                  onChange={handleFileChange}
                  // input={<OutlinedInput label="Select Inputs" />}
                  renderValue={(selected) => {
                    if (selected.length === 0) {
                      return <em>Select Files</em>;
                    }
                    return (
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {selected.map((value) => (
                          <Chip key={value} label={value} />
                        ))}
                      </Box>
                    );
                  }}
                  MenuProps={MenuProps}
                >
                  <MenuItem value="All Files">
                    <Checkbox
                      checked={selectedFiles.indexOf("All Files") > -1}
                    />
                    <ListItemText primary={"All Files"} />
                  </MenuItem>
                  {files.map((item) => (
                    <MenuItem key={item.value} value={item.label}>
                      <Checkbox
                        checked={
                          selectedFiles.indexOf(item.label) > -1 ||
                          selectedFiles.indexOf("All Files") > -1
                        }
                      />
                      <ListItemText primary={item.label} />
                    </MenuItem>
                  ))}
                </Select>
              )}
            </FormControl>
          </Stack>

          {ctx.projectSubType === "CODEGEN" && (
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>
                Select Augmentation Category
              </FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: 700 }}>
                <Select
                  fullWidth
                  displayEmpty
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  value={selectedAugmentationCategory}
                  onChange={handleChangeAugmentationCategory}
                  MenuProps={MenuProps}
                >
                  {["Code", "Prompt"].map((name) => (
                    <MenuItem key={name} value={name}>
                      <ListItemText primary={name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>
          )}

          {ctx.projectSubType === "CODEGEN" ? (
            <Stack direction="row" alignItems="center" spacing={2}>
              <FormLabel sx={{ width: "10rem" }}>
                Select Augmentations{" "}
              </FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: 700 }}>
                <Select
                  fullWidth
                  displayEmpty
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  multiple
                  value={selectedAugmentations}
                  onChange={handleChangeAugmentations}
                  renderValue={(selected) => {
                    if (selected && selected.length > 0) {
                      return (
                        <Box
                          sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}
                        >
                          {selected.map((value) => (
                            <Chip key={value} label={value} />
                          ))}
                        </Box>
                      );
                    } else {
                      return <div>Select Augmentations</div>; // Placeholder text
                    }
                  }}
                  MenuProps={MenuProps}
                >
                  {selectedAugmentationCategory === "Prompt" &&
                    augmentationListForCodeGen.length > 0
                    ? augmentationListForCodeGen.map((name) => (
                      <MenuItem key={name} value={name}>
                        <Checkbox
                          checked={selectedAugmentations.indexOf(name) > -1}
                        />
                        <ListItemText primary={name} />
                      </MenuItem>
                    ))
                    : null}

                  {selectedAugmentationCategory === "Code" &&
                    augmentationListForCodeGen.length > 0
                    ? augmentationListForCodeGen.map((augTypeObj) => (
                      <Accordion key={augTypeObj.augType}>
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          id={`panel-${augTypeObj.augType}`}
                        >
                          {augTypeObj.augType}
                        </AccordionSummary>
                        <AccordionDetails>
                          <FormGroup>
                            {augTypeObj.subAugType &&
                              augTypeObj.subAugType.length > 0 ? (
                              augTypeObj.subAugType.map((subAug) => (
                                <FormControlLabel
                                  key={subAug}
                                  control={
                                    <Checkbox
                                      checked={selectedAugmentations.includes(
                                        subAug
                                      )}
                                      onChange={(event) => {
                                        const newSelection = [
                                          ...selectedAugmentations,
                                        ];
                                        if (event.target.checked) {
                                          newSelection.push(subAug); // Add if checked
                                        } else {
                                          const index =
                                            newSelection.indexOf(subAug);
                                          newSelection.splice(index, 1); // Remove if unchecked
                                        }
                                        setSelectedAugmentations(
                                          newSelection
                                        );
                                      }}
                                      value={subAug}
                                    />
                                  }
                                  label={subAug}
                                />
                              ))
                            ) : (
                              <div>No Sub-Augmentations Available</div>
                            )}
                          </FormGroup>
                        </AccordionDetails>
                      </Accordion>
                    ))
                    : null}
                </Select>
              </FormControl>
            </Stack>
          ) : (
            <Stack direction="row" alignItems="center" spacing={2}>
              {/* <FormLabel sx={{ width: "10rem" }}>
                Select Augmentations{" "}
              </FormLabel>
              <FormLabel>:</FormLabel>
              <FormControl sx={{ m: 1, width: 700 }}>
                <Select
                  fullWidth
                  displayEmpty
                  labelId="demo-multiple-checkbox-label"
                  id="demo-multiple-checkbox"
                  multiple
                  value={selectedAugmentations}
                  onChange={handleChangeAugmentations}
                  renderValue={(selected) => {
                    return (
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {selected.map((value) => (
                          <Chip key={value} label={value} />
                        ))}
                      </Box>
                    );
                  }}
                  MenuProps={MenuProps}
                >
                  {augmentationList.map((name) => (
                    <MenuItem key={name} value={name}>
                      <Checkbox
                        checked={selectedAugmentations.indexOf(name) > -1}
                      />
                      <ListItemText primary={name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl> */}

              {
                (augmentations && augmentations.length > 0) &&
                <AugmentationPanel
                  updateSelectedAugmentations={(augs) => setSelectedAugmentations(augs)}
                  data={augmentations} 
                  datasetId={props.datasetId}/>
              }
            </Stack>
          )}

          <Button
            sx={{
              margin: "1rem 40%",
              width: "20%",
              backgroundColor: "#4546D9",
            }}
            variant="contained"
            onClick={generateInputAugmentations}
            disabled={loading}
          >
            Generate Inputs
          </Button>

          {loading && (
            <div style={{ textAlign: "center", verticalAlign: "middle" }}>
              {" "}
              Augmentations is in progress... <CircularProgress size={20} />
            </div>
          )}

          {show && !loading && (
            <>
              {(ctx.projectSubType === "SUM" ||
                ctx.projectSubType === "CODEGEN") && (
                  <Stack direction={"row-reverse"}>
                    <Paper
                      style={{ padding: "0.25rem", backgroundColor: "#ECECEE" }}
                    >
                      <Button
                        variant={compareView ? "text" : "contained"}
                        // endIcon={<CompareArrowsIcon />}
                        onClick={() => {
                          setCurrentData(generatedPrompts[0]);
                          setCompareView((prev) => !prev);
                        }}
                      >
                        Raw
                      </Button>
                      <Button
                        variant={!compareView ? "text" : "contained"}
                        // style={{backgroundColor: "white"}}
                        // endIcon={<CompareArrowsIcon />}
                        onClick={() => {
                          setCurrentData(generatedPrompts[0]);
                          setCompareView((prev) => !prev);
                        }}
                      >
                        Highlight
                      </Button>
                    </Paper>
                  </Stack>
                )}

              {!compareView && (
                <>
                  <DataGrid
                    rows={generatedPrompts}
                    columns={columns}
                    initialState={{
                      pagination: {
                        paginationModel: { page: 0, pageSize: 5 },
                      },
                    }}
                    pageSizeOptions={[5, 10]}
                    checkboxSelection
                    onRowSelectionModelChange={(ids) => {
                      const selectedIDs = new Set(ids);
                      const selectedRows = generatedPrompts.filter((row) =>
                        selectedIDs.has(row.id)
                      );
                      setSelectedRows(selectedRows);
                    }}
                  />
                  {/* <Button
                sx={{ margin: "1rem 0 1rem 65%", width: "35%" }}
                variant="outlined"
                onClick={toggleModal}
              >
                Selected Generated Inputs : {selectedGeneratedPrompts.length}
              </Button> */}
                  {/* <TableContainer component={Paper}>
                <Table aria-label="Material-UI Table">
                  <TableHead sx={{ background: "#111270", color: "#fff" }}>
                    <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        <strong>S No.</strong>
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        <strong>Generated Inputs</strong>
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        <strong>Action</strong>
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  {loading === true ? (
                    <div style={{ margin: "2rem 40%" }}>
                      <h3>Loading...</h3>
                    </div>
                  ) : generatedPrompts.length === 0 ? (
                    <>
                      <div style={{ margin: "2rem 40%" }}>
                        <h3>No Data Available</h3>
                      </div>
                    </>
                  ) : (
                    <TableBody>
                      {generatedPrompts
                        .slice(page * rowPage, page * rowPage + rowPage)
                        .map((item, index) => {
                          const uniqueRowNumber = page * rowPage + index + 1;
                          return (
                            <TableRow
                              key={index}
                              style={
                                index % 2
                                  ? { background: "#F6F6F6" }
                                  : { background: "white" }
                              }
                            >
                              <TableCell>{uniqueRowNumber}</TableCell>
                              <TableCell>{item.prompt}</TableCell>
                              <TableCell>
                                <IconButton
                                  onClick={() => {
                                    item.selected
                                      ? removeGeneratedPrompt(
                                          item,
                                          uniqueRowNumber - 1
                                        )
                                      : addGeneratedPrompt(
                                          item,
                                          uniqueRowNumber - 1
                                        );
                                  }}
                                >
                                  {item.selected ? <RemoveIcon /> : <AddIcon />}
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </TableBody>
                  )}
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={generatedPrompts.length}
                rowsPerPage={rowPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              /> */}
                  <Button
                    style={{ width: "15rem", margin: "0 auto" }}
                    variant="contained"
                    onClick={pushAugmentations}
                  >
                    Push to Dataset
                  </Button>
                </>
              )}
              {compareView && (
                <Paper>
                  <Stack
                    padding="0.5rem"
                    direction="column"
                    height="25rem"
                    overflow="scroll"
                  >
                    <Stack
                      direction="row"
                      alignItems="center"
                      borderBottom="1px solid #A5A7B4"
                    >
                      {/* <Checkbox  onChange={(e) => {
                      if(e.target.checked) {
                        setSelectedRows(prev => [...prev, {...currentData}])
                      } else {
                        setSelectedRows(prev => prev.filter( (row) => row.id!==currentData.id))
                      }
                    }}/> */}
                      <strong style={{ fontSize: "1.25rem" }}>
                        {currentData.id}.{currentData.augmentedType}
                      </strong>
                    </Stack>
                    <Stack direction="row">
                      <Stack
                        width="50%"
                        padding="0.5rem"
                        borderRight="1px solid black"
                        bgcolor="#F6FCFF"
                      >
                        <strong style={{ fontSize: "1rem" }}>Input</strong>
                        <div style={{ marginTop: "0.5rem" }}>
                          <DisplayStringWithLineBreaks
                            text={currentData.input}
                          />
                        </div>
                      </Stack>
                      <Stack
                        width="50%"
                        padding="0.5rem"
                        borderLeft="1px solid black"
                        bgcolor="#EEFCFF"
                      >
                        <Stack direction="row">
                          <img src={stars} style={{ width: "1rem" }} />
                          <strong
                            style={{ fontSize: "1rem", color: "#00B4BF" }}
                          >
                            Augmented Input
                          </strong>
                        </Stack>
                        <div style={{ marginTop: "0.5rem" }}>
                          <DisplayHighlightedStringWithLineBreaks
                            text={currentData.augmentedInput}
                            highlight={currentData.range.blue}
                          />
                        </div>
                      </Stack>
                    </Stack>
                    <Stack
                      alignItems="center"
                      justifyContent="center"
                      marginTop="1rem"
                    >
                      <Pagination
                        page={currentData.id}
                        count={generatedPrompts.length}
                        variant="outlined"
                        shape="rounded"
                        color="primary"
                        onChange={(e, val) => {
                          setCurrentData(generatedPrompts[val - 1]);
                        }}
                        renderItem={(item) => (
                          <PaginationItem
                            slots={{
                              previous: ArrowBackIcon,
                              next: ArrowForwardIcon,
                            }}
                            {...item}
                          />
                        )}
                      />
                    </Stack>
                  </Stack>
                </Paper>
              )}
            </>
          )}

          {ctx.projectSubType === "P2I" && (
            <>
              <DataGrid
                rows={[
                  {
                    id: 1,
                    input: "Prompt",
                    augmentedInput: { dummyP2I },
                    augmentedType: "Augmentation",
                  },
                ]}
                columns={columns}
                initialState={{
                  pagination: {
                    paginationModel: { page: 0, pageSize: 5 },
                  },
                }}
                pageSizeOptions={[5, 10]}
                checkboxSelection
                onRowSelectionModelChange={(ids) => {
                  const selectedIDs = new Set(ids);
                  const selectedRows = [
                    {
                      id: 1,
                      input: "Prompt",
                      augmentedInput: { dummyP2I },
                      augmentedType: "Augmentation",
                    },
                  ].filter((row) => selectedIDs.has(row.id));
                  setSelectedRows(selectedRows);
                }}
              />

              <Button
                style={{ width: "15rem", margin: "0 auto" }}
                variant="contained"
                onClick={pushAugmentations}
              >
                Push to Dataset
              </Button>
            </>
          )}
        </Stack>
      </Paper>

      <Modal
        open={open}
        onClose={toggleModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper elevation={3} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Selected Generated Inputs
            </Typography>
            <IconButton onClick={toggleModal}>
              {" "}
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <TableContainer component={Paper}>
              <Table aria-label="Material-UI Table">
                <TableHead sx={{ background: "#111270", color: "#fff" }}>
                  <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>S No.</strong>
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Selected Inputs</strong>
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Action</strong>
                    </TableCell>
                  </TableRow>
                </TableHead>
                {loading === true ? (
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={3}>
                        <Stack
                          width="100%"
                          direction="row"
                          justifyContent="center"
                        >
                          <CircularProgress />
                        </Stack>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                ) : generatedPrompts.length === 0 ? (
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={3}>
                        <Stack
                          width="100%"
                          direction="row"
                          justifyContent="center"
                        >
                          No Data Available
                        </Stack>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                ) : (
                  <TableBody>
                    {selectedGeneratedPrompts
                      .slice(page * rowPage, page * rowPage + rowPage)
                      .map((item, index) => {
                        const uniqueRowNumber = page * rowPage + index + 1;
                        return (
                          <TableRow
                            key={index}
                            style={
                              index % 2
                                ? { background: "#F6F6F6" }
                                : { background: "white" }
                            }
                          >
                            <TableCell>{uniqueRowNumber}</TableCell>
                            {/* <TableCell>{row.description}</TableCell> */}
                            <TableCell>{item}</TableCell>
                            <TableCell>
                              <IconButton
                                onClick={() => removeSelectedPrompt(item)}
                              >
                                <RemoveIcon />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                )}
              </Table>
            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={selectedGeneratedPrompts.length}
              rowsPerPage={modalRowPage}
              page={modalPage}
              onPageChange={handleModalChangePage}
              onRowsPerPageChange={handleModalChangeRowsPerPage}
            />
          </div>
          {/* <div className={styles.modalFooter}>
            <Button centerRipple variant="contained" mar>
              Create
            </Button>
          </div> */}
        </Box>
      </Modal>

      <Modal
        open={openHighlight}
        onClose={() => setOpenHighlight((prev) => !prev)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            p: 2,
            borderRadius: "1rem",
          }}
        >
          <DisplayHighlightedStringWithLineBreaks
            text={selectedAugmentedInput}
            highlight={highlight}
          />
        </Box>
      </Modal>
    </div>
  );
};

export default AugmentDataset;
