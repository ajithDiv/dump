import React, { useState } from "react";
import "./PromptReview.css";

const PromptReview = ({ onNext, onBack }) => {
  const [prompt, setPrompt] = useState(
    "Generate a test data call conversation between a travel agency flight booking agent and a customer on the topic 'Changes & Cancellations' and subtopic 'Cancellation Fees & Waivers'. The conversation should simulate a realistic phone call where the customer requests cancellation of a flight and seeks a waiver of cancellation charges due to a valid reason such as a medical emergency. The agent should show empathy, validate booking details, explain waiver policies, and confirm final resolution. Format output as a turn-by-turn dialog with speaker tags (Agent/Customer) and natural language utterances."
  );

  return (
    <div className="review-wrapper">
      <div className="review-card">
        <div className="review-left">
          <h3>Prompt Details</h3>
          <div>
            <label>Topic</label>
            <p><strong> Changes & Cancellations</strong>
            </p>
          </div>
          <div>
            <label>Subtopic:</label>
            <p>
              <strong> Cancellation Fees & Waivers</strong>
            </p>
          </div>
          <div>
            <label>Token Limit:</label>
            <p>
              <strong>  0 - 100</strong>
            </p>
          </div>
          <div>
            <label>Prompts:</label>
            <p>
              <strong>1</strong>
            </p>
          </div>
          <div>
            <label>Keywords:</label>
            <div className="keywords">
              <span className="keyword">Keyword 01</span>
              <span className="keyword">Keyword 02</span>
              <span className="keyword">Keyword 03</span>
            </div>
          </div>
        </div>

        <div className="review-right">
          <h3>Generated Prompt</h3>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="prompt-box"
          />
        </div>
      </div>

      <div className="footer-row">
        <button className="back-btn" onClick={onBack}>← Back to Form</button>
        <button className="generate-btn" onClick={onNext}>Generate Datasets</button>
      </div>
    </div>
  );
};

export default PromptReview;