import React, { useState } from "react";
import "./UploadScreen.css";

const UploadScreen = ({ onNext }) => {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedFile(file);
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setUploadProgress(progress);
        if (progress >= 75) clearInterval(interval);
      }, 100);
    }
  };

  return (
    <div className="upload-screen">
      <div className="upload-card">
        <div className="radio-section">
          <div className="radio-option disabled">
            <input type="radio" disabled />
            <label>Generate Input</label>
            <p>Reference site about Lorem Ipsum, giving information on its origins</p>
          </div>
          <div className="radio-option selected">
            <input type="radio" checked readOnly />
            <label>Upload Curated Dataset</label>
            <p>Reference site about Lorem Ipsum, giving information on its origins</p>
          </div>
        </div>

        <div className="upload-area">
          <div className="upload-box">
            <label htmlFor="fileInput" className="drop-zone">
              <div className="icon">📁</div>
              <p>Drag and drop a file or <span className="browse">Browse</span></p>
              <p className="limit">Max upload file size 10mb</p>
            </label>
            <input type="file" id="fileInput" onChange={handleFileChange} hidden />
          </div>

          {uploadedFile && (
            <div className="file-progress">
              <div className="file-name">{uploadedFile.name}</div>
              <div className="progress-bar">
                <div className="progress" style={{ width: uploadProgress + "%" }}></div>
              </div>
              <div className="progress-text">{uploadProgress}%</div>
            </div>
          )}
        </div>

        <div className="btn-container">
          <button className="generate-btn" onClick={onNext}>Generate Prompts</button>
        </div>
      </div>
    </div>
  );
};

export default UploadScreen;