import React, { useEffect, useState } from "react";
import {
    MenuItem,
    Select,
    InputLabel,
    FormControl,
    OutlinedInput,
    Checkbox,
    ListItemText,
    Box,
    Grid,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow
} from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";
// import data from "./data.json"; // your sample JSON placed here

const CompareDashBoard = ({ data }) => {
    const [datasets, setDatasets] = useState([]);
    const [selectedDataset, setSelectedDataset] = useState("");
    const [configs, setConfigs] = useState([]);
    const [selectedConfig, setSelectedConfig] = useState("");
    const [runs, setRuns] = useState([]);
    const [selectedRuns, setSelectedRuns] = useState([]);
    const [metrics, setMetrics] = useState([]);
    const [selectedMetrics, setSelectedMetrics] = useState([]);

    // Load initial datasets
    useEffect(() => {
        const uniqueDatasets = [...new Set(data.map((d) => d.datasetName))];
        setDatasets(uniqueDatasets);
    }, []);

    // Update configs when dataset changes
    useEffect(() => {
        const filteredConfigs = data
            .filter((d) => d.datasetName === selectedDataset)
            .map((d) => d.configurationName);
        setConfigs([...new Set(filteredConfigs)]);
        setSelectedConfig("");
        setSelectedRuns([]);
        setSelectedMetrics([]);
    }, [selectedDataset]);

    // Update runs when config changes
    useEffect(() => {
        const filteredRuns = data.filter(
            (d) =>
                d.datasetName === selectedDataset &&
                d.configurationName === selectedConfig
        );
        const names = filteredRuns.map((d) => d.run_name).filter(Boolean);
        setRuns(names);
        setSelectedRuns([]);
        setSelectedMetrics([]);
    }, [selectedConfig]);

    // Update metrics when run selection changes
    useEffect(() => {
        const selectedRunObjs = data.filter(
            (d, i) =>
                d.datasetName === selectedDataset &&
                d.configurationName === selectedConfig &&
                (selectedRuns.includes(d.run_name) || selectedRuns.includes(`Run-${i + 1}`))
        );
        const allMetrics = new Set();
        selectedRunObjs.forEach((run) => {
            run.evaluation_metrics_status?.forEach((m) => allMetrics.add(m.metric));
        });
        setMetrics([...allMetrics]);
    }, [selectedRuns]);

    // Get Graph data per run
    const getChartDataForRun = (runLabel) => {

        const index = runs.indexOf(runLabel);
        const record = data.find(
            (_, i) =>
                _.datasetName === selectedDataset &&
                _.configurationName === selectedConfig &&
                _.run_name?.trim().toLowerCase() === runLabel.trim().toLowerCase()
        );
        if (!record) return [];

        return selectedMetrics.map((metric) => {
            const found = record.evaluation_metrics_status?.find((m) => m.metric === metric);
            return {
                metric,
                Passed: found?.["Total Passed"] || 0,
                Failed: found?.["Total Failed"] || 0
            };
        });
    };


    const getStackedChartData = () => {
        const result = [];
        selectedMetrics.forEach((metric) => {
            const entry = { metric };
            selectedRuns.forEach((run) => {
                const record = data.find(
                    (d) =>
                        d.datasetName === selectedDataset &&
                        d.configurationName === selectedConfig &&
                        d.run_name?.trim().toLowerCase() === run.trim().toLowerCase()
                );
                const found = record?.evaluation_metrics_status?.find((m) => m.metric === metric);
                entry[`${run}_Passed`] = found?.["Total Passed"] || 0;
                entry[`${run}_Failed`] = found?.["Total Failed"] || 0;
            });
            result.push(entry);
        });
        return result;
    };


    // Table Rows
    const tableRows = selectedMetrics.map((metric) => {
        const row = {
            metric,
            threshold: ""
        };

        selectedRuns.forEach((runLabel) => {
            const index = runs.indexOf(runLabel);
            const record = data.find(
                (_, i) =>
                    _.datasetName === selectedDataset &&
                    _.configurationName === selectedConfig &&
                    _.run_name?.trim().toLowerCase() === runLabel.trim().toLowerCase()
            );

            const thresholdObj = record?.evaluation_metrics_threshold_status?.find(
                (m) => m.metric === metric
            );

            if (!row.threshold && thresholdObj?.ThresholdValue !== undefined) {
                row.threshold = thresholdObj.ThresholdValue;
            }

            row[runLabel] =
                thresholdObj?.ActualValue !== undefined
                    ? `${(thresholdObj.TotalPassed || 0).toFixed(1)}%`
                    : "-";
        });

        return row;
    });

    return (
        <Box p={3}>
            <Grid container spacing={2}>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Dataset</InputLabel>
                        <Select
                            value={selectedDataset}
                            onChange={(e) => setSelectedDataset(e.target.value)}
                            label="Dataset"
                        >
                            {datasets.map((ds) => (
                                <MenuItem key={ds} value={ds}>
                                    {ds}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Configuration</InputLabel>
                        <Select
                            value={selectedConfig}
                            onChange={(e) => setSelectedConfig(e.target.value)}
                            label="Configuration"
                            disabled={!selectedDataset}
                        >
                            {configs.map((cfg) => (
                                <MenuItem key={cfg} value={cfg}>
                                    {cfg}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Run Name</InputLabel>
                        <Select
                            multiple
                            value={selectedRuns}
                            onChange={(e) => setSelectedRuns(e.target.value)}
                            input={<OutlinedInput label="Run Name" />}
                            renderValue={(selected) => selected.join(", ")}
                            disabled={!selectedConfig}
                        >
                            {runs.map((run) => (
                                <MenuItem key={run} value={run}>
                                    <Checkbox checked={selectedRuns.indexOf(run) > -1} />
                                    <ListItemText primary={run} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={2}>
                    <FormControl fullWidth>
                        <InputLabel>Metrics</InputLabel>
                        <Select
                            multiple
                            value={selectedMetrics}
                            onChange={(e) => setSelectedMetrics(e.target.value)}
                            input={<OutlinedInput label="Metrics" />}
                            renderValue={(selected) => selected.join(", ")}
                            disabled={selectedRuns.length === 0}
                        >
                            {metrics.map((metric) => (
                                <MenuItem key={metric} value={metric}>
                                    <Checkbox checked={selectedMetrics.indexOf(metric) > -1} />
                                    <ListItemText primary={metric} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>

            {/* Charts */}
            <Box mt={4}>
                {/* {selectedRuns.map((run, idx) => (
                    <Box key={idx} mb={4}>
                        <Typography variant="h6" gutterBottom>
                            {run} – Metric Evaluation
                        </Typography>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={getChartDataForRun(run)}>
                                <XAxis dataKey="metric" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="Passed" fill="#8884d8" />
                                <Bar dataKey="Failed" fill="#82ca9d" />
                            </BarChart>
                        </ResponsiveContainer>
                    </Box>
                ))} */}
                <ResponsiveContainer width="100%" height={450}>
                    <BarChart
                        data={getStackedChartData()}
                        margin={{ top: 20, right: 30, left: 20, bottom: 60 }} barSize={20}

                    >
                        <XAxis dataKey="metric" />
                        <YAxis />
                        <Tooltip />
                        {
                            selectedRuns.map((run) => (
                                <>
                                    <Bar
                                        key={`${run}_Passed`}
                                        dataKey={`${run}_Passed`}
                                        stackId={run}
                                        name={`${run} - Passed`}
                                        fill="#4caf50"
                                    />
                                    <Bar
                                        key={`${run}_Failed`}
                                        dataKey={`${run}_Failed`}
                                        stackId={run}
                                        name={`${run} - Failed`}
                                        fill="#f44336"
                                    />
                                </>
                            ))
                        }
                    </BarChart>
                </ResponsiveContainer>
            </Box>

            {/* Table */}
            <Box mt={5}>
                <Paper elevation={2}>
                    <Table>
                        <TableHead sx={{ background: "#111270", color: "#fff" }}>
                            <TableRow>
                                <TableCell sx={{ color: "#fff" }}>Metric</TableCell>
                                <TableCell sx={{ color: "#fff" }}>Threshold</TableCell>
                                {selectedRuns.map((run, idx) => (
                                    <TableCell key={idx} sx={{ color: "#fff" }}>
                                        {run}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {tableRows.map((row, idx) => (
                                <TableRow
                                    key={idx}
                                    sx={{
                                        backgroundColor: idx % 2 === 0 ? "#f9f9f9" : "#ffffff"
                                    }}
                                >
                                    <TableCell>{row.metric}</TableCell>
                                    <TableCell>{row.threshold || "-"}</TableCell>
                                    {selectedRuns.map((run, rIdx) => (
                                        <TableCell key={rIdx}>{row[run]}</TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </Paper>
            </Box>
        </Box>
    );
};

export default CompareDashBoard;