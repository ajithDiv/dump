import React, { useState } from "react";
import classes from "./ConfigurationMap.module.css";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const ConfigurationMap = () => {
  const [data, setData] = useState(null);
  const [customInputs, setCustomInputs] = useState({});

  const dummyData = {
    fieldNames: ["Field1", "Field2"],
    parsers: ["Parser1", "Custom Parser"],
  };

  const fetchData = () => {
    setData(dummyData);
  };

  const handleTestClick = () => {
    fetchData();
  };

  const handleParserChange = (index, value) => {
    const newCustomInputs = { ...customInputs };

    if (value === "Custom Parser") {
      newCustomInputs[index] = true;
    } else {
      delete newCustomInputs[index];
    }

    setCustomInputs(newCustomInputs);
  };

  const renderCustomInput = (index) => {
    if (customInputs[index]) {
      return (
        <td>
          <input
            type="text"
            className={classes.custom_input_field}
            placeholder="Enter Custom Parser"
          />
        </td>
      );
    }
    return null;
  };

  return (
    <div className={classes.configuration_map}>
      <div className={classes.question}>
        <span>Do you want to test?</span>
        <button className={classes.test_button} onClick={handleTestClick}>
          Test
        </button>
      </div>

      {data && (
        <div className={classes.table_container}>
          <TableContainer component={Paper}>
            <Table aria-label="Material-UI Table">
              <TableHead sx={{ background: "#111270", color: "#fff" }}>
                <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Field Names
                  </TableCell>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Parsers
                  </TableCell>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Context/Output
                  </TableCell>
                  <TableCell
                    sx={{ color: "#fff", textAlign: "left" }}
                  ></TableCell>{" "}
                  {/* Placeholder for custom input column */}
                </TableRow>
              </TableHead>
              <TableBody>
                {data.fieldNames.map((fieldName, index) => (
                  <TableRow
                    key={index}
                    style={
                      index % 2
                        ? { background: "#F6F6F6" }
                        : { background: "white" }
                    }
                  >
                    <TableCell>
                      <select className={classes.field_names_dropdown}>
                        {data.fieldNames.map((fieldName, index) => (
                          <option key={index} value={fieldName}>
                            {fieldName}
                          </option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      <select
                        className={classes.parsers_dropdown}
                        onChange={(e) =>
                          handleParserChange(index, e.target.value)
                        }
                      >
                        {data.parsers.map((parser, index) => (
                          <option key={index} value={parser}>
                            {parser}
                          </option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      <select className={classes.context_output_dropdown}>
                        <option value="Context">Context</option>
                        <option value="Output">Output</option>
                      </select>
                    </TableCell>
                    {renderCustomInput(index)}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <button className={classes.submit_button}>Submit</button>
        </div>
      )}
    </div>
  );
};

export default ConfigurationMap;
