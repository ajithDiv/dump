import React, { useContext, useState } from "react";
import ApiConnector from "./ApiConnector";
import { AuthContext } from "../../globals/AuthContext";
import { useLocation } from "react-router-dom";
import ConfigurationMap from "./ConfigurationMap";
import LLM from "./LLM";
import Langfuse from "./Langfuse";

const Model = () => {
  const ctx = useContext(AuthContext);
  ctx.updateHeader("Model+");
  const location = useLocation();

  let tabMenu = ["Configure", "LLM"];//"Map", "Test",
  let tabMenuForObservability = ["Configure", "LLM", "Langfuse"]
  const [selectedTab, setSelectedTab] = useState(
    tabMenu[(location.state && location.state.tabIndex) || 0]
  );

  const handleTabSelection = (menu) => {
    setSelectedTab(menu);
  };

  return (
    <div>
      <div
        style={{
          backgroundColor: "#FEF2FA",
          borderBottom: "1px solid #C8C4D9",
          color: "gray",
        }}
      >
        {ctx.projectName !== "Observability" ? tabMenu.map((menu) => (
          <h5
            style={{
              display: "inline-block",
              margin: "0",
              padding: "8px",
              borderRight: "1px solid #C8C4D9",
              color: selectedTab === menu ? "#4546D9" : "#434343",
              borderBottom: selectedTab === menu ? "2px solid #4546D9" : null,
              fontSize: "1rem",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => handleTabSelection(menu)}
          >
            {menu}
          </h5>
        )) : tabMenuForObservability.map((menu) => (
          <h5
            style={{
              display: "inline-block",
              margin: "0",
              padding: "8px",
              borderRight: "1px solid #C8C4D9",
              color: selectedTab === menu ? "#4546D9" : "#434343",
              borderBottom: selectedTab === menu ? "2px solid #4546D9" : null,
              fontSize: "1rem",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => handleTabSelection(menu)}
          >
            {menu}
          </h5>
        ))}
      </div>

      <div style={{ padding: "1rem" }}>
        {selectedTab === "Configure" && <ApiConnector />}
        {selectedTab === "Map" && <ConfigurationMap />}
        {selectedTab === "Test" && <h1>Test</h1>}
        {selectedTab === "LLM" && <LLM />}
        {selectedTab === "Langfuse" && <Langfuse />}
      </div>
    </div>
  );
};

export default Model;
