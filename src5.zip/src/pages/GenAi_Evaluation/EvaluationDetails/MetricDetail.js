import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Chip,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from "@mui/material";
import Button from "@mui/material/Button";
import { useContext, useEffect, useState } from "react";
import { getEvaluationRecordData } from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import { useParams } from "react-router-dom";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const MetricDetail = () => {
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [data, setData] = useState({});
  const [selectedReason, setSelectedReason] = useState("");
  const [selectedTableData, setSelectedTableData] = useState([]);
  const [show, setShow] = useState(true);
  const [accordianStatus, setAccordianStatus] = useState([]);

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleChipClick = (reason, tableData) => {
    setSelectedReason(reason);
    setSelectedTableData(tableData);
    setAccordianStatus((prev) => {
      let temp = [];
      tableData.map((item) => temp.push(true));
      return temp;
    });
    setShow(true);
  };

  const ctx = useContext(AuthContext);
  const params = useParams();

  useEffect(() => {
    getEvaluationRecordData(params.subId, ctx.projectSubType).then((result) => {
      setData(result.output);
      setSelectedReason(result.output.metrics.length > 0 ? result.output.metrics[0].reason : result.output.custom_metrics.length > 0 ? result.output.custom_metrics[0].reason : result.output.static_metrics.length > 0 ? result.output.static_metrics[0].reason : "");
      setSelectedTableData(result.output.metrics.length > 0 ? result.output.metrics[0].tableData : result.output.custom_metrics.length > 0 ? result.output.custom_metrics[0].tableData : result.output.static_metrics.length > 0 ? result.output.static_metrics[0].tableData : []);
      setAccordianStatus((prev) => {
        let temp = [];
        if (result.output.metrics.length > 0) {
          result.output.metrics[0].tableData.map((item) => temp.push(true));
        }
        if (result.output.custom_metrics.length > 0) {
          result.output.custom_metrics[0].tableData.map((item) => temp.push(true));
        }
        return temp;
      });
    });
  }, []);

  return (
    <Stack direction="row">
      <Stack direction="column">
        <Paper
          style={{ width: "12rem", minHeight: "100vh", padding: "0.25rem" }}
        >
          {data.metrics &&
            data.metrics.length > 0 &&
            data?.metrics.map((metric, index) => {
              return (
                <Paper
                  style={{
                    padding: "0.5rem",
                    marginBottom: "0.5rem",
                    cursor: "pointer",
                    backgroundColor:
                      metric.reason === selectedReason ? "#E9FAFF" : null,
                    border:
                      metric.reason === selectedReason
                        ? "2px solid #0546C5"
                        : null,
                  }}
                  onClick={() => {
                    handleChipClick(metric.reason, metric.tableData);
                  }}
                >
                  <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="space-between"
                    fontSize="1rem"
                    fontWeight="500"
                  >
                    {metric.name}
                    <Chip
                      style={{
                        height: "1rem",
                        fontSize: "10px",
                        color: metric.status ? "#0fc7c7" : "#ff5473",
                        border: metric.status
                          ? "1px solid #0fc7c7"
                          : "1px solid #ff5473",
                      }}
                      label={metric.value.toFixed(1)}
                      variant="outlined"
                      color={metric.status ? "success" : "error"}
                    />
                  </Stack>
                </Paper>
              );
            })}
          
          {data.custom_metrics &&
            data.custom_metrics.length > 0 &&
            data?.custom_metrics.map((metric, index) => {
              return (
                <Paper
                  style={{
                    padding: "0.5rem",
                    marginBottom: "0.5rem",
                    cursor: "pointer",
                    backgroundColor:
                      metric.reason === selectedReason ? "#E9FAFF" : null,
                    border:
                      metric.reason === selectedReason
                        ? "2px solid #0546C5"
                        : null,
                  }}
                  onClick={() => {
                    handleChipClick(metric.reason, metric.tableData);
                  }}
                >
                  <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="space-between"
                    fontSize="1rem"
                    fontWeight="500"
                  >
                    {metric.name}
                    <Chip
                      style={{
                        height: "1rem",
                        fontSize: "10px",
                        color: metric.status ? "#0fc7c7" : "#ff5473",
                        border: metric.status
                          ? "1px solid #0fc7c7"
                          : "1px solid #ff5473",
                      }}
                      label={metric.value.toFixed(1)}
                      variant="outlined"
                      color={metric.status ? "success" : "error"}
                    />
                  </Stack>
                </Paper>
              );
            })}
          
          {data.static_metrics &&
            data.static_metrics.length > 0 &&
            data?.static_metrics.map((metric, index) => {
              return (
                <Paper
                  style={{
                    padding: "0.5rem",
                    marginBottom: "0.5rem",
                    cursor: "pointer",
                    backgroundColor:
                      metric.reason === selectedReason ? "#E9FAFF" : null,
                    border:
                      metric.reason === selectedReason
                        ? "2px solid #0546C5"
                        : null,
                  }}
                  onClick={() => {
                    handleChipClick(metric.reason, metric.tableData);
                  }}
                >
                  <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="space-between"
                    fontSize="1rem"
                    fontWeight="500"
                  >
                    {metric.name}
                    <Chip
                      style={{
                        height: "1rem",
                        fontSize: "10px",
                        color: metric.status ? "#0fc7c7" : "#ff5473",
                        border: metric.status
                          ? "1px solid #0fc7c7"
                          : "1px solid #ff5473",
                      }}
                      label={metric.value.toFixed(1)}
                      variant="outlined"
                      color={metric.status ? "success" : "error"}
                    />
                  </Stack>
                </Paper>
              );
            })}
        </Paper>
      </Stack>
      <Stack style={{ padding: "2rem" }}>
        {/* <TableContainer component={Paper}>
          <Table aria-label="Material-UI Table">
            <TableHead sx={{ background: "#111270", color: "#fff" }}>
              <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                {data.metrics &&
                  data.metrics.length > 0 &&
                  data?.metrics.map((metric, index) => {
                    return (
                      <TableCell
                        sx={{
                          width: "2.5rem",
                          color: "#fff",
                          textAlign: "center",
                          padding: "0.5rem",
                        }}
                        key={index}
                      >
                        {metric.name}
                      </TableCell>
                    );
                  })}
              </TableRow>
            </TableHead>

            <TableBody>
              <TableRow>
                {data.metrics &&
                  data.metrics.length > 0 &&
                  data?.metrics.map((metric, index) => {
                    return (
                      <TableCell
                        sx={{
                          width: "2.5rem",
                          color: "#fff",
                          textAlign: "center",
                        }}
                        key={index}
                      >
                        <Chip
                          style={{
                            height: "1.5rem",
                            fontSize: "12px",
                            color: "#0fc7c7",
                            border: "1px solid #0fc7c7",
                          }}
                          label={metric.value.toFixed(1)}
                          variant="outlined"
                          color={"success"}
                          clickable={true}
                          onClick={() => {
                            handleChipClick(metric.reason, metric.tableData);
                          }}
                        />
                      </TableCell>
                    );
                  })}
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer> */}

        {show && (
          <div
          // style={{
          //   paddingTop: "16px",
          // }}
          >
            <Paper
              style={{
                padding: "20px",
                display: "flex",
                flexDirection: "column",
                gap: "20px",
              }}
            >
              <Typography fontSize="22px" fontWeight={700} color={"#484A56"}>
                Reason
              </Typography>
              <Typography color={"#484A56"} fontSize="15px" fontWeight={400}>
                {selectedReason}
              </Typography>

              {/* <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={selectedTableData.length}
              rowsPerPage={rowPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            /> */}
            </Paper>

            {selectedTableData.length > 0 && (
              <Stack direction="row-reverse">
                <Button
                  style={{ margin: "1rem 0" }}
                  variant="contained"
                  onClick={() =>
                    setAccordianStatus((prev) => prev.map((it) => true))
                  }
                >
                  Expand All
                </Button>
              </Stack>
            )}
            {selectedTableData.map((row, index) => {
              return (
                <Accordion
                  expanded={accordianStatus[index]}
                  onChange={() =>
                    setAccordianStatus((prev) => {
                      let temp = [...prev];
                      temp[index] = !temp[index];
                      return temp;
                    })
                  }
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1-content"
                    id="panel1-header"
                  >
                    <Typography fontWeight={500}>
                      Traceback {index + 1}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <TableContainer sx={{ marginTop: "0px" }} component={Paper}>
                      <Table aria-label="Material-UI Table">
                        <TableHead
                          sx={{ background: "#78ABB6", color: "#fff" }}
                        >
                          <TableRow
                            sx={{ alignItems: "center", color: "#fff" }}
                          >
                            {selectedTableData &&
                              selectedTableData.length > 0 &&
                              Object.keys(selectedTableData[0]).map(
                                (row, index) => {
                                  return (
                                    <TableCell
                                      sx={{
                                        width: "calc(100% / " + Object.keys(selectedTableData[0]).length + ")",
                                        padding: "0.5rem",
                                        color: "#fff",
                                        textAlign: "center",
                                        borderRight: "1px solid gray",
                                      }}
                                      key={index}
                                    >
                                      <strong>{row}</strong>
                                    </TableCell>
                                  );
                                }
                              )}
                          </TableRow>
                        </TableHead>

                        <TableBody>
                          <TableRow
                            key={index}
                            style={
                              index % 2
                                ? { background: "#EEF4F9" }
                                : { background: "#EEF4F9" }
                            }
                          >
                            {selectedTableData &&
                              selectedTableData.length > 0 &&
                              Object.keys(selectedTableData[0]).map(
                                (cell, index) => {
                                  return (
                                    <TableCell
                                      sx={{
                                        width: "calc(100% / (Object.keys(selectedTableData[0]).length))",
                                        padding: "0.5rem",
                                        color: "black",
                                        textAlign: "center",
                                        borderRight: "1px solid gray",
                                      }}
                                      key={index}
                                    >
                                      {typeof row[cell] === "object" &&
                                      typeof row[cell].length === "number"
                                        ? row[cell].map((item, idx) => {
                                            return <p key={idx}>{item}</p>;
                                          })
                                        : row[cell]}
                                    </TableCell>
                                  );
                                }
                              )}
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </AccordionDetails>
                </Accordion>
              );
            })}
          </div>
        )}
      </Stack>
    </Stack>
  );
};

export default MetricDetail;
