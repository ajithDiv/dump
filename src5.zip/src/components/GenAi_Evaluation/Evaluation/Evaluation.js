import {
  Button,
  CircularProgress,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import RefreshIcon from "@mui/icons-material/Refresh";

import styles from "./Evaluation.module.css";
import { Link } from "react-router-dom";
import {
  deleteEvaluation,
  getAllEvaluations,
} from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import { formatTimestamp } from "../../../_helpers/formatTime";
import Confirmation from "../../Confirmation/Confirmation";

const Evaluation = () => {
  const [loading, setLoading] = useState(true);
  const [executionData, setExecutionData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [refresh, setRefresh] = useState(true);
  const [open, setOpen] = useState(false);
  const [selectedId, setSelectedId] = useState("");

  const ctx = useContext(AuthContext);

  const handleRefresh = () => {
    setRefresh(true);
  };

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDeleteEvaluation = (id) => {
    deleteEvaluation(id).then(result => {
      setRefresh(true);
    })
  }

  const toggleConfirm = () => {
    setOpen(prev => !prev);
  }

  useEffect(() => { 
    if (refresh) {
      setLoading(true);
      getAllEvaluations(ctx.projectName).then(async (result) => {
        setLoading(false);
        setExecutionData(result.evaluationList);
        setRefresh(false);
      });
    }
  }, [refresh]);

  return (
    <div style={{ height: "calc(100vh - 75px)" }}>
      <>
      <Confirmation
        open={open}
        toggleConfirm={toggleConfirm}
        handleSubmit={() => {
          handleDeleteEvaluation(selectedId);
          toggleConfirm();
        }}
        message="Are you sure you want to delete this?"
      />
        <div className={styles.buttonContainer}>
          <Button
            variant="contained"
            style={{ backgroundColor: "#0FC7C7" }}
            onClick={handleRefresh}
          >
            Refresh
            <RefreshIcon />
          </Button>
        </div>
        <TableContainer component={Paper}>
          <Table aria-label="Material-UI Table">
            <TableHead sx={{ background: "#111270", color: "#fff" }}>
              <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                <TableCell
                  sx={{ width: "2.5rem", color: "#fff", textAlign: "left" }}
                >
                  <strong>S No.</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Configuration Name</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Dataset Name</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Evaluator LLM</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Total Records</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Executed By</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Execution Date</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Execution Time</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Execution Status</strong>
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  <strong>Action</strong>
                </TableCell>
              </TableRow>
            </TableHead>
            {loading === true ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      <CircularProgress />
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : executionData.length === 0 ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      No Data Available
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : (
              <TableBody>
                {executionData
                  .slice(page * rowPage, page * rowPage + rowPage)
                  .map((row, index) => {
                    const uniqueRowNumber = page * rowPage + index + 1;
                    return (
                      <TableRow
                        key={index}
                        style={
                          index % 2
                            ? { background: "#F6F6F6" }
                            : { background: "white" }
                        }
                      >
                        <TableCell>{uniqueRowNumber}</TableCell>
                        <TableCell>{row.configurationName || "view"}</TableCell>
                        <TableCell>{row.datasetName}</TableCell>
                        <TableCell>{row.model}</TableCell>
                        <TableCell>{row.totalRecords}</TableCell>
                        <TableCell>{row.executedBy}</TableCell>
                        <TableCell>
                          {formatTimestamp(row.executedDate)}
                        </TableCell>
                        <TableCell>{row.executionTime} mins</TableCell>
                        <TableCell>
                          {row.executionStatus === "Completed" ||
                          row.executionStatus === "Failed" ? (
                            <Link to={"evaluation_summary/" + row._id}>
                              {row.executionStatus}
                            </Link>
                          ) : (
                            <>{row.executionStatus}</>
                          )}
                        </TableCell>
                        <TableCell>
                          <Stack direction="row">
                            <IconButton
                              onClick={() => {
                                setSelectedId(row._id);
                                toggleConfirm();
                              }}
                              color="error"
                              size="small"
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            )}
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={executionData.length}
          rowsPerPage={rowPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </>
    </div>
  );
};

export default Evaluation;
