import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  Chip,
  CircularProgress,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from "@mui/material";
import ThumbUpOutlinedIcon from "@mui/icons-material/ThumbUpOutlined";
import ThumbDownOutlinedIcon from "@mui/icons-material/ThumbDownOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import VerifiedOutlinedIcon from "@mui/icons-material/VerifiedOutlined";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import JailBreakResults from "../JailBreakResults/JailBreakResults";
import AdversialResults from "../AdversialResults/AdversialResult";
import RedTeamResults from "../RedTeamResults/RedTeamResults";
import BiasResults from "../BiasResults/BiasResults";
import DuplicateResults from "../DuplicateResults/DuplicateResults";
import CoverageResults from "../CoverageResults/CoverageResults";
import { AuthContext } from "../../../globals/AuthContext";

let data = [
  {
    id: "01",
    promptResponse: "Lorem Ipsum",
    baseResponse: "Lorem Ipsum",
    actualResponse: "Lorem Ipsum ",
    adherence: 3,
    relevance: 8,
    completeness: 6,
    similar: "Failed",
    contains: "Passed",
    startsWith: "Failed",
  },
];

const redList = [
  "controversiality",
  "criminality",
  "harmfullness",
  "insensitivity",
  "maliciousness",
  "misogyny",
  "pii_detction",
  "stereotype",
];

const TelemetryDetails = (props) => {
  const [executionData, setExecutionData] = useState(data);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [showElement, setShowElement] = useState("");
  const [indice, setIndice] = useState(0);

  const navigate = useNavigate();
  const ctx = useContext(AuthContext);

  const handleChangeShowElement = (element, ind = 0) => {
    setShowElement(element);
    setIndice(ind);
  };

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <>
      {props.loading === true && (
        <Stack width="100%" direction="row" justifyContent="center">
          <CircularProgress />
        </Stack>
      )}
      {showElement === "" && props.loading === false && (
        <div>
          {/* <Button style={{marginBottom: "1rem"}} startIcon={<KeyboardBackspaceIcon/>} variant="outlined" onClick={()=>navigate("/genai-assurance/genai_evaluate")}>Back</Button> */}
          
          <TableContainer component={Paper}>
            <Table aria-label="Material-UI Table">
              <TableHead sx={{ background: "#111270", color: "#fff" }}>
                <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    <strong>S.No.</strong>
                  </TableCell>
                  {!Object.keys(props.evaluationData.aggregate).includes(
                    "Metrices"
                  ) && (
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Input</strong>
                    </TableCell>
                  )}
                  {props.evaluationData.aggregate[
                    Object.entries(props.evaluationData.aggregate)[0][0]
                  ].map(
                    (item) =>
                      !(["latency", "totalcost"].indexOf(item.name) > -1) && (
                        <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                          <strong>{item.name}</strong>
                        </TableCell>
                      )
                  )}
                  {props.evaluationData.custom_aggregate[
                    Object.entries(props.evaluationData.custom_aggregate)[0][0]
                  ].map(
                    (item) =>
                      !(["latency", "totalcost"].indexOf(item.name) > -1) && (
                        <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                          <strong>{item.name}</strong>
                        </TableCell>
                      )
                  )}
                  {props.evaluationData.static_aggregate[
                    Object.entries(props.evaluationData.static_aggregate)[0][0]
                  ].map(
                    (item) =>
                      !(["latency", "totalcost"].indexOf(item.name) > -1) && (
                        <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                          <strong>{item.name}</strong>
                        </TableCell>
                      )
                  )}
                  {!(
                    props.evaluationData.evaluation.constructor === Object
                  ) && (
                    <>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Jail Break
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Adverserial
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Red Team Component
                      </TableCell>
                    </>
                  )}
                  {props.evaluationData.evaluation.constructor === Object && (
                    <>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Bias
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Coverage
                      </TableCell>
                      <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                        Duplicate
                      </TableCell>
                    </>
                  )}
                </TableRow>
              </TableHead>
              {props.loading === true ? (
                <TableBody>
                  <TableRow>
                    <TableCell colSpan={8}>
                      <Stack
                        width="100%"
                        direction="row"
                        justifyContent="center"
                      >
                        <CircularProgress />
                      </Stack>
                    </TableCell>
                  </TableRow>
                </TableBody>
              ) : executionData.length === 0 ? (
                <TableBody>
                  <TableRow>
                    <TableCell colSpan={8}>
                      <Stack
                        width="100%"
                        direction="row"
                        justifyContent="center"
                      >
                        No Data Available
                      </Stack>
                    </TableCell>
                  </TableRow>
                </TableBody>
              ) : (
                <TableBody>
                  <TableRow>
                    {Object.entries(props.evaluationData.aggregate)
                      .slice(page * rowPage, page * rowPage + rowPage)
                      .map((item, index) => {
                        const uniqueRowNumber = page * rowPage + index + 1;
                        return (
                          <>
                            <TableCell>{uniqueRowNumber}</TableCell>
                            {item[0] !== "Metrices" && (
                              <TableCell>{item[0]}</TableCell>
                            )}

                            {item[1].map(
                              (metrics) =>
                                ["latency", "totalcost"].indexOf(
                                  metrics.name
                                ) === -1 && (
                                  <TableCell>
                                    {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    ) : (
                                      // redList.indexOf(metrics[0]) > -1 ? (
                                      // <Chip
                                      //   style={{
                                      //     backgroundColor:
                                      //       metrics[1] < 0.5
                                      //         ? "#EAFFFE"
                                      //         : "#FFEDF3",
                                      //   }}
                                      //   icon={
                                      //     metrics[1] < 0.5 ? (
                                      //       <VerifiedOutlinedIcon />
                                      //     ) : (
                                      //       <ErrorOutlineOutlinedIcon />
                                      //     )
                                      //   }
                                      //   label={metrics[1].toFixed(2)}
                                      //   variant="outlined"
                                      //   color={
                                      //     metrics[1] < 0.5 ? "success" : "error"
                                      //   }
                                      //   size="small"
                                      // />
                                      // ) :
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    )}
                                  </TableCell>
                                )
                            )}
                          </>
                        );
                      })}

                    {Object.entries(props.evaluationData.custom_aggregate)
                      .slice(page * rowPage, page * rowPage + rowPage)
                      .map((item, index) => {
                        const uniqueRowNumber = page * rowPage + index + 1;
                        return (
                          <>
                            {/* <TableCell>{uniqueRowNumber}</TableCell>
                            {item[0] !== "Metrices" && (
                              <TableCell>{item[0]}</TableCell>
                            )} */}

                            {item[1].map(
                              (metrics) =>
                                ["latency", "totalcost"].indexOf(
                                  metrics.name
                                ) === -1 && (
                                  <TableCell>
                                    {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    ) : (
                                      // redList.indexOf(metrics[0]) > -1 ? (
                                      // <Chip
                                      //   style={{
                                      //     backgroundColor:
                                      //       metrics[1] < 0.5
                                      //         ? "#EAFFFE"
                                      //         : "#FFEDF3",
                                      //   }}
                                      //   icon={
                                      //     metrics[1] < 0.5 ? (
                                      //       <VerifiedOutlinedIcon />
                                      //     ) : (
                                      //       <ErrorOutlineOutlinedIcon />
                                      //     )
                                      //   }
                                      //   label={metrics[1].toFixed(2)}
                                      //   variant="outlined"
                                      //   color={
                                      //     metrics[1] < 0.5 ? "success" : "error"
                                      //   }
                                      //   size="small"
                                      // />
                                      // ) :
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    )}
                                  </TableCell>
                                )
                            )}
                          </>
                        );
                      })}
                        
                        {Object.entries(props.evaluationData.static_aggregate)
                      .slice(page * rowPage, page * rowPage + rowPage)
                      .map((item, index) => {
                        const uniqueRowNumber = page * rowPage + index + 1;
                        return (
                          <>
                            {/* <TableCell>{uniqueRowNumber}</TableCell>
                            {item[0] !== "Metrices" && (
                              <TableCell>{item[0]}</TableCell>
                            )} */}

                            {item[1].map(
                              (metrics) =>
                                ["latency", "totalcost"].indexOf(
                                  metrics.name
                                ) === -1 && (
                                  <TableCell>
                                    {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    ) : (
                                      // redList.indexOf(metrics[0]) > -1 ? (
                                      // <Chip
                                      //   style={{
                                      //     backgroundColor:
                                      //       metrics[1] < 0.5
                                      //         ? "#EAFFFE"
                                      //         : "#FFEDF3",
                                      //   }}
                                      //   icon={
                                      //     metrics[1] < 0.5 ? (
                                      //       <VerifiedOutlinedIcon />
                                      //     ) : (
                                      //       <ErrorOutlineOutlinedIcon />
                                      //     )
                                      //   }
                                      //   label={metrics[1].toFixed(2)}
                                      //   variant="outlined"
                                      //   color={
                                      //     metrics[1] < 0.5 ? "success" : "error"
                                      //   }
                                      //   size="small"
                                      // />
                                      // ) :
                                      <Chip
                                        style={{
                                          backgroundColor: metrics.status
                                            ? "#EAFFFE"
                                            : "#FFEDF3",
                                        }}
                                        icon={
                                          metrics.status ? (
                                            <VerifiedOutlinedIcon />
                                          ) : (
                                            <ErrorOutlineOutlinedIcon />
                                          )
                                        }
                                        label={metrics.value.toFixed(2)}
                                        variant="outlined"
                                        color={
                                          metrics.status ? "success" : "error"
                                        }
                                        size="small"
                                      />
                                    )}
                                  </TableCell>
                                )
                            )}
                          </>
                        );
                      })}

                    {!(
                      props.evaluationData.evaluation.constructor === Object
                    ) && (
                      <>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            handleChangeShowElement("Jail Break")
                          }
                        >
                          View Report
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            handleChangeShowElement("Adverserial")
                          }
                        >
                          View Report
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            handleChangeShowElement("Red Team Component")
                          }
                        >
                          View Report
                        </TableCell>
                      </>
                    )}
                    {props.evaluationData.evaluation.constructor === Object && (
                      <>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() => handleChangeShowElement("Bias")}
                        >
                          View Report
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            handleChangeShowElement("Coverage")
                          }
                        >
                          View Report
                        </TableCell>
                        <TableCell
                          sx={{
                            color: "darkblue",
                            cursor: "pointer",
                          }}
                          onClick={() =>
                            handleChangeShowElement("Duplicate")
                          }
                        >
                          View Report
                        </TableCell>
                      </>
                    )}
                  </TableRow>
                </TableBody>
              )}
            </Table>
          </TableContainer>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={Object.entries(props.evaluationData.aggregate).length}
            rowsPerPage={rowPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </div>
      )}

      {!(props.evaluationData.evaluation.constructor === Object) &&
        showElement === "Jail Break" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Jail Break Result
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <JailBreakResults />
              </AccordionDetails>
            </Accordion>
          </>
        )}
      {!(props.evaluationData.evaluation.constructor === Object) &&
        showElement === "Adverserial" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Adverserial Results
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <AdversialResults />
              </AccordionDetails>
            </Accordion>
          </>
        )}
      {!(props.evaluationData.evaluation.constructor === Object) &&
        showElement === "Red Team Component" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Red Team Component Results
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <RedTeamResults />
              </AccordionDetails>
            </Accordion>
          </>
        )}

      {props.evaluationData.evaluation.constructor === Object &&
        showElement === "Bias" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Bias
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <BiasResults
                  indice={indice}
                  evaluationData={props.evaluationData}
                />
              </AccordionDetails>
            </Accordion>
          </>
        )}

      {props.evaluationData.evaluation.constructor === Object &&
        showElement === "Coverage" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Coverage -{" "}
                  {Object.entries(props.evaluationData.evaluation)[
                    indice
                  ][1].overall_coverage.toFixed(2)}{" "}
                  %
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <CoverageResults
                  indice={indice}
                  evaluationData={props.evaluationData}
                />
              </AccordionDetails>
            </Accordion>
          </>
        )}

      {props.evaluationData.evaluation.constructor === Object &&
        showElement === "Duplicate" && (
          <>
            <Button
              style={{ marginBottom: "1rem" }}
              startIcon={<KeyboardBackspaceIcon />}
              variant="outlined"
              onClick={() => handleChangeShowElement("")}
            >
              Back
            </Button>

            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography fontSize="20px" color="#313b3e">
                  Duplicate
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "0.5rem",
                }}
              >
                <DuplicateResults
                  indice={indice}
                  evaluationData={props.evaluationData}
                />
              </AccordionDetails>
            </Accordion>
          </>
        )}
    </>
  );
};

export default TelemetryDetails;
