import {
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { getDocumentsByExecutionCategory } from "../../../_services/genai_evaluation.service";
import { useParams } from "react-router-dom";

const AdversialResults = () => {
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [data, setData] = useState([]);

  const params = useParams();

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  useEffect(() => {
    getDocumentsByExecutionCategory("adversarial_attack", params.id).then(
      (result) => {
        setLoading(false);
        // setData(result[0].results);
        let response = [];
        result.map((item) => {
          item.Response_List.map((sub) => {
            response.push({
              ogPrompt: item["Original Question"],
              ogResponse: item["Original Response"],
              augPromt: sub["Augmented Question"],
              augResponse: sub["Augmented Response"],
              status: sub["Status"],
            });
          });
        });
        setData(response)
      }
    );
  }, []);

  return (
    <div>
      <TableContainer component={Paper}>
        <Table aria-label="Material-UI Table">
          <TableHead sx={{ background: "#111270", color: "#fff" }}>
            <TableRow sx={{ alignItems: "center", color: "#fff" }}>
              <TableCell
                sx={{
                  width: "2.5rem",
                  color: "#fff",
                  textAlign: "left",
                }}
              >
                <strong>S No.</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Original Prompt</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Original Response</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Augmented Prompt</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Augmented Response</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Adversarial Attack Status</strong>
              </TableCell>
            </TableRow>
          </TableHead>
          {loading === true ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    <CircularProgress />
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : data.length === 0 ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    No Data Availble
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : (
            <TableBody>
              {data
                .slice(page * rowPage, page * rowPage + rowPage)
                .map((row, index) => {
                  const uniqueRowNumber = page * rowPage + index + 1;
                  return (
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#F6F6F6" }
                          : { background: "white" }
                      }
                    >
                      <TableCell>{uniqueRowNumber}</TableCell>
                      <TableCell>{row.ogPrompt}</TableCell>
                      <TableCell>{row.ogResponse}</TableCell>
                      <TableCell>{row.augPromt}</TableCell>
                      <TableCell>{row.augResponse}</TableCell>
                      <TableCell>{row.status}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          )}
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={data.length}
        rowsPerPage={rowPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};

export default AdversialResults;
