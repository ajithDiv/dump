import {
  Breadcrumbs,
  Button,
  Chip,
  CircularProgress,
  IconButton,
  InputBase,
  Paper,
  Stack,
  TablePagination,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import commentIcon from "../../../assets/genaiIcons/comment_edit_icon.png";
import SearchIcon from "@mui/icons-material/Search";
import SwapVertIcon from "@mui/icons-material/SwapVert";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

import styles from "./DatasetPrompts.module.css";
import { Link, useLocation } from "react-router-dom";
import { getPrompts } from "../../../_services/genai_dataset.service";

const breadcrumbs = [
  <Link
    underline="hover"
    key="1"
    color="inherit"
    to="/genai-assurance/genai_dataset/01"
  >
    Settings
  </Link>,
  <Typography key="3" color="text.primary">
    All Generated Prompts
  </Typography>,
];

const DatasetPrompts = (props) => {
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(25);
  const [prompts, setPrompts] = useState([]);

  const { state } = useLocation();

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  useEffect(() => {
    getPrompts(state.datasetId).then((results) => {
      setLoading(false);
      setPrompts(results.responses);
    });
  }, []);

  return (
    <div style={{ margin: "1rem" }}>
      <Breadcrumbs
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
      >
        {breadcrumbs}
      </Breadcrumbs>
      <Paper> 
        <Paper className={styles.header}>
          <Typography color="#313B3E" fontSize="18px" fontWeight="500">
            Test Data
          </Typography>
          <Paper
            component="form"
            sx={{
              display: "flex",
              alignItems: "center",
              width: 400,
            }}
          >
            <IconButton sx={{ p: "5px" }} aria-label="menu">
              <SearchIcon />
            </IconButton>
            <InputBase sx={{ ml: 1, flex: 1 }} placeholder="Search Prompts" />
          </Paper>
          <Button
            style={{ border: "1px solid #DCDCE4", color: "#898B9B" }}
            variant="outlined"
            startIcon={<SwapVertIcon />}
          >
            Sort: Date by
          </Button>
        </Paper>

        <div className={styles.content}>
          {loading === true && (
            <Stack width="100%" direction="row" justifyContent="center">
              <CircularProgress />
            </Stack>
          )}
          {loading === false && prompts
            .slice(page * rowPage, page * rowPage + rowPage)
            .map((item, index) => (
              <Paper className={styles.promptBox}>
                <div className={styles.firstLayer}>
                  <img src={commentIcon} alt="edit" />
                  <Chip
                    style={{ height: "1rem", fontSize: "9px" }}
                    label={item.source}
                    variant="outlined"
                    size="small"
                    color="primary"
                  />
                </div>
                <Typography
                  marginTop="0.25rem"
                  fontSize="14px"
                  fontWeight={400}
                  color="#484A56"
                >
                  {item.question.substring(0, 82)}
                  {item.question.length > 82 ? "..." : ""}
                </Typography>
              </Paper>
            ))}
        </div>

        <Paper>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={prompts.length}
            rowsPerPage={rowPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Paper>
    </div>
  );
};

export default DatasetPrompts;
