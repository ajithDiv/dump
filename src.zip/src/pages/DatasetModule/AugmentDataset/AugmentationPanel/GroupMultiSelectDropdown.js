import React, { useState, useRef, useEffect } from 'react';
import './AugmentationPanel.css';
const GroupMultiSelectDropdown = ({ options, selected, onApply }) => {
    const [open, setOpen] = useState(false);
    const [tempSelected, setTempSelected] = useState([...selected]);
    const dropdownRef = useRef(null);
    useEffect(() => {
        setTempSelected(selected.length ? selected : ['All']);
    }, [selected]);
    useEffect(() => {
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    const toggleOption = (group) => {
        setTempSelected((prev) => {
            let updated;
            if (group === 'All') {
                updated = ['All'];
            } else {
                updated = prev.includes(group)
                    ? prev.filter((g) => g !== group)
                    : [...prev.filter((g) => g !== 'All'), group];
            }
            return updated.length === 0 ? ['All'] : updated;
        });
    };
    const applySelection = () => {
        onApply(tempSelected.length > 0 ? tempSelected : ['All']);
        setOpen(false);
    };
    const clearAll = () => {
        setTempSelected([]);
    };
    return (
        <div className="custom-dropdown" ref={dropdownRef}>
            <div
                className="dropdown-header ellipsis"
                onClick={() => setOpen(!open)}
                title={selected.join(', ')}
            >
                {selected.includes('All') || selected.length === 0 ? 'All' : selected.join(', ')}
                <span className="arrow">{open ? '▲' : '▼'}</span>
            </div>
            {open && (
                <div className="dropdown-list">
                    {options.map((group, idx) => (
                        <label key={idx} className="dropdown-item">
                            <input
                                type="checkbox"
                                checked={tempSelected.includes(group)}
                                onChange={() => toggleOption(group)}
                            />
                            {group}
                        </label>
                    ))}
                    <div className="dropdown-actions">
                        <button className="clear-button" onClick={clearAll}>
                            Clear All
                        </button>
                        <button className="apply-button" onClick={applySelection}>
                            Apply
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
export default GroupMultiSelectDropdown;