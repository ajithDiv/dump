import {
  Alert,
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  FormControlLabel,
  Icon,
  IconButton,
  InputBase,
  Link,
  ListItemText,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Popover,
  Snackbar,
  Stack,
  TablePagination,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import commentIcon from "../../../assets/genaiIcons/comment_edit_icon.png";
import verifiedCommentIcon from "../../../assets/genaiIcons/verified_comment_edit_icon 1.png";
import SearchIcon from "@mui/icons-material/Search";
import SwapVertIcon from "@mui/icons-material/SwapVert";
import CloseIcon from "@mui/icons-material/Close";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import deleteIcon from "../../../assets/genaiIcons/delete-fail.png";
import DownloadingIcon from "@mui/icons-material/Downloading";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import FilterListIcon from "@mui/icons-material/FilterList";
import adversarialAttackIcon from "../../../assets/genaiIcons/adversarial_attack.png";
import dummyP2I from "../../../assets/img/dummyP2I.png";
import PriorityHighIcon from "@mui/icons-material/PriorityHigh";
import VerifiedOutlinedIcon from "@mui/icons-material/VerifiedOutlined";

import styles from "./VerifyDataset.module.css";
import {
  VerifyPromptResponse,
  deleteBulkPrompts,
  deleteDatasetPrompt,
  generateGroundTruth,
  getPromptResponses,
} from "../../../_services/genai_dataset.service";
import Confirmation from "../../../components/Confirmation/Confirmation";
import { useContext } from "react";
import { AuthContext } from "../../../globals/AuthContext";
import { useParams } from "react-router-dom";

let options = [
  "Uploaded",
  "Generated",
  "Augmented",
  "Verified",
  "Not Verified",
  "Multiple-Choice",
];
const VerifyDataset = (props) => {
  const ctx = useContext(AuthContext);

  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(25);
  const [allPrompts, setAllPrompts] = useState([]);
  const [prompts, setPrompts] = useState([]);
  const [selectedPrompt, setSelectedPrompt] = useState({});
  const [open, setOpen] = useState(false);
  const [editedPrompt, setEditedPrompt] = useState("");
  const [editedResponse, setEditedResponse] = useState(null);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [deleteFilter, setDeleteFilter] = useState(false);
  const [deleteSelection, setDeleteSelections] = useState([]);
  const [searchInput, setSearchInput] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [multiConfirm, setMultiConfirm] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  const [refresh, setRefresh] = useState(false);
  const [snackInfo, setSnackInfo] = useState({
    open: false,
    severity: "success",
    msg: "",
  });
  const [groundTruthStatus, setGroundTruthStatus] = useState(false);

  const [anchorEle, setAnchorEle] = React.useState(null);
  const params = useParams();

  const handlePopoverOpen = (event) => {
    setAnchorEle(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEle(null);
  };

  const openA = Boolean(anchorEle);

  const openMenu = Boolean(anchorEl);

  const handleChangeSearchInput = (event) => {
    setSearchInput(event.target.value);
    let filteredList = allPrompts.filter(
      (item) =>
        item.question.includes(event.target.value) ||
        item.answer.includes(event.target.value)
    );
    setPrompts(filteredList);
    setPage(0);
  };

  const handleChangeDeletefilter = () => {
    if (deleteFilter) {
      toggleMultiConfirm();
    }
    setDeleteFilter((prev) => !prev);
  };

  const handleChangeDeleteSelection = (id) => {
    if (deleteSelection.indexOf(id) > -1) {
      setDeleteSelections((prev) => prev.filter((item) => item !== id));
    } else {
      setDeleteSelections((prev) => [...prev, id]);
    }
  };

  const handleAddSelectedOptions = (value) => {
    setSelectedOptions((prev) => [...prev, value]);
  };

  const handleRemoveSelectedOptions = (value) => {
    setSelectedOptions((prev) => prev.filter((item) => item !== value));
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const toggleModal = () => {
    setOpen((prev) => !prev);
  };

  const handleChangeEditedPrompt = (event) => {
    setEditedPrompt(event.target.innerText);
  };

  const handleChangeEditedResponse = (event) => {
    setEditedResponse(event.target.innerText);
  };

  const handleSubmitVerify = () => {
    const data = {
      dataset_id: props.datasetId,
      question: editedPrompt,
      new_answer: editedResponse,
      is_verified: true,
    };
    VerifyPromptResponse(data).then((result) => {
      getPromptResponseList();
      setOpen(false);
    });
  };

  const getPromptResponseList = () => {
    getPromptResponses(props.datasetId).then((results, error) => {
      setAllPrompts(results.responses);
      setPrompts(results.responses);
      setLoading(false);
    });
  };

  const deleteBulkDatasetPrompts = () => {
    deleteBulkPrompts(deleteSelection).then((res) => {
      getPromptResponseList();
      setSnackInfo({
        open: true,
        severity: "success",
        msg: res.message,
      });
    });
  };

  const deleteSelectedPrompt = () => {
    deleteDatasetPrompt(selectedPrompt._id).then((res) => {
      getPromptResponseList();
      setSnackInfo({
        open: true,
        severity: "success",
        msg: res.message,
      });
    });
  };

  const toggleConfirm = () => {
    setConfirm((prev) => !prev);
  };

  const toggleMultiConfirm = () => {
    setMultiConfirm((prev) => !prev);
  };

  const handleCloseSnackBar = () => {
    setSnackInfo({
      open: false,
      severity: "success",
      msg: "",
    });
  };

  const generateGroundTruthNow = () => {
    generateGroundTruth(params.id).then((res) => {
      setSnackInfo({
        open: true,
        severity: "success",
        msg: res.successful_updates + " " + res["message"],
      });
      setGroundTruthStatus(true);
    });
  };

  useEffect(() => {
    getPromptResponseList();
  }, []);

  useEffect(() => {
    let filteredList = [];
    let temp = [];
    let flag = true;

    // Handle source filters: Uploaded, Generated, Augmented
    if (selectedOptions.includes("Uploaded")) {
      flag = false;
      temp.push(...allPrompts.filter((item) => item.source === "Uploaded"));
    }

    if (selectedOptions.includes("Generated")) {
      flag = false;
      temp.push(...allPrompts.filter((item) => item.source === "Generated"));
    }

    if (selectedOptions.includes("Augmented")) {
      flag = false;
      temp.push(...allPrompts.filter((item) => item.source === "Augmented"));
    }

    if (selectedOptions.includes("Multiple-Choice")) {
      flag = false;
      temp.push(
        ...allPrompts.filter((item) => item.question_type === "Multiple-Choice")
      );
    }

    // If no specific source is selected, use all prompts
    if (flag) {
      filteredList = [...allPrompts];
    } else {
      filteredList = [...temp];
    }

    temp = [];

    // Handle verification filters
    if (
      selectedOptions.includes("Verified") &&
      !selectedOptions.includes("Not Verified")
    ) {
      filteredList = filteredList.filter((pmt) => pmt.is_verified);
    }

    if (
      !selectedOptions.includes("Verified") &&
      selectedOptions.includes("Not Verified")
    ) {
      filteredList = filteredList.filter((pmt) => !pmt.is_verified);
    }
    // Set filtered prompts and ensure new reference for triggering re-render
    setPrompts([...filteredList]); // Making a new array reference here to trigger re-render
    setPage(0);
  }, [selectedOptions, allPrompts]);

  return (
    <Stack className={styles.main} gap={"1rem"}>
      <Stack
        direction="row"
        justifyContent={"end"}
        alignItems={"center"}
        gap={"0.5rem"}
      >
        <div>
          <Typography
            aria-owns={openA ? "mouse-over-popover" : undefined}
            aria-haspopup="true"
            onMouseEnter={handlePopoverOpen}
            onMouseLeave={handlePopoverClose}
          >
            <IconButton
              style={{
                color: groundTruthStatus ? "green" : "red",
                // backgroundColor: "#FD8A8A",
                borderRadius: "0.25rem",
                border: groundTruthStatus ? "1px solid green" : "1px solid red",
              }}
              onClick={generateGroundTruthNow}
            >
              {groundTruthStatus ? (
                <VerifiedOutlinedIcon />
              ) : (
                <PriorityHighIcon />
              )}
            </IconButton>
          </Typography>
          <Popover
            id="mouse-over-popover"
            sx={{ pointerEvents: "none" }}
            open={openA}
            anchorEl={anchorEle}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
            onClose={handlePopoverClose}
            disableRestoreFocus
          >
            <Typography sx={{ p: 1 }}>Update Pending Items</Typography>
          </Popover>
        </div>

        <IconButton
          style={{
            color: "white",
            backgroundColor: "#4546D9",
            borderRadius: "0.25rem",
          }}
        >
          <DownloadingIcon />
        </IconButton>
        <IconButton
          style={{
            color: "white",
            backgroundColor: "#FD8A8A",
            borderRadius: "0.25rem",
          }}
          onClick={handleChangeDeletefilter}
        >
          <DeleteOutlineOutlinedIcon />
        </IconButton>
        <div>
          <IconButton
            color="primary"
            style={{ border: "1px solid #BFBFBF", borderRadius: "0.25rem" }}
            aria-label="more"
            id="long-button"
            aria-controls={open ? "long-menu" : undefined}
            aria-expanded={open ? "true" : undefined}
            aria-haspopup="true"
            onClick={handleClick}
          >
            <FilterListIcon />
          </IconButton>
          <Menu
            id="long-menu"
            MenuListProps={{
              "aria-labelledby": "long-button",
            }}
            anchorEl={anchorEl}
            open={openMenu}
            onClose={handleClose}
            PaperProps={{
              style: {
                // maxHeight: ITEM_HEIGHT * 4.5,
                width: "20ch",
              },
            }}
          >
            {options.map((option) => (
              <MenuItem
                key={option}
                value={option}
                selected={selectedOptions.indexOf(option) > -1}
                onClick={() =>
                  selectedOptions.indexOf(option) > -1
                    ? handleRemoveSelectedOptions(option)
                    : handleAddSelectedOptions(option)
                }
              >
                <Checkbox checked={selectedOptions.indexOf(option) > -1} />
                <ListItemText primary={option} />
              </MenuItem>
            ))}
          </Menu>
        </div>
      </Stack>
      <Paper>
        <Paper className={styles.header}>
          Inputs
          <Paper
            component="form"
            sx={{
              display: "flex",
              alignItems: "center",
              width: 400,
            }}
          >
            <IconButton sx={{ p: "5px" }} aria-label="menu">
              <SearchIcon />
            </IconButton>
            <InputBase
              sx={{ ml: 1, flex: 1 }}
              placeholder="Search Inputs"
              value={searchInput}
              onChange={handleChangeSearchInput}
              //   inputProps={{ "aria-label": "search google maps" }}
            />
          </Paper>
          <Button
            style={{ border: "1px solid #DCDCE4", color: "#898B9B" }}
            variant="outlined"
            startIcon={<SwapVertIcon />}
          >
            Sort: Date by
          </Button>
        </Paper>

        <div className={styles.content}>
          {loading === true && (
            <Stack width="100%" direction="row" justifyContent="center">
              <CircularProgress />
            </Stack>
          )}
          {loading === false &&
            prompts?.length > 0 &&
            prompts
              .slice(page * rowPage, page * rowPage + rowPage)
              .map((item, index) => {
                const uniqueRowNumber = page * rowPage + index;
                // return <Paper>{uniqueRowNumber}</Paper>
                let temp =
                  ctx.projectSubType === "P2I" ? (
                    <Paper
                      className={styles.promptBox}
                      onClick={() => {
                        if (deleteFilter) {
                          handleChangeDeleteSelection("101");
                        } else {
                          // setSelectedPrompt(item);
                          // setEditedPrompt(item.question);
                          // setEditedResponse(item.answer);
                          toggleModal();
                        }
                      }}
                    >
                      <Stack gap="0.5rem">
                        <Stack
                          direction={"row"}
                          justifyContent={"space-between"}
                        >
                          <div
                            style={{ width: "100%" }}
                            className={styles.firstLayer}
                          >
                            {true ? (
                              <img src={verifiedCommentIcon} alt="verified" />
                            ) : (
                              <img src={commentIcon} alt="unverified" />
                            )}

                            <Chip
                              style={{ height: "1rem", fontSize: "9px" }}
                              label={"Generated"}
                              variant="outlined"
                              color="primary"
                              size="small"
                            />
                            <div
                              style={{
                                width: "100%",
                                display: "flex",
                                direction: "row",
                                justifyContent: "end",
                              }}
                            ></div>
                            {false && (
                              <Avatar
                                src={adversarialAttackIcon}
                                sx={{
                                  fontSize: "12px",
                                  width: 20,
                                  height: 20,
                                  border: "1px solid black",
                                }}
                              />
                            )}
                          </div>
                          {deleteFilter && (
                            <Checkbox
                              checked={deleteSelection.indexOf("101") > -1}
                              style={{ padding: 0 }}
                              size="small"
                            />
                          )}
                        </Stack>
                        <div className={styles.question}>
                          {item.prompt.substring(0, 75)}
                          {item.prompt.length > 75 ? "...?" : "?"}
                        </div>
                        <div className={styles.response}>
                          <img
                            src={index % 2 ? dummyP2I : item.image_url}
                            style={{
                              height: "6rem",
                              width: "100%",
                              borderRadius: "0.25rem",
                            }}
                          />
                        </div>
                      </Stack>
                    </Paper>
                  ) : (
                    <Paper
                      className={styles.promptBox}
                      onClick={() => {
                        if (deleteFilter) {
                          handleChangeDeleteSelection(item._id);
                        } else {
                          setSelectedPrompt(item);
                          setEditedPrompt(item.question);
                          setEditedResponse(
                            ctx.projectSubType === "GEN" &&
                              item.question_type === "Multiple-Choice"
                              ? item.options
                              : item.answer
                          );
                          toggleModal();
                        }
                      }}
                    >
                      <Stack gap="0.5rem">
                        <Stack
                          direction={"row"}
                          justifyContent={"space-between"}
                        >
                          <div
                            style={{ width: "100%" }}
                            className={styles.firstLayer}
                          >
                            {item.is_verified ? (
                              <img src={verifiedCommentIcon} alt="verified" />
                            ) : (
                              <img src={commentIcon} alt="unverified" />
                            )}

                            <Chip
                              style={{ height: "1rem", fontSize: "9px" }}
                              label={item.source}
                              variant="outlined"
                              color="primary"
                              size="small"
                            />
                           {item?.augmentedType && <Chip
                              style={{ height: "1rem", fontSize: "9px" }}
                              label={item.augmentedType}
                              variant="outlined"
                              color="primary"
                              size="small"
                            />}
                            <div
                              style={{
                                width: "100%",
                                display: "flex",
                                direction: "row",
                                justifyContent: "end",
                              }}
                            ></div>
                            {item.augmentedType === "Alter Key Entities" && (
                              <IconButton
                                size="small"
                                style={{
                                  height: "1rem",
                                  color: groundTruthStatus ? "green" : "red",
                                  // backgroundColor: "#FD8A8A",
                                  borderRadius: "0.25rem",
                                  // border: "1px solid red",
                                  fontSize: "0.5rem",
                                }}
                              >
                                {groundTruthStatus ? (
                                  <VerifiedOutlinedIcon />
                                ) : (
                                  <PriorityHighIcon />
                                )}
                              </IconButton>
                            )}
                            {item.marked_adversarial && (
                              <Avatar
                                src={adversarialAttackIcon}
                                sx={{
                                  fontSize: "12px",
                                  width: 20,
                                  height: 20,
                                  border: "1px solid black",
                                }}
                              />
                            )}
                          </div>
                          {deleteFilter && (
                            <Checkbox
                              checked={deleteSelection.indexOf(item._id) > -1}
                              style={{ padding: 0 }}
                              size="small"
                            />
                          )}
                        </Stack>
                        <div className={styles.question}>
                          {item.question.substring(0, 75)}
                          {ctx.projectSubType !== "SUM" &&
                            (item.question.length > 75 ? "...?" : "?")}
                          {ctx.projectSubType === "SUM" &&
                            (item.question.length > 75 ? "..." : "")}
                        </div>
                        <div className={styles.response}>
                          {ctx.projectSubType === "GEN" &&
                          item.question_type === "Multiple-Choice"
                            ? item.options[0].substring(0, 80)
                            : item.answer === undefined ? "" : item.answer.substring(0, 80)}
                          {ctx.projectSubType === "GEN" &&
                          item.question_type === "Multiple-Choice"
                            ? "..."
                            : item.answer === undefined ? "" : item.answer.length > 80
                            ? "..."
                            : ""}
                        </div>
                      </Stack>
                    </Paper>
                  );

                return temp;
              })}
        </div>

        <Paper>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={prompts.length}
            rowsPerPage={rowPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Paper>

      <Modal
        open={open}
        onClose={toggleModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "60rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            // overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "90vh", // Set a maximum height to trigger scrolling
            borderRadius: "1rem",
          }}
        >
          <div className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Input Details
            </Typography>
            <IconButton onClick={toggleModal}>
              {" "}
              <CloseIcon />
            </IconButton>
          </div>
          <Stack
            className={styles.modalContent}
            style={{ maxHeight: "65vh", overflow: "auto" }}
            gap="0.5rem"
          >
            <Stack direction="row" gap="0.5rem">
              <Chip
                style={{ height: "1.5rem", fontSize: "14px" }}
                label={selectedPrompt.source}
                variant="outlined"
                color="primary"
              />
            </Stack>
            <Stack direction="row">
              {ctx.projectSubType !== "SUM" && (
                <Stack>
                  <Typography
                    fontSize={"12px"}
                    fontWeight={500}
                    color="#898b9b"
                  >
                    Q.
                  </Typography>
                </Stack>
              )}
              <Stack flexGrow={1}>
                <Typography
                  className={styles.question}
                  // width="80%"
                  contentEditable
                  component="div"
                  onBlur={handleChangeEditedPrompt}
                  fontSize="16px"
                  // fontWeight={500}
                  color="#484A56"
                >
                  {selectedPrompt.question}
                </Typography>
              </Stack>
            </Stack>

            <div className={styles.modalResponse}>
              <Typography fontSize="1rem" fontWeight={500} color={"black"}>
                Response :{" "}
              </Typography>
              <Typography
                contentEditable
                component="div"
                onBlur={handleChangeEditedResponse}
              >
                {ctx.projectSubType === "SUM"
                  ? Object.keys(
                      JSON.parse(
                        selectedPrompt.answer ? selectedPrompt.answer : "{}"
                      )
                    ).map((it) => (
                      <div>
                        <div
                          style={{
                            fontWeight: 500,
                            width: "100%",
                          }}
                        >
                          {it}
                        </div>
                        <p style={{ fontWeight: 300, margin: "0.5rem 0" }}>
                          {JSON.parse(selectedPrompt.answer)[it]}
                        </p>
                      </div>
                    ))
                  : ctx.projectSubType === "GEN" &&
                    selectedPrompt.question_type === "Multiple-Choice"
                  ? selectedPrompt.options.map((item, index) => {
                      return <div key={index}>{item}</div>;
                    })
                  : selectedPrompt.answer}
              </Typography>
            </div>
          </Stack>
          <div className={styles.modalFooter}>
            <Button
              className={styles.saveBtn}
              variant="contained"
              endIcon={<ArrowForwardIcon />}
              onClick={handleSubmitVerify}
              size="small"
            >
              Verify
            </Button>
            <Button
              className={styles.deleteBtn}
              endIcon={<img src={deleteIcon} alt="Delete" />}
              color="error"
              size="small"
              onClick={toggleConfirm}
            >
              Delete
            </Button>
          </div>
        </Box>
      </Modal>
      <Confirmation
        open={confirm}
        toggleConfirm={toggleConfirm}
        handleSubmit={() => {
          deleteSelectedPrompt();
          toggleConfirm();
          toggleModal();
        }}
        message="Are you sure you want to delete this prompt?"
      />
      <Snackbar
        open={snackInfo.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackBar}
      >
        <Alert
          onClose={handleCloseSnackBar}
          severity={snackInfo.severity}
          variant="filled"
          sx={{ width: "100%" }}
        >
          {snackInfo.msg}
        </Alert>
      </Snackbar>
      <Confirmation
        open={multiConfirm}
        toggleConfirm={toggleMultiConfirm}
        handleSubmit={() => {
          deleteBulkDatasetPrompts();
          toggleMultiConfirm();
        }}
        message="Are you sure you want to delete selected prompts?"
      />
    </Stack>
  );
};

export default VerifyDataset;
