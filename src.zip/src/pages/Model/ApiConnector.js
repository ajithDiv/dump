import React, { useContext, useEffect, useState } from "react";
import classes from "./ApiConnector.module.css";
import { AuthContext } from "../../globals/AuthContext";
import {
  createModelConfiguration,
  deleteModelConfiguration,
  getAllModelPlusConfigurationList,
  updateModelConfiguration,
} from "../../_services/model.service";
import {
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import Confirmation from "../../components/Confirmation/Confirmation";

const ApiConnector = () => {
  const [configureAuthenticator, setConfigureAuthenticator] = useState(false);
  const [configurationName, setConfigurationName] = useState("");
  const [url, setUrl] = useState("");
  const [method, setMethod] = useState("POST");
  const [requestBodyType, setRequestBodyType] = useState("parameters");
  const [parameters, setParameters] = useState([
    { key: "username", value: "" },
    { key: "password", value: "" },
    { key: "granttype", value: "" },
  ]);
  const [rawBody, setRawBody] = useState("");
  const [headers, setHeaders] = useState([
    { key: "content-type", value: "application/x-www-form-urlencoded" },
  ]);
  const [savedConfigurations, setSavedConfigurations] = useState({});
  const [editIndex, setEditIndex] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  const [refresh, setRefresh] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const ctx = useContext(AuthContext);

  

  const handleParameterChange = (index, key, value) => {
    const newParams = [...parameters];
    newParams[index][key] = value;
    setParameters(newParams);
  };

  const handleHeaderChange = (index, key, value) => {
    const newHeaders = [...headers];
    newHeaders[index][key] = value;
    setHeaders(newHeaders);
  };

  const addParameter = () => {
    setParameters([...parameters, { key: "", value: "" }]);
  };

  const removeParameter = (index) => {
    setParameters(parameters.filter((_, i) => i !== index));
  };

  const addHeader = () => {
    setHeaders([...headers, { key: "", value: "" }]);
  };

  const removeHeader = (index) => {
    setHeaders(headers.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    const newConfiguration = {
      configurationName,
      url,
      method,
      parameters: [...parameters],
      rawBody,
      headers: [...headers],
    };

    if (editIndex !== null) {
      // Editing existing configuration
      const updatedConfigurations = [...savedConfigurations];
      updatedConfigurations[editIndex] = newConfiguration;
      setSavedConfigurations(updatedConfigurations);
      setEditIndex(null); // Exit edit mode
    } else {
      // Adding new configuration
      setSavedConfigurations([...savedConfigurations, newConfiguration]);
    }

    // Optionally, clear form fields after saving
    setConfigurationName("");
    setUrl("");
    setMethod("POST");
    setParameters([
      { key: "username", value: "" },
      { key: "password", value: "" },
      { key: "granttype", value: "" },
    ]);
    setRawBody("");
    setHeaders([
      { key: "content-type", value: "application/x-www-form-urlencoded" },
    ]);
  };

  const editConfiguration = (index) => {
    const data = savedConfigurations[index];
    setConfigureAuthenticator(data.authentication);
    setConfigurationName(data.configurationName);
    setUrl(data.url);
    setMethod(data.method);
    setRequestBodyType(data.requestBodyType);
    if (data.requestBodyType === "parameters") {
      setParameters(data.configurationData)
    }
    if (data.requestBodyType === "raw") {
      setRawBody(JSON.stringify(data.configurationData))
    }
    // setHeaders([...data.headers]);
    setEditIndex(index); // Set edit mode
    setIsEditing(true);
  };


  const deleteConfiguration = (index) => {
    const updatedConfigurations = [...savedConfigurations];
    updatedConfigurations.splice(index, 1);
    setSavedConfigurations(updatedConfigurations);
  };
  const handleSubmit = () => {
    const data = {
      projectName: ctx.projectName,
      datasetId: "",
      configurationName: configurationName,
      url: url,
      configurationData:
        requestBodyType === "parameters" ? parameters : JSON.parse(rawBody),
      authentication: configureAuthenticator,
      method: method,
      requestBodyType: requestBodyType
    };

    if (isEditing) {
      data["id"] = savedConfigurations[editIndex]._id
      updateModelConfiguration(data).then(result => {
        getAllModelPlusConfigurationList(ctx.projectName).then((response) => {
          setSavedConfigurations(response.data);
        });
      })
    } else {
      createModelConfiguration(data).then((result) => {
        getAllModelPlusConfigurationList(ctx.projectName).then((response) => {
          setSavedConfigurations(response.data);
        });
      });
    }
  };

  const getModelPlusConfigurationList = () => {
    getAllModelPlusConfigurationList(ctx.projectName).then((result) => {
      setSavedConfigurations(result.data);
    });
  };

  const toggleConfirm = () => {
    setConfirm(prev => !prev);
  }
  
  const handleDeleteModelConfiguration = (id) => {
    deleteModelConfiguration(id).then((result) => {
      setRefresh(true);
    });
  };


  useEffect(() => {
    if (refresh) {
      getModelPlusConfigurationList();
      setRefresh(false);
    }
  }, [refresh]);

  useEffect(() => {
    getModelPlusConfigurationList();
  },[])

  return (
    <div className={classes.api_connector}>
      <h2>Configure API Connector</h2>
      <div className={classes.form_group}>
        <label>
          Do you want to configure authenticator ?
          <input
            type="checkbox"
            checked={configureAuthenticator}
            onChange={() => setConfigureAuthenticator(!configureAuthenticator)}
          />
        </label>
      </div>
      <div className={classes.form_group}>
        <label>Configuration Name</label>
        <input
          type="text"
          value={configurationName}
          onChange={(e) => setConfigurationName(e.target.value)}
          placeholder="Enter Configuration Name"
          disabled={isEditing}
        />
      </div>
      <div className={classes.form_group}>
        <label>URL</label>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL"
        />
      </div>
      <div className={classes.form_group}>
        <label>Method</label>
        <select value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="GET">GET</option>
          <option value="POST">POST</option>
          <option value="PUT">PUT</option>
          <option value="DELETE">DELETE</option>
        </select>
      </div>
      <div className={classes.form_group}>
        <label>Request Body</label>
        <div className={classes.radio_buttons}>
          <label>
            <input
              type="radio"
              value="parameters"
              checked={requestBodyType === "parameters"}
              onChange={() => setRequestBodyType("parameters")}
            />
            Parameter(s)
          </label>
          <label>
            <input
              type="radio"
              value="raw"
              checked={requestBodyType === "raw"}
              onChange={() => setRequestBodyType("raw")}
            />
            Raw
          </label>
        </div>
        {requestBodyType === "parameters" ? (
          <div>
            {parameters.map((param, index) => (
              <div key={index} className={classes.parameter_group}>
                <input
                  type="text"
                  value={param.key}
                  onChange={(e) =>
                    handleParameterChange(index, "key", e.target.value)
                  }
                  placeholder="Parameter Key"
                />
                <input
                  type="text"
                  value={param.value}
                  onChange={(e) =>
                    handleParameterChange(index, "value", e.target.value)
                  }
                  placeholder="Parameter Value"
                />
                <button
                  className={classes.remove_button}
                  onClick={() => removeParameter(index)}
                >
                  -
                </button>
              </div>
            ))}
            <button className={classes.add_button} onClick={addParameter}>
              +
            </button>
          </div>
        ) : (
          <textarea
            value={rawBody}
            onChange={(e) => setRawBody(e.target.value)}
            placeholder="Enter raw body"
            className={classes.raw_textarea}
          />
        )}
      </div>
      <div className={classes.form_group}>
        <label>Header(s)</label>
        <div>
          {headers.map((header, index) => (
            <div key={index} className={classes.header_group}>
              <input
                type="text"
                value={header.key}
                onChange={(e) =>
                  handleHeaderChange(index, "key", e.target.value)
                }
                placeholder="Header Key"
              />
              <input
                type="text"
                value={header.value}
                onChange={(e) =>
                  handleHeaderChange(index, "value", e.target.value)
                }
                placeholder="Header Value"
              />
              <button
                className={classes.remove_button}
                onClick={() => removeHeader(index)}
              >
                -
              </button>
            </div>
          ))}
          <button className={classes.add_button} onClick={addHeader}>
            +
          </button>
        </div>
      </div>
      <div className={classes.button_group}>
        {/* <button className={classes.save_button} onClick={handleSave}>
          {editIndex !== null ? "Update" : "Save"} */}
        <button className={classes.save_button} onClick={handleSubmit}>
          {isEditing ? "Update" : "Save"}
        </button>
        <button
          className={classes.cancel_button}
          onClick={() => {
            requestBodyType === "parameters"
              ? setParameters([])
              : setRawBody("");
            setHeaders([]);
          }}
        >
          Cancel
        </button>
      </div>

      {/* Render saved configurations table */}
      {Object.keys(savedConfigurations).length > 0 && (
        <div className={classes.saved_configurations}>
          <h3>Saved Configurations</h3>
          <TableContainer component={Paper}>
            <Table aria-label="Material-UI Table">
              <TableHead sx={{ background: "#111270", color: "#fff" }}>
                <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Configuration Name
                  </TableCell>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    URL
                  </TableCell>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Method
                  </TableCell>
                  <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {savedConfigurations.map((config, index) => (
                  <TableRow
                    style={
                      index % 2
                        ? { background: "#F6F6F6" }
                        : { background: "white" }
                    }
                    key={index}
                  >
                    <TableCell>{config.configurationName}</TableCell>
                    <TableCell>{config.url}</TableCell>
                    <TableCell>{config.method}</TableCell>
                    <TableCell>
                      {/* <button onClick={() => editConfiguration(index)}>
                        Edit
                      </button>
                      &nbsp;&nbsp;
                      <button onClick={() => deleteConfiguration(index)}>
                        Delete
                      </button> */}
                      <Stack direction="row">
                        <IconButton color="primary" size="small">
                          <EditIcon fontSize="inherit" onClick={() => editConfiguration(index)} />
                        </IconButton>
                        <IconButton color="error" size="small">
                          <DeleteIcon fontSize="inherit"
                            onClick={() => {
                              setSelectedId(config._id);
                              toggleConfirm();
                            }} />
                        </IconButton>
                      </Stack>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      )}
      <Confirmation
        open={confirm}
        toggleConfirm={toggleConfirm}
        handleSubmit={() => {
          handleDeleteModelConfiguration(selectedId);
          toggleConfirm();
        }}
        message="Are you sure you want to delete this?"
      />
    </div>
  );
};

export default ApiConnector;
