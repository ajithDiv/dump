import {
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  IconButton,
  InputBase,
  InputLabel,
  MenuItem,
  Modal,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Slide,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import React, {
  forwardRef,
  useContext,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import CloseIcon from "@mui/icons-material/Close";
import { AddCircleOutline } from "@mui/icons-material";
import PromptTemplate from "./PromptTemplate";
import { saveCustomMetricData } from "../../../_services/genai_dataset.service";
import { AuthContext } from "../../../globals/AuthContext";

const variableTypeList = ["String", "Score"]; //, "Boolean", "Number", "Percentage"
const conditionTableHeaders = [
  "Condition",
  "Variable",
  "Operation",
  "Value",
  "Then",
  "Custom Then",
  "Display Status",
  "",
];
const stringOperations = [
  "Refusal detection",
  "Entity Co-occurrence",
  "% Special Characters",
  "Average Word Length",
  "Average Words Per Sentence",
  "Compression Ratio",
  "Email Addresses Count",
  "Invalid Link Syntax",
  "Lexical Density",
  "Text Length",
  "Unique Noun Count",
  "URLs Count",
  "Regex",
];
// [
//   "Char Length",
//   "Word Count",
//   "Contains",
//   "Does not Contain",
// ];
const stringOperationsDescription = {
  "Refusal detection": "Identifies if the text contains refusal-related words.",
  "Entity Co-occurrence": "Counts occurrences of specific named entities in the text.",
  "% Special Characters": "Calculates the number of special characters in a given text",
  "Average Word Length": "Computes the average length of words in the text.",
  "Average Words Per Sentence": "Determines the average number of words per sentence.",
  "Compression Ratio": "Measures how much the text is reduced compared to an output version.",
  "Email Addresses Count": "Counts the number of email addresses present in the text.",
  "URLs Count": "Counts the number of URLs present in the text.",
  "Lexical Density": "Computes the ratio of unique words to the total number of words.",
  "Text Length": "Returns the total number of characters in the text.",
  "Unique Noun Count": "Counts the number of distinct nouns in the text.",
  "Invalid Link Syntax": "Calculates the ratio of incorrectly formatted URLs in the text.",
  "Regex": "Matches predefined patterns (e.g., emails, dates, phone numbers) in the text."
}
const booleanOperations = ["&&", "||", "!"];
const numberOperations = ["==", "!=", "<", "<=", ">", ">="];
const percentageOperations = ["==", "!=", "<", "<=", ">", ">="];
const scoreOperations = ["==", "!=", "<", "<=", ">", ">="];
const INITIAL_ROW = {
  condition: "If",
  variable: "",
  operation: "",
  value: "",
  then: "Pass",
  customThen: "",
  displayStatus: "Pass-Green",
};
const emptyData = {
  name: "",
  description: "",
  promptTemplate: { level_1: "", level_2: "", level_3: "" },
};

const promptTypes = ["Single Level", "2 Level Prompt", "3 Level Prompt"];
const levels = ["level_1", "level_2", "level_3"];
const scores = Array(11)
  .fill()
  .map((_, i) => i / 10);

const CustomMetric = ({ open, onClose, customMetric }) => {
  const ctx = useContext(AuthContext);
  const [modalState, setModalState] = useState(open);
  const [varibaleNameList, setVariableNameList] = useState(
    customMetric.conditions.map((row) => row.output_key)
  );
  let varObj = {};
  customMetric.conditions.map((row) => {
    varObj[row.output_key] = "String";
  });
  const [variableTypeMapObject, setVariableTypeMapObject] = useState(varObj);
  const [rows, setRows] = useState(
    customMetric.conditions.map((row) => {
      let rowObj = {};
      rowObj["condition"] = "If";
      rowObj["variable"] = row["output_key"];
      setVariableTypeMapObject((prevState) => ({
        ...prevState,
        [row["output_key"]]: row["output_key_type"],
      }));
      rowObj["variableType"] = row["output_key_type"];
      rowObj["operation"] = row["operator"];
      rowObj["value"] = row["threshold_value"];
      rowObj["then"] = row["pass_fail"];
      rowObj["customThen"] = row["custom_name"];
      rowObj["displayStatus"] = row["pass_fail"] + "-" + row["color"];
      return rowObj;
    })
  );
  const [customMetricData, setCustomMetricData] = useState(customMetric);
  const [promptType, setPromptType] = useState(
    promptTypes[+customMetric.level - 1]
  );
  const [selectedVariable, setSelectedVariable] = useState("");
  const [metricType, setMetricType] = useState("Custom Metric");
  const [staticMetricList, setStaticMetricList] = useState([]);
  const [staticRows, setStaticRows] = useState([INITIAL_ROW]);

  const handleChangeCustomMetricName = (event) => {
    const name = event.target.value;
    setCustomMetricData((prev) => ({ ...prev, name }));
  };

  const handleChangeCustomMetricDescription = (event) => {
    const description = event.target.value.trim();
    setCustomMetricData((prev) => ({ ...prev, description }));
  };

  const handleChangeCustomPromptTemplate = (key, value, level) => {
    setCustomMetricData((prev) => {
      let template = { ...prev };
      template.prompts[level] = value;
      if (varibaleNameList.length == 0) {
        setRows([{ ...INITIAL_ROW }]);
      }
      return template;
    });
  };

  const handleChangeVariableTypeMapObject = (selectedValue, key) => {
    setVariableTypeMapObject((prevState) => ({
      ...prevState,
      [key]: selectedValue,
    }));
  };

  const handleChangeVariableList = (list) => {
    setVariableNameList(list);
  };

  const handleAddRow = () => {
    const newRow = { ...INITIAL_ROW };
    setRows((prevState) => [...prevState, newRow]);
  };

  const handleSubmtCustomMetrice = () => {
    const obj = {};
    obj.name = customMetricData.name;
    obj.description = customMetricData.description;
    obj.thresholdValue = 0.5;
    obj.inverse = false;
    obj.enabled = false;
    obj.level = promptType === "Single Level" ? 1 : promptType.split(" ")[0];
    obj.prompts = customMetricData.prompts;
    obj.project_type=ctx.projectSubType;
    obj.static_metrics=staticMetricList.map(item=>{
      return ({
        "name": item,
        "enabled": true
      })
    })
 
    // Object.values(customMetricData.promptTemplate)
    // .flat()
    // .filter((template) => template != "");
    const conditions = rows.map((row) => {
      let rowObj = {};
      rowObj["output_key"] = row["variable"];
      rowObj["output_key_type"] = variableTypeMapObject[row["variable"]];
      rowObj["operator"] = row["operation"];
      rowObj["threshold_value"] = row["value"];
      rowObj["pass_fail"] = row["then"];
      rowObj["custom_name"] = row["customThen"];
      rowObj["color"] = row["displayStatus"].split("-")[1];
      return rowObj;
    });
    if (conditions.length > 0) {
      let lastCondition = conditions[conditions.length - 1];
      if (
        lastCondition["output_key"] === "" ||
        lastCondition["operator"] === "" ||
        lastCondition["threshold_value"] === ""
      ) {
        conditions.pop();
      }
    }
    obj.conditions = conditions;
    saveCustomMetricData(obj);
    closeModal();
  };

  const closeModal = () => {
    setCustomMetricData(emptyData);
    onClose();
    setModalState((prev) => !prev);
  };

  const handlePromptTypeChange = (event) => {
    setPromptType(event.target.value);
    setVariableNameList([]);
    setCustomMetricData((prev) => ({
      ...prev,
      promptTemplate: { level_1: "", level_2: "", level_3: "" },
    }));
  };

  return (
    <Modal
      open={modalState}
      onClose={closeModal}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          maxWidth: "90%",
          width: "80%",
          bgcolor: "background.paper",
          boxShadow: 12,
          overflow: "hidden",
          overflowY: "scroll",
          maxHeight: "95vh",
          borderRadius: "1rem",
        }}
      >
        <Paper style={{ padding: "0.5rem 1rem" }}>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems={"center"}
          >
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Create Custom Metric
            </Typography>
            <IconButton onClick={closeModal}>
              <CloseIcon />
            </IconButton>
          </Stack>
        </Paper>
        <div style={{ padding: "1rem" }}>
          <FormControl
            style={{
              display: "flex",
              alignItems: "center",
              flexDirection: "row",
              gap: "1rem",
            }}
          >
            <FormLabel id="demo-row-radio-buttons-group-label">
              Select Metric Type :
            </FormLabel>
            <RadioGroup
              row
              aria-labelledby="demo-row-radio-buttons-group-label"
              name="row-radio-buttons-group"
              value={metricType}
              onChange={(e) => setMetricType(e.target.value)}
            >
              <FormControlLabel
                value="Custom Metric"
                control={<Radio />}
                label="Custom Metric"
              />
              <FormControlLabel
                value="Static Metric"
                control={<Radio />}
                label="Static Metric"
              />
            </RadioGroup>
          </FormControl>
          {metricType === "Custom Metric" && (
            <>
              <Stack direction="row" alignItems="center" gap="1rem">
                <FormLabel>Choose Prompt Type :</FormLabel>
                <FormControl>
                  <Select
                    labelId="prompt-type-label"
                    id="prompt-type"
                    value={promptType}
                    size="small"
                    onChange={handlePromptTypeChange}
                  >
                    {promptTypes.map((type) => (
                      <MenuItem key={type} value={type}>
                        {type}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Stack>
              <TextField
                fullWidth
                id="outlined-basic"
                label="Name"
                variant="outlined"
                margin="dense"
                name="name"
                required
                value={customMetricData.name}
                onChange={handleChangeCustomMetricName}
              />
              <TextField
                fullWidth
                id="outlined-basic"
                label="Description"
                variant="outlined"
                margin="dense"
                name="description"
                multiline
                minRows={2}
                value={customMetricData.description}
                onChange={handleChangeCustomMetricDescription}
              />

              <PromptTemplate
                heading="Level 1"
                promptType={promptType}
                level="level_1"
                levelIndex={0}
                template={customMetricData.prompts[0]}
                setVariableNameList={handleChangeVariableList}
                setVariableTypes={setVariableTypeMapObject}
                handleChangeCustomPromptTemplate={
                  handleChangeCustomPromptTemplate
                }
                setCustomMetricData={setCustomMetricData}
                setSelectedVariable={setSelectedVariable}
              />
              {(promptType === "2 Level Prompt" ||
                promptType === "3 Level Prompt") && (
                  <PromptTemplate
                    heading="Level 2"
                    level="level_2"
                    levelIndex={1}
                    promptType={promptType}
                    template={customMetricData.prompts[1]}
                    varibaleNameList={varibaleNameList["level_2"]}
                    setVariableNameList={handleChangeVariableList}
                    setVariableTypes={setVariableTypeMapObject}
                    handleChangeCustomPromptTemplate={
                      handleChangeCustomPromptTemplate
                    }
                    setCustomMetricData={setCustomMetricData}
                    setSelectedVariable={setSelectedVariable}
                  />
                )}
              {promptType === "3 Level Prompt" && (
                <PromptTemplate
                  heading="Level 3"
                  level="level_3"
                  levelIndex={2}
                  promptType={promptType}
                  template={customMetricData.prompts[2]}
                  varibaleNameList={varibaleNameList["level_3"]}
                  setVariableNameList={handleChangeVariableList}
                  setVariableTypes={setVariableTypeMapObject}
                  handleChangeCustomPromptTemplate={
                    handleChangeCustomPromptTemplate
                  }
                  setCustomMetricData={setCustomMetricData}
                  setSelectedVariable={setSelectedVariable}
                />
              )}
              {/* Variable-Type mapping table */}
              <TableContainer component={Paper} sx={{ mt: 1 }}>
                <Typography variant="h6" sx={{ p: 1 }}>
                  Map the Output
                </Typography>
                <Table sx={{ width: "100%" }} aria-label="simple table">
                  <TableHead sx={{ background: "#111270", color: "#fff" }}>
                    <TableRow>
                      <TableCell sx={{ alignItems: "center", color: "#fff" }}>
                        Variable Name
                      </TableCell>
                      <TableCell
                        sx={{ alignItems: "center", color: "#fff" }}
                        align="center"
                      >
                        Type
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {varibaleNameList?.map((row, index) => (
                      <TableRow
                        key={row}
                        sx={{
                          "&:last-child td, &:last-child th": { border: 0 },
                        }}
                        style={
                          index % 2
                            ? { background: "#F6F6F6" }
                            : { background: "white" }
                        }
                      >
                        <TableCell component="th" scope="row">
                          <FormControl>
                            <RadioGroup
                              aria-labelledby="demo-radio-buttons-group-label"
                              name="radio-buttons-group"
                              value={selectedVariable}
                              onChange={(e) =>
                                setSelectedVariable(e.target.value)
                              }
                            >
                              <FormControlLabel
                                value={row}
                                control={<Radio />}
                                label={row}
                              />
                            </RadioGroup>
                          </FormControl>
                        </TableCell>
                        <TableCell>
                          <FormControl fullWidth>
                            <Select
                              labelId="type-select-label"
                              id="type-simple-select"
                              value={variableTypeMapObject[row]}
                              onChange={(e) =>
                                handleChangeVariableTypeMapObject(
                                  e.target.value,
                                  row
                                )
                              }
                            >
                              {variableTypeList.map((value, idx) => (
                                <MenuItem
                                  key={`${value}_{idx}`}
                                  value={value}
                                  defaultValue={idx === 0 && value}
                                >
                                  {value}
                                </MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

              {metricType === "Custom Metric" && (
                <TableContainer component={Paper} sx={{ my: 1 }}>
                  <Typography variant="h6" sx={{ p: 1 }}>
                    Condition
                  </Typography>
                  <Table aria-label="simple table">
                    <TableHead sx={{ background: "#111270", color: "#fff" }}>
                      <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                        {conditionTableHeaders.map((header) => (
                          <TableCell key={header} sx={{ color: "#fff" }}>
                            {header}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.values(varibaleNameList).flat().length !== 0 &&
                        rows.map((row, index) => (
                          <TableRow
                            style={
                              index % 2
                                ? { background: "#F6F6F6" }
                                : { background: "white" }
                            }
                          >
                            <TableCell>{row["condition"]}</TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="variable-type-select-label"
                                  id="type-select"
                                  value={row["variable"]}
                                  onChange={(e) => {
                                    const updatedRows = [...rows];
                                    updatedRows[index]["variable"] =
                                      e.target.value;
                                    setRows(updatedRows);
                                  }}
                                >
                                  {Object.values(varibaleNameList)
                                    .flat()
                                    .map((value, idx) => (
                                      <MenuItem
                                        key={`${value}_${idx}`}
                                        value={value}
                                      >
                                        {value}
                                      </MenuItem>
                                    ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="operation-select-label"
                                  id="operation-simple-select"
                                  value={row["operation"]}
                                  onChange={(e) => {
                                    const updatedRows = [...rows];
                                    updatedRows[index].operation = e.target.value;
                                    setRows(updatedRows);
                                  }}
                                >
                                  {variableTypeMapObject[row["variable"]] ===
                                    "String" &&
                                    stringOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                  {variableTypeMapObject[row["variable"]] ===
                                    "Boolean" &&
                                    booleanOperations.map((value) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                  {variableTypeMapObject[row["variable"]] ===
                                    "Number" &&
                                    numberOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                  {variableTypeMapObject[row["variable"]] ===
                                    "Percentage" &&
                                    percentageOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                  {variableTypeMapObject[row["variable"]] ===
                                    "Score" &&
                                    scoreOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              {variableTypeMapObject[row["variable"]] ===
                                "String" && (
                                  <TextField
                                    fullWidth
                                    id="outlined-basic"
                                    variant="outlined"
                                    margin="dense"
                                    name="value"
                                    value={row["value"]}
                                    onChange={(e) => {
                                      const updatedRows = [...rows];
                                      updatedRows[index]["value"] = e.target.value;
                                      setRows(updatedRows);
                                    }}
                                  />
                                )}
                              {variableTypeMapObject[row["variable"]] !==
                                "String" && (
                                  <FormControl fullWidth>
                                    <Select
                                      labelId="value-select-label"
                                      id="value-simple-select"
                                      value={row["value"]}
                                      onChange={(e) => {
                                        const updatedRows = [...rows];
                                        updatedRows[index]["value"] =
                                          e.target.value;
                                        setRows(updatedRows);
                                      }}
                                    >
                                      {variableTypeMapObject[row["variable"]] ===
                                        "Score" &&
                                        scores.map((value, idx) => (
                                          <MenuItem value={value}>{value}</MenuItem>
                                        ))}
                                      {(variableTypeMapObject[row["variable"]] ===
                                        "Percentage" ||
                                        variableTypeMapObject[row["variable"]] ===
                                        "Number") &&
                                        Array(100)
                                          .fill()
                                          .map((_, i) => i + 1)
                                          .map((value, idx) => (
                                            <MenuItem value={value}>
                                              {value}
                                            </MenuItem>
                                          ))}
                                      {variableTypeMapObject[row["variable"]] ===
                                        "Boolean" &&
                                        [0, 1].map((value, idx) => (
                                          <MenuItem value={value}>{value}</MenuItem>
                                        ))}
                                    </Select>
                                  </FormControl>
                                )}
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="then-select-label"
                                  id="then-simple-select"
                                  value={row["then"]}
                                  onChange={(e) => {
                                    const updatedRows = [...rows];
                                    updatedRows[index]["then"] = e.target.value;
                                    setRows(updatedRows);
                                  }}
                                >
                                  {["Pass", "Fail"].map((value, idx) => (
                                    <MenuItem key={value} value={value}>
                                      {value}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              <TextField
                                fullWidth
                                id="outlined-basic"
                                variant="outlined"
                                margin="dense"
                                name="customThen"
                                value={row["customThen"]}
                                onChange={(e) => {
                                  const updatedRows = [...rows];
                                  updatedRows[index]["customThen"] =
                                    e.target.value;
                                  setRows(updatedRows);
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="status-select-label"
                                  id="status-simple-select"
                                  value={row["displayStatus"]}
                                  onChange={(e) => {
                                    const updatedRows = [...rows];
                                    updatedRows[index]["displayStatus"] =
                                      e.target.value;
                                    setRows(updatedRows);
                                  }}
                                >
                                  {["Pass-Green", "Fail-Red"].map(
                                    (value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    )
                                  )}
                                </Select>
                              </FormControl>
                            </TableCell>
                            {index === rows.length - 1 ? (
                              <TableCell>
                                <IconButton
                                  onClick={handleAddRow}
                                  disabled={
                                    row["variable"] === "" ||
                                    row["operation"] === "" ||
                                    row["value"] === ""
                                  }
                                >
                                  <AddCircleOutline />
                                </IconButton>
                              </TableCell>
                            ) : (
                              <TableCell></TableCell>
                            )}
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TableContainer>)}
            </>
          )}
          {metricType === "Static Metric" && (
            <Stack direction="column" gap="0.5rem" >
              <FormLabel>Static Metrices : </FormLabel>
              {
                stringOperations.map((op) => (
                  <FormControlLabel
                    label={op + " - " + stringOperationsDescription[op]}
                    control={<Checkbox
                      checked={staticMetricList.indexOf(op) > -1}
                      onChange={() =>
                        setStaticMetricList((prev) => {
                          if (prev.indexOf(op) > -1) {
                            return prev.filter((metric) => metric !== op);
                          }
                          return [...prev, op];
                        })
                      }
                    />}
                  />
                ))
              }

              {metricType === "Custom Metric" &&
                (<TableContainer component={Paper} sx={{ my: 1 }}>
                  <Typography variant="h6" sx={{ p: 1 }}>
                    Condition
                  </Typography>
                  <Table aria-label="simple table">
                    <TableHead sx={{ background: "#111270", color: "#fff" }}>
                      <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                        {conditionTableHeaders.map((header, ind) => ind > 0 ? (
                          <TableCell key={header} sx={{ color: "#fff" }}>
                            {header}
                          </TableCell>
                        ) : null)}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {
                        staticRows.map((row, index) => (
                          <TableRow
                            style={
                              index % 2
                                ? { background: "#F6F6F6" }
                                : { background: "white" }
                            }
                          >
                            {/* <TableCell>{row["condition"]}</TableCell> */}
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="variable-type-select-label"
                                  id="type-select"
                                  value={row["variable"]}
                                  onChange={(e) => {
                                    setStaticRows(prev => {
                                      const updatedRows = [...prev];
                                      updatedRows[index]["variable"] = e.target.value;
                                      return updatedRows
                                    });
                                  }}
                                >
                                  {stringOperations
                                    .map((value, idx) => (
                                      <MenuItem
                                        key={`${value}_${idx}`}
                                        value={value}
                                      >
                                        {value}
                                      </MenuItem>
                                    ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="operation-select-label"
                                  id="operation-simple-select"
                                  value={row["operation"]}
                                  onChange={(e) => {
                                    setStaticRows(prev => {
                                      const updatedRows = [...prev];
                                      updatedRows[index].operation = e.target.value;
                                      return updatedRows
                                    });
                                  }}
                                >
                                  {row["variable"] === "Regex" &&
                                    stringOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                  {row["variable"] !== "Regex" &&
                                    scoreOperations.map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              {row["variable"] ===
                                "Regex" && (
                                  <TextField
                                    fullWidth
                                    id="outlined-basic"
                                    variant="outlined"
                                    margin="dense"
                                    name="value"
                                    value={row["value"]}
                                    onChange={(e) => {
                                      setStaticRows(prev => {
                                        const updatedRows = [...prev];
                                        updatedRows[index]["value"] = e.target.value;
                                        return updatedRows
                                      });
                                    }}
                                  />
                                )}
                              {row["variable"] !==
                                "Regex" && (
                                  <FormControl fullWidth>
                                    <Select
                                      labelId="value-select-label"
                                      id="value-simple-select"
                                      value={row["value"]}
                                      onChange={(e) => {
                                        setStaticRows(prev => {
                                          const updatedRows = [...prev];
                                          updatedRows[index]["value"] = e.target.value;
                                          return updatedRows
                                        });
                                      }}
                                    >
                                      {
                                        // variableTypeMapObject[row["variable"]] ===
                                        // "Score" &&
                                        scores.map((value, idx) => (
                                          <MenuItem value={value}>{value}</MenuItem>
                                        ))
                                      }
                                      {/* {(variableTypeMapObject[row["variable"]] ===
                                    "Percentage" ||
                                    variableTypeMapObject[row["variable"]] ===
                                      "Number") &&
                                    Array(100)
                                      .fill()
                                      .map((_, i) => i + 1)
                                      .map((value, idx) => (
                                        <MenuItem value={value}>
                                          {value}
                                        </MenuItem>
                                      ))}
                                  {variableTypeMapObject[row["variable"]] ===
                                    "Boolean" &&
                                    [0, 1].map((value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    ))} */}
                                    </Select>
                                  </FormControl>
                                )}
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="then-select-label"
                                  id="then-simple-select"
                                  value={row["then"]}
                                  onChange={(e) => {
                                    setStaticRows(prev => {
                                      const updatedRows = [...prev];
                                      updatedRows[index]["then"] = e.target.value;
                                      return updatedRows
                                    });
                                  }}
                                >
                                  {["Pass", "Fail"].map((value, idx) => (
                                    <MenuItem key={value} value={value}>
                                      {value}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell>
                              <TextField
                                fullWidth
                                id="outlined-basic"
                                variant="outlined"
                                margin="dense"
                                name="customThen"
                                value={row["customThen"]}
                                onChange={(e) => {
                                  setStaticRows(prev => {
                                    const updatedRows = [...prev];
                                    updatedRows[index]["customThen"] = e.target.value;
                                    return updatedRows
                                  });
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <FormControl fullWidth>
                                <Select
                                  labelId="status-select-label"
                                  id="status-simple-select"
                                  value={row["displayStatus"]}
                                  onChange={(e) => {
                                    setStaticRows(prev => {
                                      const updatedRows = [...prev];
                                      updatedRows[index]["displayStatus"] = e.target.value;
                                      return updatedRows
                                    });
                                  }}
                                >
                                  {["Pass-Green", "Fail-Red"].map(
                                    (value, idx) => (
                                      <MenuItem value={value}>{value}</MenuItem>
                                    )
                                  )}
                                </Select>
                              </FormControl>
                            </TableCell>
                            {index === staticRows.length - 1 ? (
                              <TableCell>
                                <IconButton
                                  onClick={() => {
                                    const newRow = { ...INITIAL_ROW };
                                    setStaticRows((prevState) => [...prevState, newRow]);
                                  }}
                                  disabled={
                                    row["variable"] === "" ||
                                    row["operation"] === "" ||
                                    row["value"] === ""
                                  }
                                >
                                  <AddCircleOutline />
                                </IconButton>
                              </TableCell>
                            ) : (
                              <TableCell></TableCell>
                            )}
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                )}
            </Stack>
          )}
        </div>
        <Box margin="0 0 1rem 0" textAlign={"center"}>
          <Button
            centerRipple
            variant="contained"
            onClick={handleSubmtCustomMetrice}
            disabled={
              rows.length === 0 ||
              customMetricData.name.trim().length === 0 ||
              rows[0]["variable"] === "" ||
              rows[0]["operation"] === "" ||
              rows[0]["value"] === ""
            }
          >
            Submit
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default CustomMetric;
