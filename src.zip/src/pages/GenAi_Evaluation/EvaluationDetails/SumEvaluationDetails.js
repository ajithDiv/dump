import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Breadcrumbs,
  Button,
  Chip,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import evaluateSelectedIcon from "../../../assets/genaiIcons/find_in_page _active.png";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import inputIcon from "../../../assets/genaiIcons/contact_support.png";
import responseIcon from "../../../assets/genaiIcons/mark_unread_chat_alt.png";
import { styled } from "@mui/material/styles";
import { getEvaluationRecordData } from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";

const CustomAccordianSummary = styled((props) => (
  <AccordionSummary
    expandIcon={<KeyboardArrowRightIcon sx={{ fontSize: "0.9rem" }} />}
    {...props}
  />
))(({ theme }) => ({
  margin: 0,
  border: "1px solid #E6E6E6",
  borderRadius: "0.5rem 0.5rem 0 0",
  flexDirection: "row-reverse",
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(-90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const SumEvaluationDetails = () => {
  const params = useParams();
  const { state } = useLocation();

  const breadcrumbs = [
    <Link
      style={{ color: "#313B3E", fontWeight: 400, fontSize: "20px" }}
      key="1"
      to={"/genai-assurance/genai_evaluate/evaluation_summary/" + params.id}
    >
      DocsList
    </Link>,
    <Typography
      style={{ fontWeight: 500, fontSize: "20px", color: "#4546d9" }}
      key="3"
    >
      #{state.num}
    </Typography>,
  ];

  const [highlights, setHighlights] = useState([
    {
      input: {
        red: [],
        green: [],
      },
      summary: {
        red: [],
        green: [],
      },
    },
  ]);
  const [data, setData] = useState({});

  const ctx = useContext(AuthContext);

  const handleViewDetails = () => {
    window.open(
      `/genai-assurance/genai_evaluate/evaluation_summary/${params.id}/sum-details/${params.subId}/metric-details`,
      "_blank"
    );
  };

  const handleHighlight = (highlightData) => {
    setHighlights(highlightData);
  };

  const getHighlightedText = (text, highlights) => {
    let parts = []; // Array to hold segments of the text
    let lastIndex = 0; // Track the end of the last processed part

    const addPart = (start, end, color) => {
      if (start > lastIndex) {
        // Add unhighlighted part
        parts.push({ text: text.slice(lastIndex, start), color: null });
      }
      // Add highlighted part
      parts.push({ text: text.slice(start, end), color });
      lastIndex = end; // Update lastIndex to the end of this part
    };

    const redHighlights = highlights.red || [];
    const greenHighlights = highlights.green || [];

    // Combine and sort ranges
    const allHighlights = [
      ...redHighlights.map((range) => ({ range, color: "#FFE0E0" })),
      ...greenHighlights.map((range) => ({ range, color: "#ADEDEA" })),
    ];
    allHighlights.sort((a, b) => a.range[0] - b.range[0]);

    // Process each highlight range
    allHighlights.forEach(({ range: [start, end], color }) => {
      addPart(start, end, color);
    });

    // Add any remaining unhighlighted text
    if (lastIndex < text.length) {
      parts.push({ text: text.slice(lastIndex), color: null });
    }

    // Convert parts to <span> elements
    return parts.map((part, index) => (
      <span key={index} style={{ backgroundColor: part.color }}>
        {part.text}
      </span>
    ));
  };

  useEffect(() => {
    getEvaluationRecordData(params.subId, ctx.projectSubType).then((result) => {
      setData(result.output);
    });
  }, []);

  return (
    <div style={{ margin: "1rem" }}>
      <Stack gap="1rem">
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="medium" />}
            aria-label="breadcrumb"
          >
            {breadcrumbs}
          </Breadcrumbs>
        </Stack>
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="start"
          gap="1rem"
        >
          <Stack width="70%" gap="1rem">
            <Accordion
              square={false}
              variant={"outlined"}
              defaultExpanded
              sx={{ borderRadius: "8px" }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
                sx={{ borderRadius: "8px" }}
              >
                <Stack direction={"row"} alignItems="center" gap="0.2rem">
                  <img src={inputIcon} alt="inputIcon" />
                  <Typography
                    fontSize="18px"
                    fontWeight={500}
                    color={"#484A56"}
                  >
                    Input raw text
                  </Typography>
                </Stack>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "8px",
                }}
              >
                <Typography color={"#484A56"} fontSize="15px" fontWeight={400}>
                  {data.question &&
                    getHighlightedText(data?.question, highlights[0]["input"])}
                </Typography>
              </AccordionDetails>
            </Accordion>
            <Accordion
              square={false}
              variant={"outlined"}
              defaultExpanded
              sx={{ borderRadius: "8px" }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
                sx={{ borderRadius: "8px" }}
              >
                <Stack direction={"row"} alignItems="center" gap="0.2rem">
                  <img src={responseIcon} alt="inputIcon" />
                  <Typography
                    fontSize="18px"
                    fontWeight={500}
                    color={"#484A56"}
                  >
                    Summary
                  </Typography>
                </Stack>
              </AccordionSummary>
              <AccordionDetails
                style={{
                  backgroundColor: "#E7F1F6",
                  margin: "0.5rem",
                  borderRadius: "8px",
                }}
              >
                <Typography fontSize="15px" fontWeight={400} color={"#484A56"}>
                  {data.answer &&
                    getHighlightedText(data?.answer, highlights[0]["summary"])}
                </Typography>
              </AccordionDetails>
            </Accordion>
          </Stack>
          <Stack width="30%">
            <Paper>
              <Paper style={{ height: "auto" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "5px",
                    padding: "15px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      gap: "5px",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <img src={evaluateSelectedIcon} alt="evaluate" width={25} />
                    <Typography
                      fontSize="18px"
                      fontWeight={500}
                      color={"#484A56"}
                    >
                      Evaluate
                    </Typography>
                  </div>
                  <Button onClick={handleViewDetails}>View Details</Button>
                </div>
              </Paper>

              <Stack style={{ padding: "0.5rem 1rem 1rem 1rem" }} gap="0.5rem">
                {data.metrics &&
                  data.metrics.length > 0 &&
                  data?.metrics.map((metric, index) => {
                    return (
                      <Accordion
                        sx={{ borderRadius: "8px" }}
                        // onClick={() => handleHighlight(metric.range)}
                        key={index}
                      >
                        <CustomAccordianSummary
                          expandIcon={<KeyboardArrowRightIcon />}
                          aria-controls="panel2-content"
                          id="panel2-header"
                          sx={{ borderRadius: "8px" }}
                        >
                          <Stack
                            flexGrow={1}
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                          >
                            <Stack direction="row">
                              <Typography fontSize="14px" fontWeight={400}>
                                {metric.name}
                              </Typography>
                            </Stack>
                            <Chip
                                style={{
                                  height: "1rem",
                                  fontSize: "10px",
                                  color: metric.status ? "#0fc7c7" : "#ff5473",
                                  border: metric.status
                                    ? "1px solid #0fc7c7"
                                    : "1px solid #ff5473",
                                }}
                                label={metric.status ? "Passed" : "Failed"}
                                variant="outlined"
                                color={metric.status ? "success" : "error"}
                              />
                          </Stack>
                        </CustomAccordianSummary>
                        <AccordionDetails
                          style={{
                            backgroundColor: "#E7F1F6",
                            margin: "0.5rem",
                            borderRadius: "0.5rem",
                          }}
                        >
                          {metric.reason && (
                            <Typography
                              fontSize="12px"
                              fontWeight={400}
                              color={"#484A56"}
                            >
                              {metric.reason.substr(0, 100)}
                            </Typography>
                          )}
                        </AccordionDetails>
                      </Accordion>
                    );
                  })}
                
                {data.custom_metrics &&
                  data.custom_metrics.length > 0 &&
                  data?.custom_metrics.map((metric, index) => {
                    return (
                      <Accordion
                        sx={{ borderRadius: "8px" }}
                        // onClick={() => handleHighlight(metric.range)}
                        key={index}
                      >
                        <CustomAccordianSummary
                          expandIcon={<KeyboardArrowRightIcon />}
                          aria-controls="panel2-content"
                          id="panel2-header"
                          sx={{ borderRadius: "8px" }}
                        >
                          <Stack
                            flexGrow={1}
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                          >
                            <Stack direction="row">
                              <Typography fontSize="14px" fontWeight={400}>
                                {metric.name}
                              </Typography>
                            </Stack>
                            <Chip
                                style={{
                                  height: "1rem",
                                  fontSize: "10px",
                                  color: metric.status ? "#0fc7c7" : "#ff5473",
                                  border: metric.status
                                    ? "1px solid #0fc7c7"
                                    : "1px solid #ff5473",
                                }}
                                label={metric.status ? "Passed" : "Failed"}
                                variant="outlined"
                                color={metric.status ? "success" : "error"}
                              />
                          </Stack>
                        </CustomAccordianSummary>
                        <AccordionDetails
                          style={{
                            backgroundColor: "#E7F1F6",
                            margin: "0.5rem",
                            borderRadius: "0.5rem",
                          }}
                        >
                          {metric.reason && (
                            <Typography
                              fontSize="12px"
                              fontWeight={400}
                              color={"#484A56"}
                            >
                              {metric.reason.substr(0, 100)}
                            </Typography>
                          )}
                        </AccordionDetails>
                      </Accordion>
                    );
                  })}

                {data.static_metrics &&
                  data.static_metrics.length > 0 &&
                  data?.static_metrics.map((metric, index) => {
                    return (
                      <Accordion
                        sx={{ borderRadius: "8px" }}
                        // onClick={() => handleHighlight(metric.range)}
                        key={index}
                      >
                        <CustomAccordianSummary
                          expandIcon={<KeyboardArrowRightIcon />}
                          aria-controls="panel2-content"
                          id="panel2-header"
                          sx={{ borderRadius: "8px" }}
                        >
                          <Stack
                            flexGrow={1}
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                          >
                            <Stack direction="row">
                              <Typography fontSize="14px" fontWeight={400}>
                                {metric.name}
                              </Typography>
                            </Stack>
                            <Chip
                                style={{
                                  height: "1rem",
                                  fontSize: "10px",
                                  color: metric.status ? "#0fc7c7" : "#ff5473",
                                  border: metric.status
                                    ? "1px solid #0fc7c7"
                                    : "1px solid #ff5473",
                                }}
                                label={metric.status ? "Passed" : "Failed"}
                                variant="outlined"
                                color={metric.status ? "success" : "error"}
                              />
                          </Stack>
                        </CustomAccordianSummary>
                        <AccordionDetails
                          style={{
                            backgroundColor: "#E7F1F6",
                            margin: "0.5rem",
                            borderRadius: "0.5rem",
                          }}
                        >
                          {metric.reason && (
                            <Typography
                              fontSize="12px"
                              fontWeight={400}
                              color={"#484A56"}
                            >
                              {metric.reason.substr(0, 100)}
                            </Typography>
                          )}
                        </AccordionDetails>
                      </Accordion>
                    );
                  })}
              </Stack>
            </Paper>
          </Stack>
        </Stack>
      </Stack>
    </div>
  );
};

export default SumEvaluationDetails;
