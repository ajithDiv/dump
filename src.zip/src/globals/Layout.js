import React, { useContext } from "react";
import Topbar from "./Topbar";
import styles from "./Layout.module.css";
import SideBar from "./SideBar";
import { Outlet } from "react-router-dom";
import bg from "../assets/img/background.png";
import { AuthContext } from "./AuthContext";

const Layout = ({ children, ...props }) => {
  const ctx = useContext(AuthContext);
  ctx.updateUser("testUser");
  // ctx.updateSelectedProject("GENAI");
  return (
    <div className={styles.content}>
      <div className={styles.sidebarContainer}>
        <SideBar />
      </div>
      <div style={{backgroundImage: `url(${bg})`, backgroundRepeat: "repeat" }} className={styles.rightContainer}>
          <Topbar />
          <Outlet/>
      </div>
    </div>
  );
};

export default Layout;
