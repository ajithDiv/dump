// ScoreDistribution.js

import React from 'react';
import AreaChartIcon from "../../../../assets/genaiIcons/area_chart.png"

import {

    LineChart,

    Line,

    XAxis,

    YAxis,

    Tooltip,

    CartesianGrid,

    ResponsiveContainer,

} from 'recharts';

const data = [

    { score: "Fluency", value: 0.9 },

    { score: "Completeness", value: 0.7 },

    { score: "Exact Match Check", value: 0.7 },

    { score: "Factual Accuracy", value: 0.7 },

    { score: "Non Informativeness", value: 0.7 },

    { score: "QA Score", value: 0.6 },

    { score: "Bert Similarity", value: 0.7},

    { score: "Contradiction Check", value: 0.6 },

    { score: "Insensitiivty", value: 0.3 },

    { score: "Stereotype", value: 0.3 },

    { score: "Unethical", value: 0.3 },

    { score: "Profanity", value: 0.2 },

    { score: "PII Detection", value: 0 },

];

const ScoreDistribution = () => {

    return (
        <div style={{ background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 1px 4px rgba(0,0,0,0.1)', marginTop: '20px', border: '1px solid #C1C1C1' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 10px 0', display: 'flex', alignItems: 'center', color: '#666687' }}>
                <img src={AreaChartIcon} />&nbsp; Score Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="score" />
                    <YAxis allowDecimals={true} domain={[0, 1]} />
                    <Tooltip />
                    <Line

                        type="monotone"

                        dataKey="value"

                        stroke="#8884d8"

                        strokeWidth={2}

                        fill="#8884d8"
                        fillOpacity={0.2}
                    // dot={{ r: 4 }}

                    // activeDot={{ r: 6 }}

                    />
                </LineChart>
            </ResponsiveContainer>
        </div>

    );

};

export default ScoreDistribution;
