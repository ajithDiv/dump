import React from 'react';
import './AugmentationInsights.css';
import AugmentationInsightsIcon from "../../../../assets/genaiIcons/emoji_objects.png"


const augmentationData = [
    { title: 'Broken English', records: 8, pass: '50%' },
    { title: 'Paraphrasing', records: 6, pass: '90%' },
    { title: 'Induce Toxicty', records: 5, pass: '30%' },
    { title: 'Multiligual', records: 8, pass: '60%' },
    { title: 'Induce Stereotype', records: 2, pass: '100%' },
    { title: 'String repeat', records: 4, pass: '75%' },
    { title: 'Short Duration call', records: 11, pass: '60%' },
    { title: 'Long duration call', records: 2, pass: '50%' },
    { title: 'Brevity', records: 4, pass: '50%' },
    { title: 'Verbosity', records: 9, pass: '80%' },
];
const AugmentationInsights = () => {
    return (
        <div className="augmentation-container">
            <div className="augmentation-title">
                <span className="augmentation-icon"><img src={AugmentationInsightsIcon}/></span> Augmentation Insights
            </div>
            <div className="augmentation-grid">
                {augmentationData.map((item, index) => (
                    <div key={index} className="augmentation-card">
                        <div className="card-content">
                            <div className="card-title">{item.title}</div>
                            <div className="card-subtitle">
                                {item.records} Records ({item.pass} Pass)
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
export default AugmentationInsights;