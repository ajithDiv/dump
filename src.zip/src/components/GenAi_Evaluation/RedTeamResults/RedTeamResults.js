import {
    CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { getDocumentsByExecutionCategory } from "../../../_services/genai_evaluation.service";
import { useParams } from "react-router-dom";


const RedTeamResults = () => {
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
    const [rowPage, setRowPage] = useState(5);
    const [data, setData] = useState([]);

  const params = useParams();

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
    };
    
    useEffect(() => {
        getDocumentsByExecutionCategory("red_team_component", params.id).then(result => {
            setLoading(false);
          let arr = [];
          result.map(item => {
              arr.push({
                useCase: item.TestCase,
                attackStrategy: item.Attack_Strategy,
                attackerInput: item.prompt,
                applicationOutput: item.response,
                status: item.status
                })
             
            })
            setData(arr);
        })
    }, [])

  return (
    <div>
      <TableContainer component={Paper}>
        <Table aria-label="Material-UI Table">
          <TableHead sx={{ background: "#111270", color: "#fff" }}>
            <TableRow sx={{ alignItems: "center", color: "#fff" }}>
              <TableCell
                sx={{
                  width: "2.5rem",
                  color: "#fff",
                  textAlign: "left",
                }}
              >
                S No.
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                Test Case
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                Attack Strategy
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                Attacker Input
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                Application Response
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                Status
              </TableCell>
            </TableRow>
          </TableHead>
          {loading === true ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    <CircularProgress />
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : data.length === 0 ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    No Data Availble
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : (
            <TableBody>
              {data
                .slice(
                  page * rowPage,
                  page * rowPage + rowPage
                )
                .map((row, index) => {
                  const uniqueRowNumber =
                    page * rowPage + index + 1;
                  return (
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#F6F6F6" }
                          : { background: "white" }
                      }
                    >
                      <TableCell>{uniqueRowNumber}</TableCell>
                      {/* <TableCell>{row.description}</TableCell> */}
                      <TableCell>
                        {row.useCase} {/*<Link to={row.id}>{row.name}</Link>*/}
                      </TableCell>
                      <TableCell>{row.attackStrategy}</TableCell>
                      <TableCell>{row.attackerInput}</TableCell>
                      <TableCell>{row.applicationOutput}</TableCell>
                      <TableCell>{row.status}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          )}
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={data.length}
        rowsPerPage={rowPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};

export default RedTeamResults;
