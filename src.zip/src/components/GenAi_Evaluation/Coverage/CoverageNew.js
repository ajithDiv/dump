import React, { useMemo, useState } from "react";

import "./CoverageNew.css";

// Mock multiple records

const mockRecords = new Array(12).fill(null).map((_, i) => ({

    id: i + 1,

    topic: "Changes & Cancellations",

    biasStatus: "Balanced",

    insights:

        "Lorem ipsum dolor sit amet consectetur adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. Nemo enim ipsam voluptatemLorem ipsum dolor sit amet consectetur adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. Nemo enim ipsam voluptatem.Lorem ipsum dolor sit amet consectetur adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. Nemo enim ipsam voluptatem",

    moreInsights:

        "Ut enim ad minima veniam quis nostrum exercitationem ullam corporis suscipit laboriosam nisi ut aliquid ex ea commodi consequatur. Quis autem vel eum iure reprehenderit.",

    recommended:

        "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit. Sed quia non numquam eius modi tempora incidunt ut labore et dolore.",

    subtopics: [

        { label: "Rebooking", score: "100%" },

        { label: "Cancellation Fees", score: "0%" },

        { label: "Delay Compensation", score: "0%" }

    ]

}));

const truncateWithCount = (text, wordLimit = 25) => {

    const words = text.trim().split(/\s+/);

    if (words.length <= wordLimit) return { visible: text, remaining: 0 };

    return {

        visible: words.slice(0, wordLimit).join(" "),

        remaining: words.length - wordLimit

    };

};
const transformApiData = (coverageDetails) => {
    if (!Array.isArray(coverageDetails)) return [];
    return coverageDetails.map((raw) => ({
        topic: raw.Topic,
        biasStatus: raw.Bias_Status,
        insights: raw["Insights(with Real-World Context)"],
        moreInsights: raw["More Insights"] || "",
        recommended: 
        Array.isArray(raw.Recommend_Augmentation)
          ? raw.Recommend_Augmentation.join(", ")
          : String(raw.Recommend_Augmentation || ""),
        
        percentage: `${raw.percentage || 0}%`,
        subtopics: Object.entries(raw.subtopics || {}).map(([label, score]) => ({
            label,
            score: `${score}%`
        }))
    })
    )
};
export default function CoverageNew(props) {

    const rowsPerPage = 5;

    const [page, setPage] = useState(1);

    const [isModalOpen, setIsModalOpen] = useState(false);

    const [expandedSection, setExpandedSection] = useState("insights");

    const [activeRecord, setActiveRecord] = useState(null);

    const transformedRecords = useMemo(() => transformApiData(props.coverageDetails), [props.coverageDetails]);
    const paginatedData = transformedRecords.slice(

        (page - 1) * rowsPerPage,

        page * rowsPerPage

    );

    const handleOpenModal = (record, section) => {

        setActiveRecord(record);

        setExpandedSection(section);

        setIsModalOpen(true);

    };

    return (
        <>
            <div className="contianer-wrapper">
                <div className="table-header">
                    <div>Topic</div>
                    <div>Bias Status</div>
                    <div>Insights (with real-world context)</div>
                    <div>More Insights</div>
                    <div>Recommended Augmentation</div>
                </div>
                {paginatedData.map((record) => {

                    const insights = truncateWithCount(record.insights);

                    const more = truncateWithCount(record.moreInsights);

                    const rec = truncateWithCount(record.recommended);

                    return (
                        <div className="table-row" key={record.id}>
                            <div className="top-row">
                                <div className="cell topic">
                                    <div className="topic-title">{record.topic}</div>
                                </div>
                                <div className="cell bias">
                                    <span className="bias-status">{record.biasStatus}</span>
                                </div>
                                <div className="cell insights">
                                    <p>

                                        {insights.visible}

                                        {insights.remaining > 0 && (
                                            <span

                                                className="more-text"

                                                onClick={() => handleOpenModal(record, "insights")}
                                            >

                                                +{insights.remaining}
                                            </span>

                                        )}
                                    </p>
                                </div>
                                <div className="cell more-insights">
                                    <p>

                                        {more.visible}

                                        {more.remaining > 0 && (
                                            <span

                                                className="more-text"

                                                onClick={() => handleOpenModal(record, "moreInsights")}
                                            >

                                                +{more.remaining}
                                            </span>

                                        )}
                                    </p>
                                </div>
                                <div className="cell recommendation">
                                    <p>

                                        {rec.visible}

                                        {rec.remaining > 0 && (
                                            <span

                                                className="more-text"

                                                onClick={() =>

                                                    handleOpenModal(record, "recommended")

                                                }
                                            >

                                                +{rec.remaining}
                                            </span>

                                        )}
                                    </p>
                                </div>
                            </div>
                            <div className="bottom-row">
                                <div className="subtopic">
                                    <div className="subtopic-label">Subtopic:</div>
                                    <div className="subtopics">
                                        {record.subtopics.map((sub, idx) => (
                                            <div style={{display:"flex",alignItems:"center"}}>
                                                <span key={idx} >
                                                    {sub.label}
                                                </span>
                                                <span className="pill subtopic-pill">{sub.score}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                {/* <span className="separator">•</span> */}
                                <div style={{ background: "#fff", height: "100%", display: "flex", alignItems: "center" }}>
                                    <span className="pill percentage-pill">
                                        Percentage <b>100%</b>
                                    </span>
                                </div>

                            </div>
                        </div>

                    );

                })}

                {/* Pagination */}
                <div className="pagination">
                    <span>

                        Rows per page: {rowsPerPage}
                    </span>
                    <span>

                        {(page - 1) * rowsPerPage + 1}-{Math.min(page * rowsPerPage, transformedRecords.length)} of {transformedRecords.length}
                    </span>
                    <button onClick={() => setPage((p) => Math.max(p - 1, 1))}>‹</button>
                    <button

                        onClick={() =>

                            setPage((p) => (p * rowsPerPage < transformedRecords.length ? p + 1 : p))

                        }
                    >

                        ›
                    </button>
                </div>

                {/* Modal */}

                {isModalOpen && activeRecord && (
                    <div className="modal-overlay">
                        <div className="modal">
                            <h3>{activeRecord.topic}</h3>
                            <div className="accordion">
                                <div

                                    className="accordion-header"

                                    onClick={() => setExpandedSection("insights")}
                                >

                                    ▸ Insights (with real-world context)
                                </div>

                                {expandedSection === "insights" && (
                                    <div className="accordion-body">
                                        <p>{activeRecord.insights}</p>
                                    </div>

                                )}
                                <div

                                    className="accordion-header"

                                    onClick={() => setExpandedSection("moreInsights")}
                                >

                                    ▸ More Insights
                                </div>

                                {expandedSection === "moreInsights" && (
                                    <div className="accordion-body">
                                        <p>{activeRecord.moreInsights}</p>
                                    </div>

                                )}
                                <div

                                    className="accordion-header"

                                    onClick={() => setExpandedSection("recommended")}
                                >

                                    ▸ Recommended Augmentation
                                </div>

                                {expandedSection === "recommended" && (
                                    <div className="accordion-body">
                                        <p>{activeRecord.recommended}</p>
                                    </div>

                                )}
                            </div>
                            <button className="modal-close" onClick={() => setIsModalOpen(false)}>Close</button>
                        </div>
                    </div>

                )}
            </div>
        </>

    );

}
