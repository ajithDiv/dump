import {
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getCoveData } from "../../../_services/genai_evaluation.service";

const CoveResults = ({ initialData }) => {
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [data, setData] = useState(initialData.details);
  const parameters = useParams();

  const id = parameters.id;
  const subId = parameters.subId;

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // useEffect(() => {
  //   getCoveData(id, subId).then((result) => {
  //       setData(result.consistent_custom_object);
  //       setLoading(false);
  //   });
  // }, []);

  return (
    <div>
      <TableContainer component={Paper}>
        <Table aria-label="Material-UI Table">
          <TableHead sx={{ background: "#111270", color: "#fff" }}>
            <TableRow sx={{ alignItems: "center", color: "#fff" }}>
              <TableCell
                sx={{
                  width: "2.5rem",
                  color: "#fff",
                  textAlign: "left",
                }}
              >
                <strong>S No.</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>CoVE Questons</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>CoVE Answers</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Generated Answer Consistency</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Explanation</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Answer Similarity</strong>
              </TableCell>
            </TableRow>
          </TableHead>
          {loading === true ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    <CircularProgress />
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : data.length === 0 ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    No Data Availble
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : (
            <TableBody>
              {data
                .slice(page * rowPage, page * rowPage + rowPage)
                .map((row, index) => {
                  const uniqueRowNumber = page * rowPage + index + 1;
                  return (
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#F6F6F6" }
                          : { background: "white" }
                      }
                    >
                      <TableCell>{uniqueRowNumber}</TableCell>
                      <TableCell>{row.question}</TableCell>
                      <TableCell>{row.answer}</TableCell>
                      <TableCell>{row.status}</TableCell>
                      <TableCell>{row.explanation}</TableCell>
                      <TableCell>{row.score}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          )}
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={data.length}
        rowsPerPage={rowPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};

export default CoveResults;
