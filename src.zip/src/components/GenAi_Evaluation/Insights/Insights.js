import React, { useContext, useEffect, useState } from "react";
import SentimentBar from "./SentimentBar";
import {
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import { AuthContext } from "../../../globals/AuthContext";
import { getInsights } from "../../../_services/genai_evaluation.service";
import { useParams } from "react-router-dom";

const dropdownOptions = [
  "Wealth Management Coach",
  "Sr Design Ops Specialist",
  "Senior Specialist",
  "Senior Analyst - Data Visualization - IN",
  "Associate - Data Analytics",
];

const segments1 = [
  {
    color: "#4546d9",
    percentage: 100,
    label:
      "The question provided does not fully address the computency, resulting in a lower relevancy score.",
    id: 1,
  },
];

const heading1 = "Relevance check (Competency & Question)";
const totalPercentage1 = "4%";

const segments2 = [
  {
    color: "#4546d9",
    percentage: 66,
    label:
      "Missing Context - The provided context is empty or not provided, making it impossible to evaluate relevance.",
    id: 1,
  },
  {
    color: "grey",
    percentage: 34,
    label:
      "Unrelated Context - The provided context does not contain relevant information to the question about financial planning software.",
    id: 2,
  },
];

const heading2 = "Relevance check (JD Context & Question)";
const totalPercentage2 = "39%";

const segments3 = [
  {
    color: "#4546d9",
    percentage: 100,
    label:
      "The question provided does not fully address the computency, resulting in a lower relevancy score.",
    id: 1,
  },
];

const heading3 = "Relevance check (JD Competency & Question)";
const totalPercentage3 = "10%";

const segments4 = [
  {
    color: "#4546d9",
    percentage: 67,
    label:
      "Lack of Specific Evidence - The context hints at the importance of initiative, but lacks direct examples to support the question about taking on additional responsibilities.",
    id: 1,
  },
  {
    color: "grey",
    percentage: 33,
    label:
      "Partially Relevant Context - The context aligns with the essence of the question regarding attention to detail in financial planning but lacks specific mention of identifying and addressing errors or oversights.",
    id: 2,
  },
];

const heading4 = "Factuality Score";
const totalPercentage4 = "47%";

const tableColumnNames = {
  actionable_insights: "Actionable Insights",
  augmentation_type: "Augmentation Type",
  example_scenarios: "Example Scenarios",
  failure_reason: "Failure Reason",
  potential_gaps: "Potential Gaps",
  priority: "Priority",
};

const Insights = () => {
  const [selectedOption, setSelectedOption] = useState(dropdownOptions[0]);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [sumResponse, setSumResponse] = useState({});

  const ctx = useContext(AuthContext);
  const params = useParams();

  const handleDropdownChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  useEffect(() => {
    getInsights(params.id).then((result) => {
      setSumResponse(result[0]);
    });
  }, []);

  if (ctx.projectSubType === "SUM" || ctx.projectSubType === "CODEGEN") {
    return (
      <> <div className="card-grid">
        {sumResponse?.metrics?.metrics &&
          sumResponse?.metrics?.metrics.length > 0 &&
          sumResponse?.metrics?.metrics.map((item, index) => {
            return (
              // <div key={index}>
              //   <Paper style={{ padding: "1rem" }} elevation={3}>
              //     <SentimentBar
              //       segments={item.segments}
              //       heading={item.heading}
              //       totalPercentage={item.totalPercentage}
              //     />
              //   </Paper>
              //   <br />
              // </div>
             
                <div className="card">
                  <h3 className="card-title">{item.heading}</h3>
                  <p className="card-percentage">{Math.trunc(item.totalPercentage)}%<span style={{fontSize:"14px"}}>&nbsp;Failed</span></p>
                  <ul className="card-list">
                    {item.segments.map((item, index) => (
                      <li key={index} className="card-item">
                        <span>{item.label}</span>
                        <span>{item.percentage}%<span style={{fontWeight:"bold",color:"red"}}>&nbsp;F&nbsp;</span></span>
                      </li>
                    ))}
                  </ul>
                </div>
              
            );
          })}
          </div>
        <Paper style={{ padding: "1rem" }} elevation={3}>
          <TableContainer sx={{ marginTop: "30px" }} component={Paper}>
            <Table aria-label="Material-UI Table">
              <TableHead sx={{ background: "#111270", color: "#fff" }}>
                <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                  {sumResponse?.insights?.insights &&
                    sumResponse?.insights?.insights.length > 0 &&
                    Object.keys(sumResponse?.insights?.insights[0]).map(
                      (row, index) => {
                        return (
                          <TableCell
                            sx={{
                              width: "2.5rem",
                              color: "#fff",
                              textAlign: "center",
                            }}
                            key={index}
                          >
                            <strong>{tableColumnNames[row]}</strong>
                          </TableCell>
                        );
                      }
                    )}
                </TableRow>
              </TableHead>

              <TableBody>
                {sumResponse?.insights?.insights &&
                  sumResponse?.insights?.insights.length > 0 &&
                  sumResponse?.insights?.insights
                    .slice(page * rowPage, page * rowPage + rowPage)
                    .map((row, index) => {
                      return (
                        <TableRow
                          key={index}
                          style={
                            index % 2
                              ? { background: "#F6F6F6" }
                              : { background: "white" }
                          }
                        >
                          {sumResponse?.insights?.insights &&
                            sumResponse?.insights?.insights.length > 0 &&
                            Object.keys(sumResponse?.insights?.insights[0]).map(
                              (cell, index) => {
                                return (
                                  <TableCell
                                    sx={{
                                      width: "2.5rem",
                                      color: "black",
                                      textAlign: "left",
                                    }}
                                    key={index}
                                  >
                                    {row[cell]}
                                  </TableCell>
                                );
                              }
                            )}
                        </TableRow>
                      );
                    })}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={sumResponse?.insights?.insights.length}
            rowsPerPage={rowPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </>
    );
  }

  return (
    <>
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <FormControl
          variant="outlined"
          style={{
            marginLeft: "2rem",
            top: "10px",
            right: "10px",
            width: "350px",
          }}
        >
          <InputLabel id="job-select-label">Select</InputLabel>
          <Select
            labelId="job-select-label"
            id="job-select"
            value={selectedOption}
            onChange={handleDropdownChange}
            label="Select"
            placeholder="Select"
          >
            {dropdownOptions.map((option, index) => (
              <MenuItem key={index} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <br />
        <br />
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <SentimentBar
          segments={segments1}
          heading={heading1}
          totalPercentage={totalPercentage1}
        />
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <SentimentBar
          segments={segments2}
          heading={heading2}
          totalPercentage={totalPercentage2}
        />
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <SentimentBar
          segments={segments3}
          heading={heading3}
          totalPercentage={totalPercentage3}
        />
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <SentimentBar
          segments={segments4}
          heading={heading4}
          totalPercentage={totalPercentage4}
        />
      </Paper>
    </>
  );
};

export default Insights;
