import React, { useContext, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import Select from "react-select";
import { Stack } from "@mui/material";
import { AuthContext } from "../../../globals/AuthContext";


const colors = ["#4c51bf", "#14b8a6", "#f43f5e"];

const customStyles = {
  control: (provided) => ({
    ...provided,
    width: "100%",
  }),
};

const options = [
  { value: "Wealth Management Coach", label: "Wealth Management Coach" },
  { value: "Sr Design Ops Specialist", label: "Sr Design Ops Specialist" },
  { value: "Senior Specialist", label: "Senior Specialist" },
  { value: "Senior Analyst - Data Visualization - IN", label: "Senior Analyst - Data Visualization - IN" },
  {value: "Associate - Data Analytics", label: "Associate - Data Analytics"},
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{opacity: 0.8, backgroundColor: "white", padding: " 0 0.5rem", borderRadius: "0.5rem"}}>
        <p className="label">{`${payload[0].payload.metric}`}</p>
        {payload.map(item => <p className="label">{item.name} : {item.value}</p> )}
      </div>
    );
  }
  return null;
};

const BarChartComponent = (props) => {
  const ctx = useContext(AuthContext);

  const data = props.data.map(item => ({...item, tag: item.metric.substring(0,3)+"..."}))

  // const data = ctx.projectName.includes("JD") ? [
  //   {
  //     metric: "Grammar_score",
  //     //"Total Executed": 105, // Calculated as Total Passed + Total Failed
  //     "Total Passed": 105,
  //     "Total Failed": 0,
  //     tag: "Gra..."
  //   },
  //   {
  //     metric: "Spelling_score",
  //     //"Total Executed": 105,
  //     "Total Passed": 105,
  //     "Total Failed": 0,
  //     tag: "Spe..."
  //   },
  //   {
  //     metric: "Relevance check ", //(Competency & Question)
  //     //"Total Executed": 105,
  //     "Total Passed": 92,
  //     "Total Failed": 13,
  //     tag: "Rel..."
  //   },
  //   {
  //     metric: "Relevance check (JD Context & Question)",
  //     //"Total Executed": 105,
  //     "Total Passed": 89,
  //     "Total Failed": 16,
  //     tag: "Rel..."
  //   },
  //   {
  //     metric: "Relevance check (JD Competency & Question)",
  //     //"Total Executed": 105,
  //     "Total Passed": 76,
  //     "Total Failed": 29,
  //     tag: "Rel..."
  //   },
  //   {
  //     metric: "Coherence_score",
  //     //"Total Executed": 105,
  //     "Total Passed": 100,
  //     "Total Failed": 5,
  //     tag: "Coh..."
  //   },
  //   {
  //     metric: "Factuality_score",
  //     //"Total Executed": 105,
  //     "Total Passed": 69,
  //     "Total Failed": 36,
  //     tag: "Fac..."
  //   },
  //   {
  //     metric: "Fluency_score",
  //     //"Total Executed": 105,
  //     "Total Passed": 104,
  //     "Total Failed": 1,
  //     tag: "Flu..."
  //   }
  // ] : [
  //   {
  //     metric: "qa_relevance",
  //     //"Total Executed": 40, // Calculated as Total Passed + Total Failed
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "qa_..."
  //   },
  //   {
  //     metric: "qs_relevance",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "qs_..."
  //   },
  //   {
  //     metric: "coherence",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "coh..."
  //   },
  //   {
  //     metric: "summarization",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "sum..."
  //   },
  //   {
  //     metric: "concisenses",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "con..."
  //   },
  //   {
  //     metric: "controversiality",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "con..."
  //   },
  //   {
  //     metric: "correctness",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "cor..."
  //   },
  //   {
  //     metric: "groundedness",
  //     //"Total Executed": 40,
  //     "Total Passed": 39,
  //     "Total Failed": 1,
  //     tag: "gro..."
  //   },
  //   {
  //     metric: "sentiment",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "sen..."
  //   },
  //   {
  //     metric: "insensitivity",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "ins..."
  //   },
  //   {
  //     metric: "stereotype",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "ste..."
  //   },
  //   {
  //     metric: "maliciousness",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "mal..."
  //   },
  //   {
  //     metric: "fluency",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "flu..."
  //   },
  //   {
  //     metric: "helpfulness",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "hel..."
  //   },
  //   {
  //     metric: "pii_detction",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "pii..."
  //   },
  //   {
  //     metric: "criminality",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "cri..."
  //   },
  //   {
  //     metric: "misogyny",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "mis..."
  //   },
  //   {
  //     metric: "harmfullness",
  //     //"Total Executed": 40,
  //     "Total Passed": 0,
  //     "Total Failed": 40,
  //     tag: "har..."
  //   },
  //   {
  //     metric: "factuality",
  //     //"Total Executed": 40,
  //     "Total Passed": 40,
  //     "Total Failed": 0,
  //     tag: "fac..."
  //   }
  // ];
  

  // const metricOptions = ctx.projectName.includes("JD") ? [
  //   // { value: "All Metrices", label: "All Metrices"},
  //   { value: "Coherence_score", label: "Coherence_score" },
  //   { value: "Factuality_score", label: "Factuality_score" },
  //   { value: "Fluency_score", label: "Fluency_score" },
  //   { value: "Spelling_score", label: "Spelling_score" },
  //   { value: "Grammar_score", label: "Grammar_score" },
  //   { value: "Relevance check (Competency & Question)", label: "Relevance check (Competency & Question)" },
  //   { value: "Relevance check (JD Context & Question)", label: "Relevance check (JD Context & Question)" },
  //   { value: "Relevance check (JD Competency & Question)", label: "Relevance check (JD Competency & Question)" }
  // ] : [
  //   { value: "qa_relevance", label: "qa_relevance" },
  //   { value: "qs_relevance", label: "qs_relevance" },
  //   { value: "coherence", label: "coherence" },
  //   { value: "summarization", label: "summarization" },
  //   { value: "concisenses", label: "concisenses" },
  //   { value: "controversiality", label: "controversiality" },
  //   { value: "correctness", label: "correctness" },
  //   { value: "groundedness", label: "groundedness" },
  //   { value: "sentiment", label: "sentiment" },
  //   { value: "insensitivity", label: "insensitivity" },
  //   { value: "stereotype", label: "stereotype" },
  //   { value: "maliciousness", label: "maliciousness" },
  //   { value: "fluency", label: "fluency" },
  //   { value: "helpfulness", label: "helpfulness" },
  //   { value: "pii_detction", label: "pii_detction" },
  //   { value: "criminality", label: "criminality" },
  //   { value: "misogyny", label: "misogyny" },
  //   { value: "harmfullness", label: "harmfullness" },
  //   { value: "factuality", label: "factuality" }
  // ];

  const [selectedOptions, setSelectedOptions] = useState([options[0]]);
  const [selectedMetrics, setSelectedMetrics] = useState([]);

  const handleChange = (selected) => {
    setSelectedOptions(selected);
  };

  const handleChangeMetrics = (selected) => {
    setSelectedMetrics(selected);
  }
  
  return (
    <>
      <Stack direction={"row"} justifyContent="flex-end" gap={1}>
      {ctx.projectName==="JD_QUESTIONNAIRE" && <Select
          value={selectedOptions}
          // onChange={handleChange}
          options={options}
          onChange={handleChange}
          styles={customStyles}
          placeholder="Select JD"
        />}
        <Select
          
          value={selectedMetrics}
          // onChange={handleChange}
          options={props.metricOptions}
          onChange={handleChangeMetrics}
          styles={customStyles}
          placeholder="Select Metrics"
          isMulti
        />
        </Stack>
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
          data={data.filter(item => {
            let flag = false;
            selectedMetrics.map(met => {
              if (met.value === item.metric) {
                flag = true;
              }
            })
            return flag;
        })}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="tag" />
        <YAxis />
        <Tooltip content={<CustomTooltip/>} />
        <Legend />
        {/* <Bar dataKey="Total Executed" fill={colors[0]} /> */}
        <Bar dataKey="Total Passed" fill={colors[1]} />
        <Bar dataKey="Total Failed" fill={colors[2]} />
      </BarChart>
      </ResponsiveContainer>
      </>
  );
};

export default BarChartComponent;
