import datasetIcon from "../assets/genaiIcons/psychology.png";
import telemetryIcon from "../assets/genaiIcons/config icon.png";
import notificationIcon from "../assets/genaiIcons/notifications.png";
import settingsIcong from "../assets/genaiIcons/settings_applications.png";
import activityIcon from "../assets/genaiIcons/sprint.png";
import evaluateIcon from "../assets/genaiIcons/evaluate.png";
import dashboardIcon from "../assets/genaiIcons/dashboard.png";
import ModelTrainingOutlinedIcon from '@mui/icons-material/ModelTrainingOutlined';
import { Typography } from "@mui/material";

export const SideBarData = [
  {
    title: "Dataset",
    path: "/genai-assurance/genai_dataset",
    icon: <img alt="Dataset Icon" src={datasetIcon} />,
  },
  {
    title: <Typography>Model<sup>+</sup></Typography>,
    path: "/genai-assurance/genai_model",
    icon: <ModelTrainingOutlinedIcon fontSize="small"/>,
  },
  {
    title: "Evaluation",
    path: "/genai-assurance/genai_evaluate",
    icon: <img alt="Evaluate Icon" src={evaluateIcon} />,
  },
  // {
  //   title: "Telemetry",
  //   path: "/genai-assurance/genai_telemetry",
  //   icon: <img alt="Telemetry Icon" src={telemetryIcon} />,
  // },
  // {
  //   title: "Notifications",
  //   path: "/genai-assurance/genai_notifications",
  //   icon: <img alt="Notification Icon" src={notificationIcon} />,
  // },
  // {
  //   title: "Active Feed",
  //   path: "/genai-assurance/genai_active_feed",
  //   icon: <img alt="Active Feed Icon" src={activityIcon} />,
  // },
  // {
  //   title: "Settings",
  //   path: "/genai-assurance/genai_settings",
  //   icon: <img alt="Settings Icon" src={settingsIcong} />,
  // },
];
