import { handleResponse } from "../_helpers";
import axios from "axios";
import { json } from "react-router-dom";

export function createDataset(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/data-gen/create_dataset`,
    requestOptions
  ).then(handleResponse);
}

export function getAllDatasets(projectName) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/get_dataset_details/` +
    projectName,
    requestOptions
  ).then(handleResponse);
}

export function deleteDataset(datasetId) {
  const requestOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/delete_dataset/` +
    datasetId,
    requestOptions
  ).then(handleResponse);
}

export async function downloadTemplate() {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_BASE_API_URL}/controller/download_excel_template`,
      {
        responseType: "blob",
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }

  // const requestOptions = {
  //     method: 'GET',
  //     // credentials: 'include',
  //     mode: 'cors',
  //     cache: 'default',
  //     headers: {
  //         'Content-Type': 'application/json',
  //         // 'Authorization': authHeader()
  //     },
  //     responseType: 'blob'

  // };
  // return fetch(`${process.env.REACT_APP_BASE_API_URL}/controller/download_excel_template`, requestOptions).then(
  //     response => { return response.data(); }
  // );
}

export const uploadDocuments = async (files, datasetId, parser) => {
  try {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append("file", file);
    });
    formData.append("datasetId", datasetId);
    formData.append("parserType", parser)

    const response = await axios.post(
      `${process.env.REACT_APP_BASE_API_URL}/data-gen/load_data`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );

    return response.data;
  } catch (error) {
    throw error;
  }
};

export const uploadFile = async (file, datasetId, projectType) => {
  try {
    const formData = new FormData();

    formData.append("file", file);
    formData.append("datasetId", datasetId);
    formData.append("projectType", projectType)

    const response = await axios.post(
      `${process.env.REACT_APP_BASE_API_URL}/controller/upload_excel`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );

    return response.data;
  } catch (error) {
    throw error;
  }

  // const formData = new FormData();
  // formData.append("file", file);
  // const requestOptions = {
  //     method: 'POST',
  //     // credentials: 'include',
  //     mode: 'cors',
  //     cache: 'default',
  //     headers: {
  //         'Content-Type': 'multipart/form-data',
  //         // 'Authorization': authHeader()
  //     },
  //     body: formData
  // };

  // return fetch(`${process.env.REACT_APP_BASE_API_URL}/data-gen/upload_excel`, requestOptions)
  //     .then(handleResponse);
};

export function generatePrompt(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/data-gen/create_data`,
    requestOptions
  ).then(handleResponse);
}

export function getPrompts(datasetId) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/fetch_ques/` + datasetId,
    requestOptions
  ).then(handleResponse);
}

export function getAugmentationTypes(category, projectSubType) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getAugmentationTypes/${category}/${projectSubType}`,
    requestOptions
  ).then(handleResponse);
}

export function getPromptResponses(datasetId) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/fetch_ques_responses/` +
    datasetId,
    requestOptions
  ).then(handleResponse);
}

export function VerifyPromptResponse(data) {
  const requestOptions = {
    method: "PUT",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/update_answer`,
    requestOptions
  ).then(handleResponse);
}

export function getInputs(datasetId, projectType) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getInputs/` + datasetId + '/' + projectType,
    requestOptions
  ).then(handleResponse);
}

export function generateAugmentations(data) {
  //console.log(data,"sdsdsa")
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/generateAugmentations`,
    requestOptions
  ).then(handleResponse);
}

export function addAugmentations(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/addAugmentations`,
    requestOptions
  ).then(handleResponse);
}

export function saveCustomMetricData(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/save_custom_metrices`,
    requestOptions
  ).then(handleResponse);
}


export function getAllProjects(projectName) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getProjectList`,
    requestOptions
  ).then(handleResponse);
}

export function getProjectById(id) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getProjects/` + id,
    requestOptions
  ).then(handleResponse);
}

export function getDatasetById(id) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getDataset/` + id,
    requestOptions
  ).then(handleResponse);
}


export function generateQuestions(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/generateQuestions`,
    requestOptions
  ).then(handleResponse);
}

export function deleteBulkPrompts(idList) {
  const requestOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify({ "idList": idList }),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/deleteBulkDatasetPrompts`,
    requestOptions
  ).then(handleResponse);
}

export function deleteDatasetPrompt(id) {
  const requestOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/deleteDatasetPrompt/` + id,
    requestOptions
  ).then(handleResponse);
}

export function generateGroundTruth(id) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/generateGroundTruth/` + id,
    requestOptions
  ).then(handleResponse);
}

export function getAugmentations(projectType) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/get_augmentation_details/` + projectType,
    requestOptions
  ).then(handleResponse);
}

export function createAugmentation(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data)
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/data-gen/generate-augmentation-prompt`,
    requestOptions
  ).then(handleResponse);
}
export function createNewGroup(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data)
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/add_augmentation_group`,
    requestOptions
  ).then(handleResponse);
}