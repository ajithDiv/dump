import { handleResponse } from "../_helpers";


export function getAllMetrices(projectType) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/metrics_config/projectType/` + projectType, requestOptions).then(handleResponse);
}

export function getDatasetList(projectName) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/controller/getDatasetNameByProjectName/` + projectName, requestOptions).then(handleResponse);
}

export function getModelDetails() {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/model_details`, requestOptions).then(handleResponse);
}

export function getAllEvaluations(projectName) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/getEvaluationByProjectName/` + projectName, requestOptions).then(handleResponse);
}

export function deleteEvaluation(evaluationId) {
    const requestOptions = {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/deleteEvaluation/` + evaluationId, requestOptions).then(handleResponse);
}

export function createConfiguration(data) {
    const requestOptions = {
        method: "POST",
        // credentials: 'include',
        mode: "cors",
        cache: "default",
        headers: {
            "Content-Type": "application/json",
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    return fetch(
        `${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/receive_metrics`,
        requestOptions
    ).then(handleResponse);
}


export function getEvaluationData(id) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/data-gen/getEvaluationData/` + id, requestOptions).then(handleResponse);
}

export function getCoverageDetails(id) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/data-gen/getCoverageDetails/` + id, requestOptions).then(handleResponse);
}

export function getEvaluationRecordData(id, projectType) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/data-gen/getEvaluationRecordData/` + id + '/' + projectType, requestOptions).then(handleResponse);
}

export function getAllConfigurations(projectName) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/getConfigurationByProjectName/` + projectName, requestOptions).then(handleResponse);
}

export function runEvaluation(data) {
    const requestOptions = {
        method: "POST",
        // credentials: 'include',
        mode: "cors",
        cache: "default",
        headers: {
            "Content-Type": "application/json",
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    return fetch(
        `${process.env.REACT_APP_BASE_API_URL}/data-gen/generate_actual_responses`,
        requestOptions
    ).then(handleResponse);
}

export function runEvaluation1(data) {
    const requestOptions = {
        method: "POST",
        // credentials: 'include',
        mode: "cors",
        cache: "default",
        headers: {
            "Content-Type": "application/json",
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    return fetch(
        `${process.env.REACT_APP_BASE_API_URL}/data-gen/app_response`,
        requestOptions
    ).then(handleResponse);
}

export function completeEvaluation(data) {
    const requestOptions = {
        method: "POST",
        // credentials: 'include',
        mode: "cors",
        cache: "default",
        headers: {
            "Content-Type": "application/json",
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    return fetch(
        `${process.env.REACT_APP_BASE_API_URL}/gen_ai_evaluation`,
        requestOptions
    ).then(handleResponse);
}


export function getDatasetNameById(id) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/getDatasetNamebyId/` + id, requestOptions).then(handleResponse);
}

export function getDocumentsByExecutionCategory(category, executionId) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/get_documents_by_execution_category/` + category + '/' + executionId, requestOptions).then(handleResponse);
}


export function deleteConfiguration(configId) {
    const requestOptions = {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/metrics_config/` + configId, requestOptions).then(handleResponse);
}

export function getEvaluationDashboardData(id) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/dashboard-metrics/get_evaluation_metrices/` + id, requestOptions).then(handleResponse);
}


export function getDashboardOverallData(projectName) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/dashboard-metrics/get_dataset_configID_list/` + projectName, requestOptions).then(handleResponse);
}

export function getDashboardCompareData(projectName) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/dashboard-metrics/get_dataset_modelID_list/` + projectName, requestOptions).then(handleResponse);
}

export function getCoveData(id, recordId) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/get_cove_details/` + id + '/' + recordId, requestOptions).then(handleResponse);
}


export function getAllMetricesById(id) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/metrics_config/` + id, requestOptions).then(handleResponse);
}


export function updateConfiguration(data, id) {
    const requestOptions = {
        method: "PUT",
        // credentials: 'include',
        mode: "cors",
        cache: "default",
        headers: {
            "Content-Type": "application/json",
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    return fetch(
        `${process.env.REACT_APP_BASE_API_URL}/evaluation-controller/update_metrics_selection/` + id,
        requestOptions
    ).then(handleResponse);
}

export function getInsights(executionId) {
    const requestOptions = {
        method: 'GET',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
    };
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/insights/` + executionId, requestOptions).then(handleResponse);
}

export function evaluateSearch(data) {

    const params = new URLSearchParams(data).toString();
    const url = `${process.env.REACT_APP_BASE_API_URL}/controller/evaluate_search?${params}`;

    const requestOptions = {
        method: 'POST',
        // credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': authHeader()
        },
        body: JSON.stringify(data),
    };
    // return fetch(url, requestOptions).then(handleResponse);
    return fetch(`${process.env.REACT_APP_BASE_API_URL}/controller/evaluate_search`, requestOptions).then(handleResponse);
}

// 67501d0ba1e851bb7ab4876a
// 6751400a8748c1d45b0ba224
// 67517e1817c3fa3dc9722428 - not working (format different)