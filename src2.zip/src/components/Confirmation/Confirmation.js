import {
  Box,
  Button,
  IconButton,
  Modal,
  Paper,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import CloseIcon from "@mui/icons-material/Close";

import styles from "./Confirmation.module.css";

const Confirmation = (props) => {
  return (
    <Modal
      open={props.open}
      onClose={props.toggleConfirm}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          maxWidth: "90%", // Adjust the maximum width as needed
          width: "30rem",
          bgcolor: "background.paper",
          boxShadow: 24,
          overflow: "auto", // Enable scrolling if content overflows
          maxHeight: "80vh", // Set a maximum height to trigger scrolling
          // p: 2,
          borderRadius: "1rem",
        }}
      >
        <Paper square elevation={1} className={styles.modalHeader}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Confirmation
          </Typography>
          <IconButton onClick={props.toggleConfirm}>
            {" "}
            <CloseIcon />
          </IconButton>
        </Paper>
        <div className={styles.modalContent}>
          <Typography>{props.message}</Typography>
        </div>
        <div className={styles.modalFooter}>
          <Button
            centerRipple
            variant="contained"
            color="inherit"
            onClick={props.toggleConfirm}
          >
            Cancel
          </Button>
          <Button centerRipple variant="contained" color="error" onClick={props.handleSubmit}>
            Proceed
          </Button>
        </div>
      </Box>
    </Modal>
  );
};

export default Confirmation;
