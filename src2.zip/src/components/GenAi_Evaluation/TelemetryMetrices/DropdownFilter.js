import React, { useState } from "react";
import "./DropdownFilter.css";
import FilterIcon from "../../../assets/genaiIcons/filter_icon.png"

const DropdownFilter = ({
    data,
    selectedTopic,
    selectedSubTopics,
    onTopicChange,
    onSubTopicChange,
    applyFilterData,
    clearFilters
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const toggleDropdown = () => setIsOpen((prev) => !prev);
    const closeFilter = () => setIsOpen((prev) => !prev);
    const applyFilter = () => {
        setIsOpen((prev) => !prev);
        applyFilterData()
    }
    const clearFilter = () => {
        setIsOpen((prev) => !prev);
        clearFilters()
    }
    return (
        <div className="filter-dropdown-container">
            <button className="filter-toggle-button" onClick={toggleDropdown}>
                <img src={FilterIcon} /> &nbsp;All Topics
            </button>
            {isOpen && (
                <div className="filter-dropdown">
                    {Object.entries(data).map(([topic, subTopics]) => (
                        <div key={topic} className="filter-group">
                            <label className="filter-radio">
                                <input
                                    type="radio"
                                    name="topic"
                                    value={topic}
                                    checked={selectedTopic === topic}
                                    onChange={(e) => onTopicChange(e.target.value)}
                                />
                                {topic}
                            </label>
                            {selectedTopic === topic && (
                                <div className="subtopics-container">
                                    {subTopics.map((sub) => (
                                        <label key={sub} className="filter-checkbox">
                                            <input
                                                type="checkbox"
                                                value={sub}
                                                checked={selectedSubTopics.includes(sub)}
                                                onChange={(e) => onSubTopicChange(e.target.value, e.target.checked)}
                                            />
                                            {sub}
                                        </label>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}

                    <div className="filter-btns">
                        <button className="close-filter-btn" onClick={clearFilter}>
                            Close
                        </button>
                        <button className="apply-filter-btn" onClick={applyFilter}>
                            Apply
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
export default DropdownFilter;