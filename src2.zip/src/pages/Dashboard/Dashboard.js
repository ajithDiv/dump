import {
  Box,
  Checkbox,
  Chip,
  CircularProgress,
  FormControl,
  InputLabel,
  ListItemText,
  MenuItem,
  Paper,
  Select,
  Stack,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Tabs,
} from "@mui/material";
// import { LineChart } from "@mui/x-charts";
// import { BarChart } from "@mui/x-charts/BarChart";
import React, { useContext, useEffect, useState } from "react";

import styles from "./Dashboard.css";
import { AuthContext } from "../../globals/AuthContext";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Rectangle,
  ResponsiveContainer,
  Text,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import BarChartComponent from "../../components/GenAi_Evaluation/PerformanceMetrics/BarChart";
import {
  getDashboardCompareData,
  getDashboardOverallData,
} from "../../_services/genai_evaluation.service";
import NorthIcon from '@mui/icons-material/North';
import SouthIcon from '@mui/icons-material/South';
import ChartComponent from './ChartComponent';
import MetricsTable from './MetricsTable';
import mockData from './mockData.json'
const sampleData =
  [
    {
      "datasetName": "Sum-Data",
      "configurationName": "TestSum",
      "run_name": "RUn 01",
      "evaluation_metrics_status": [
        {
          "metric": "Stereotype",
          "Total Passed": 0,
          "Total Failed": 3
        },
        {
          "metric": "PII Detection",
          "Total Passed": 0,
          "Total Failed": 3
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Stereotype",
          "ThresholdValue": 0.5,
          "Total Passed": 0.0,
          "Total Failed": 100.0,
          "ActualValue": 0.0
        },
        {
          "metric": "PII Detection",
          "ThresholdValue": 0.5,
          "Total Passed": 0.0,
          "Total Failed": 100.0,
          "ActualValue": 0.0
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "Summeraj",
      "run_name": "Run 02",
      "evaluation_metrics_status": [
        {
          "metric": "QA Score",
          "Total Passed": 10,
          "Total Failed": 1
        },
        {
          "metric": "Robustness",
          "Total Passed": 11,
          "Total Failed": 0
        },
        {
          "metric": "Grammatical Check",
          "Total Passed": 9,
          "Total Failed": 2
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 90.91,
          "Total Failed": 9.09,
          "ActualValue": 0.6988
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 100.0,
          "Total Failed": 0.0,
          "ActualValue": 1.0
        },
        {
          "metric": "Grammatical Check",
          "ThresholdValue": 0.5,
          "Total Passed": 81.82,
          "Total Failed": 18.18,
          "ActualValue": 0.7155
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "AJSumm",
      "run_name": "Run A1",
      "evaluation_metrics_status": [
        {
          "metric": "Robustness",
          "Total Passed": 10,
          "Total Failed": 0
        }
      ],
      "evaluation_metrics_threshold_status": []
    },
    {
      "datasetName": "SummAj",
      "configurationName": "AjaySumm",
      "run_name": "",
      "evaluation_metrics_status": [
        {
          "metric": "Robustness",
          "Total Passed": 11,
          "Total Failed": 1
        },
        {
          "metric": "Grammatical Check",
          "Total Passed": 9,
          "Total Failed": 2
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 91.67,
          "Total Failed": 8.33,
          "ActualValue": 0.8333
        },
        {
          "metric": "Grammatical Check",
          "ThresholdValue": 0.5,
          "Total Passed": 81.82,
          "Total Failed": 18.18,
          "ActualValue": 0.6545
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "Summarize",
      "run_name": "Run b1",
      "evaluation_metrics_status": [
        {
          "metric": "Error Detection",
          "Total Passed": 8,
          "Total Failed": 2
        },
        {
          "metric": "QA Score",
          "Total Passed": 7,
          "Total Failed": 3
        },
        {
          "metric": "Robustness",
          "Total Passed": 0,
          "Total Failed": 10
        },
        {
          "metric": "Grammatical Check",
          "Total Passed": 5,
          "Total Failed": 5
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Error Detection",
          "ThresholdValue": 0.5,
          "Total Passed": 80.0,
          "Total Failed": 20.0,
          "ActualValue": 0.71
        },
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 70.0,
          "Total Failed": 30.0,
          "ActualValue": 0.6267
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 0.0,
          "Total Failed": 100.0,
          "ActualValue": 0.0
        },
        {
          "metric": "Grammatical Check",
          "ThresholdValue": 0.5,
          "Total Passed": 50.0,
          "Total Failed": 50.0,
          "ActualValue": 0.48
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "NewTest",
      "run_name": "Run b2",
      "evaluation_metrics_status": [
        {
          "metric": "Error Detection",
          "Total Passed": 15,
          "Total Failed": 10
        },
        {
          "metric": "QA Score",
          "Total Passed": 25,
          "Total Failed": 0
        },
        {
          "metric": "Fluency",
          "Total Passed": 10,
          "Total Failed": 15
        },
        {
          "metric": "Robustness",
          "Total Passed": 10,
          "Total Failed": 15
        },
        {
          "metric": "Grammatical Check",
          "Total Passed": 22,
          "Total Failed": 3
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Error Detection",
          "ThresholdValue": 0.5,
          "Total Passed": 60.0,
          "Total Failed": 40.0,
          "ActualValue": 0.552
        },
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 100.0,
          "Total Failed": 0.0,
          "ActualValue": 0.7892
        },
        {
          "metric": "Fluency",
          "ThresholdValue": 0.5,
          "Total Passed": 40.0,
          "Total Failed": 60.0,
          "ActualValue": 0.38
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 40.0,
          "Total Failed": 60.0,
          "ActualValue": 0.4
        },
        {
          "metric": "Grammatical Check",
          "ThresholdValue": 0.5,
          "Total Passed": 88.0,
          "Total Failed": 12.0,
          "ActualValue": 0.72
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "testing",
      "run_name": "Run 05",
      "evaluation_metrics_status": [
        {
          "metric": "Error Detection",
          "Total Passed": 9,
          "Total Failed": 1
        },
        {
          "metric": "QA Score",
          "Total Passed": 10,
          "Total Failed": 5
        },
        {
          "metric": "Fluency",
          "Total Passed": 14,
          "Total Failed": 1
        },
        {
          "metric": "Robustness",
          "Total Passed": 5,
          "Total Failed": 15
        },
        {
          "metric": "Grammatical Check",
          "Total Passed": 13,
          "Total Failed": 2
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Error Detection",
          "ThresholdValue": 0.5,
          "Total Passed": 90.0,
          "Total Failed": 10.0,
          "ActualValue": 0.79
        },
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 66.67,
          "Total Failed": 33.33,
          "ActualValue": 0.6089
        },
        {
          "metric": "Fluency",
          "ThresholdValue": 0.5,
          "Total Passed": 93.33,
          "Total Failed": 6.67,
          "ActualValue": 0.7938
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 33.33,
          "Total Failed": 66.67,
          "ActualValue": 0.3333
        },
        {
          "metric": "Grammatical Check",
          "ThresholdValue": 0.5,
          "Total Passed": 86.67,
          "Total Failed": 13.33,
          "ActualValue": 0.6767
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "configtest",
      "run_name": "Run 16",
      "evaluation_metrics_status": [
        {
          "metric": "QA Score",
          "Total Passed": 83,
          "Total Failed": 1
        },
        {
          "metric": "Robustness",
          "Total Passed": 66,
          "Total Failed": 4
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 98.81,
          "Total Failed": 1.19,
          "ActualValue": 0.7837
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 94.29,
          "Total Failed": 5.71,
          "ActualValue": 0.9429
        }
      ]
    },
    {
      "datasetName": "Unknown",
      "configurationName": "configtest",
      "run_name": "Run a8",
      "evaluation_metrics_status": [
        {
          "metric": "QA Score",
          "Total Passed": 10,
          "Total Failed": 0
        },
        {
          "metric": "Robustness",
          "Total Passed": 10,
          "Total Failed": 0
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 100.0,
          "Total Failed": 0.0,
          "ActualValue": 0.761
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 100.0,
          "Total Failed": 0.0,
          "ActualValue": 1.0
        }
      ]
    },
    {
      "datasetName": "Temp",
      "configurationName": "configtest",
      "run_name": "Run 10",
      "evaluation_metrics_status": [
        {
          "metric": "QA Score",
          "Total Passed": 4,
          "Total Failed": 1
        },
        {
          "metric": "Robustness",
          "Total Passed": 0,
          "Total Failed": 5
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "QA Score",
          "ThresholdValue": 0.5,
          "Total Passed": 80.0,
          "Total Failed": 20.0,
          "ActualValue": 0.748
        },
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 0.0,
          "Total Failed": 100.0,
          "ActualValue": 0.0
        }
      ]
    },
    {
      "datasetName": "SummAj",
      "configurationName": "configtest",
      "run_name": "RUN1_AZ",
      "evaluation_metrics_status": [
        {
          "metric": "Robustness",
          "Total Passed": 5,
          "Total Failed": 0
        }
      ],
      "evaluation_metrics_threshold_status": [
        {
          "metric": "Robustness",
          "ThresholdValue": 0.5,
          "Total Passed": 100.0,
          "Total Failed": 0.0,
          "ActualValue": 1.0
        }
      ]
    }
  ]


const renderLegend = (props) => {
  const { payload } = props;

  return (
    <ul>
      {payload.map((entry, index) => (
        <li key={`item-${index}`}>{entry.value}</li>
      ))}
    </ul>
  );

  // return <div style={{ fontSize: "1rem", color: "black", height: "1rem" }}>{props.label}</div>
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{ opacity: 0.8, backgroundColor: "white", padding: " 0 0.5rem", borderRadius: "0.5rem" }}>
        <p className="label">{`${payload[0].payload.metric}`}</p>
        {payload.map(item => <p className="label">{item.name} : {item.value}</p>)}
      </div>
    );
  }
}

const Dashboard = () => {
  const ctx = useContext(AuthContext);
  ctx.updateHeader("Dashboard");
  const [tabValue, setTabValue] = React.useState("1");

  const [overallData, setOverallData] = useState([]);
  const [compareData, setCompareData] = useState([]);

  const [datasetList, setDatasetList] = useState([
    ...new Set(overallData.map((item) => item.datasetName)),
  ]);
  const [configurationList, setConfigurationList] = useState([]);
  const [metricsList, setMetricsList] = useState([]);

  const [dataset, setDataset] = useState("");
  const [configuration, setConfiguration] = useState("");
  const [metrics, setMetrics] = useState("");

  const [pass, setPass] = useState([]);
  const [fail, setFail] = useState([]);

  const [datasetList2, setDatasetList2] = useState([
    ...new Set(compareData.map((item) => item.datasetName)),
  ]);
  const [configurationList2, setConfigurationList2] = useState([]);
  const [modelList, setModelList] = useState([]);
  const [metricsList2, setMetricsList2] = useState([]);

  const [dataset2, setDataset2] = useState("");
  const [configuration2, setConfiguration2] = useState("");
  const [model, setModel] = useState("");
  const [model2, setModel2] = useState("");
  const [metrics2, setMetrics2] = useState([]);

  const [barData, setBarData] = useState([]);
  const [barData2, setBarData2] = useState([]);

  const [metricsAccuracy1, setMetricsAccuracy1] = useState({});
  const [metricsAccuracy2, setMetricsAccuracy2] = useState({});

  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [data, setData] = useState([]);

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };



  const [isExpanded, setIsExpanded] = useState(false);
  const runs = Object.keys(mockData[0]).filter(k => k !== 'Metric Name');
  const colorMap = runs.reduce((acc, run, index) => {
    acc[run] = `hsl(${index * 50}, 70%, 50%)`;
    return acc;
  }, {});


  const handleDatasetChange = (event) => {
    setDataset(event.target.value);
    setConfiguration("");
    setMetrics("");
    let arr = overallData.filter(
      (item) => item.datasetName === event.target.value
    );
    setConfigurationList([
      ...new Set(arr.map((item) => item.configurationName)),
    ]);
  };

  const handleConfigurationChange = (event) => {
    setConfiguration(event.target.value);
    setMetrics("");
    let arr = overallData.filter(
      (item) => item.configurationName === event.target.value
    );
    if (arr.length > 0) {
      setMetricsList(
        arr[0].evaluation_metrics_status.map((item) => item.metric)
      );
    }
  };

  const handleMetricsChange = (event) => {
    setMetrics(event.target.value);
    let passArr = [],
      failArr = [];

    overallData.map((item) => {
      if (
        item.datasetName === dataset &&
        item.configurationName === configuration
      ) {
        item.evaluation_metrics_status.map((met) => {
          if (met.metric === event.target.value) {
            passArr.push(met["Total Passed"]);
            failArr.push(met["Total Failed"]);
          }
        });
      }
    });
    setPass(passArr);
    setFail(failArr);
  };

  const handleDataset2Change = (event) => {
    setDataset2(event.target.value);
    setConfiguration2("");
    setModel("");
    setModelList([]);
    setModel2("");
    setMetrics2([]);
    setMetricsList2([]);
    setBarData([]);
    setBarData2([]);
    let arr = compareData.filter(
      (item) => item.datasetName === event.target.value
    );
    setConfigurationList2([
      ...new Set(arr.map((item) => item.configurationName)),
    ]);
  };

  const handleConfiguration2Change = (event) => {
    setConfiguration2(event.target.value);
    setModel("");
    setModel2("");
    setMetrics2([]);
    setMetricsList2([]);
    setBarData([]);
    setBarData2([]);
    let arr = compareData.filter(
      (item) => item.configurationName === event.target.value
    );
    setModelList([...new Set(arr.map((item) => item.run_name))]);
  };

  const handleModelChange = (event) => {
    setModel(event.target.value);
    setMetrics2([]);
    setBarData([]);
    setBarData2([]);
    let arr = compareData.filter(
      (item) => item.configurationName === configuration2
    );
    if (arr.length > 0) {
      setMetricsList2(
        arr[0].evaluation_metrics_status.map((item) => item.metric)
      );
    }
    let cnt = 0;
    let temp = {};
    compareData.map((item) => {
      if (
        item.datasetName === dataset2 ||
        item.configurationName === configuration2 ||
        item.model === event.target.value
      ) {
        cnt++;
        item.evaluation_metrics_threshold_status.map((sub) => {
          if (temp[sub.metric]) {
            temp[sub.metric]["value"] += sub["Total Passed"];
          } else {
            temp[sub.metric] = {
              value: sub["Total Passed"],
              threshold: sub.ThresholdValue,
            };
          }
        });
      }
    });

    Object.keys(temp).map((item) => {
      temp[item]["value"] = (temp[item]["value"] / cnt).toFixed(2);
    });
    setMetricsAccuracy1(temp);
  };

  const handleModel2Change = (event) => {
    setModel2(event.target.value);
    setMetrics2([]);
    setBarData([]);
    setBarData2([]);
    let arr = compareData.filter(
      (item) => item.configurationName === configuration2
    );
    if (arr.length > 0) {
      setMetricsList2(
        arr[0].evaluation_metrics_status.map((item) => item.metric)
      );
    }

    let cnt = 0;
    let temp = {};
    compareData.map((item) => {
      if (
        item.datasetName === dataset2 ||
        item.configurationName === configuration2 ||
        item.model === event.target.value
      ) {
        cnt++;
        item.evaluation_metrics_threshold_status.map((sub) => {
          if (temp[sub.metric]) {
            temp[sub.metric]["value"] += sub["Total Passed"];
          } else {
            temp[sub.metric] = {
              value: sub["Total Passed"],
              threshold: sub.ThresholdValue,
            };
          }
        });
      }
    });

    Object.keys(temp).map((item) => {
      temp[item]["value"] = (temp[item]["value"] / cnt).toFixed(2);
    });
    setMetricsAccuracy2(temp);
  };

  const handleMetrics2Change = (event) => {
    let selectedMetrices = event.target.value;
    if (metrics2.length < event.target.value.length) {
      let curMet = event.target.value[event.target.value.length - 1];
      let passed = 0,
        failed = 0;
      compareData.map((item) => {
        if (
          item.datasetName === dataset2 ||
          item.configurationName === configuration2 ||
          item.model === model
        ) {
          item.evaluation_metrics_status.map((met) => {
            if (met.metric === curMet) {
              passed += met["Total Passed"];
              failed += met["Total Failed"];
            }
          });
        }
      });
      setBarData((prev) => [
        ...prev,
        {
          metric: curMet,
          "Total Passed": passed,
          "Total Failed": failed,
          tag: curMet[0],
        },
      ]);
      passed = 0;
      failed = 0;
      compareData.map((item) => {
        if (
          item.datasetName === dataset2 ||
          item.configurationName === configuration2 ||
          item.model === model2
        ) {
          item.evaluation_metrics_status.map((met) => {
            if (met.metric === curMet) {
              passed += met["Total Passed"];
              failed += met["Total Failed"];
            }
          });
        }
      });
      setBarData2((prev) => [
        ...prev,
        {
          metric: curMet,
          "Total Passed": passed,
          "Total Failed": failed,
          tag: curMet[0],
        },
      ]);
    } else {
      setBarData((prev) =>
        prev.filter((item) => selectedMetrices.indexOf(item.metric) > -1)
      );
      setBarData2((prev) =>
        prev.filter((item) => selectedMetrices.indexOf(item.metric) > -1)
      );
    }
    setMetrics2(event.target.value);
  };

  useEffect(() => {
    getDashboardOverallData(ctx.projectName).then((result) => {
      sampleData.map((item) => {
        item.evaluation_metrics_status.map((met) => {
          met["tag"] = met.metric[0];
        });
      });
      setOverallData(sampleData);
      setDatasetList([...new Set(sampleData.map((item) => item.datasetName))]);
    });

    sampleData.map((item) => {
      item.evaluation_metrics_status.map((met) => {
        met["tag"] = met.metric[0];
      });
    });
    setOverallData(sampleData);
    setDatasetList([...new Set(sampleData.map((item) => item.datasetName))]);
    setCompareData(sampleData);
    setDatasetList2([...new Set(sampleData.map((item) => item.datasetName))]);

    getDashboardCompareData(ctx.projectName).then((result) => {
      sampleData.map((item) => {
        item.evaluation_metrics_status.map((met) => {
          met["tag"] = met.metric[0];
        });
      });
      setCompareData(sampleData);
      setDatasetList2([...new Set(sampleData.map((item) => item.datasetName))]);
    });
  }, []);

  return (
    <div style={{ height: "calc(100vh - 75px)" }}>
      <Paper elevation={3} style={{ margin: "1rem", padding: "1rem" }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          aria-label="basic tabs"
        >
          <Tab label="Overall" value="1" />
          <Tab label="Compare" value="2" />
        </Tabs>
        <br />
        <br />

        {tabValue === "1" && (
          <>
            <div className="parameterContainer">
              <FormControl className="selectContainer">
                <InputLabel id="Dataset-select-label">Dataset</InputLabel>
                <Select
                  labelId="Dataset-select-label"
                  id="Dataset-select"
                  value={dataset}
                  label="Dataset"
                  onChange={handleDatasetChange}
                >
                  {datasetList.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl className="selectContainer">
                <InputLabel id="Configuration-select-label">
                  Configuration
                </InputLabel>
                <Select
                  labelId="Configuration-select-label"
                  id="Configuration-select"
                  value={configuration}
                  label="Configuration"
                  onChange={handleConfigurationChange}
                >
                  {configurationList.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl className="selectContainer">
                <InputLabel id="Metrics-select-label">Metrics</InputLabel>
                <Select
                  labelId="Metrics-select-label"
                  id="Metrics-select"
                  value={metrics}
                  label="Metrics"
                  onChange={handleMetricsChange}
                >
                  {metricsList.map((name, index) => (
                    <MenuItem key={name} value={name}>
                      {/* <Checkbox checked={metrics.indexOf(name) > -1} /> */}
                      <ListItemText primary={name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>

            {/* <LineChart
              xAxis={[
                {
                  label: "Executions",
                  // data: [1, 2, 3, 4, 5]
                  data: pass.map((itm, idx) => idx + 1),
                },
              ]}
              yAxis={[{ label: "Record Count" }]}
              series={[
                { curve: "linear", data: pass, color: "green" },
                { curve: "linear", data: fail, color: "red" },
              ]}
              width={800}
              height={350}
            /> */

              <div className="main-layout">
                {/* Left: Chart */}
                <div className="chart-area">
                  <div className="chart-header">
                    <h3>Run/Metrics Overview</h3>
                  </div>
                  <ChartComponent data={mockData} runs={runs} colorMap={colorMap} />
                </div>


                <div
                  className={`table-panel ${isExpanded ? 'expanded' : 'collapsed'}`}
                >
                  <div className="table-head">
                    <div className="toggle-btn" onClick={() => setIsExpanded(!isExpanded)}>
                      {isExpanded ? '››' : '‹‹'}
                    </div>
                    <h3>Table View</h3>
                  </div>
                  <MetricsTable data={mockData} runs={runs} colorMap={colorMap} isExpanded={isExpanded} />
                </div>
              </div>
            }
          </>
        )}

        {tabValue === "2" && (
          <>
            <div className="parameterContainer">
              <FormControl className="selectContainer">
                <InputLabel id="Dataset-select-label">Dataset</InputLabel>
                <Select
                  labelId="Dataset-select-label"
                  id="Dataset-select"
                  value={dataset2}
                  label="Dataset"
                  onChange={handleDataset2Change}
                >
                  {datasetList2.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl className="selectContainer">
                <InputLabel id="Configuration-select-label">
                  Configuration
                </InputLabel>
                <Select
                  labelId="Configuration-select-label"
                  id="Configuration-select"
                  value={configuration2}
                  label="Configuration"
                  onChange={handleConfiguration2Change}
                >
                  {configurationList2.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl className="selectContainer">
                <InputLabel id="Model-select-label">Run Name</InputLabel>
                <Select
                  labelId="Model-select-label"
                  id="Model-select"
                  value={model}
                  label="Run Name"
                  onChange={handleModelChange}
                >
                  {modelList.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              {/* <FormControl className="selectContainer">
                <InputLabel id="Model-select-label">Model 2</InputLabel>
                <Select
                  labelId="Model-select-label"
                  id="Model-select"
                  value={model2}
                  label="Model 2"
                  onChange={handleModel2Change}
                >
                  {modelList.map((item, index) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </Select>
              </FormControl> */}

              <FormControl className="selectContainer">
                <InputLabel id="Metrics-select-label">Metrics</InputLabel>
                <Select
                  labelId="Metrics-select-label"
                  id="Metrics-select"
                  value={metrics2}
                  label="Metrics"
                  onChange={handleMetrics2Change}
                  multiple
                  renderValue={(selected) => selected.join(", ")}
                >
                  {metricsList2.map((name, index) => (
                    <MenuItem key={name} value={name}>
                      <Checkbox checked={metrics2.indexOf(name) > -1} />
                      <ListItemText primary={name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
            <br />
            <div style={{ textAlign: "center" }}>{model}</div>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart
                data={barData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <Text> Gpt-35 </Text>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="tag" />
                <YAxis
                  label={{
                    value: "Record Count",
                    angle: -90,
                    position: "insideLeft",
                  }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                {/* <Bar dataKey="Total Executed" fill={colors[0]} /> */}
                <Bar dataKey="Total Passed" fill="#8884d8" />
                <Bar dataKey="Total Failed" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
            <br />
            <div style={{ textAlign: "center" }}>{model2}</div>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart
                data={barData2}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="tag" />
                <YAxis
                  label={{
                    value: "Record Count",
                    angle: -90,
                    position: "insideLeft",
                  }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                {/* <Bar dataKey="Total Executed" fill={colors[0]} /> */}
                <Bar dataKey="Total Passed" fill="#8884d8" />
                <Bar dataKey="Total Failed" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>

            <br />

            <TableContainer component={Paper}>
              <Table aria-label="Material-UI Table">
                <TableHead sx={{ background: "#111270", color: "#fff" }}>
                  <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                    <TableCell
                      sx={{
                        // width: "2.5rem",
                        color: "#fff",
                        textAlign: "left",
                      }}
                    >
                      <strong>Metrices</strong>
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Threshold</strong>
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Model-1 Accuracy</strong>
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      <strong>Model-2 Accurancy</strong>
                    </TableCell>
                  </TableRow>
                </TableHead>
                {loading === true ? (
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={4}>
                        <Stack
                          width="100%"
                          direction="row"
                          justifyContent="center"
                        >
                          <CircularProgress />
                        </Stack>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                ) : Object.keys(metricsAccuracy1).length === 0 &&
                  Object.keys(metricsAccuracy2).length === 0 ? (
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={4}>
                        <Stack
                          width="100%"
                          direction="row"
                          justifyContent="center"
                        >
                          No Data Availble
                        </Stack>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                ) : (
                  <TableBody>
                    {Object.keys(metricsAccuracy1)
                      .slice(page * rowPage, page * rowPage + rowPage)
                      .map((row, index) => {
                        const uniqueRowNumber = page * rowPage + index + 1;
                        return (
                          <TableRow
                            key={index}
                            style={
                              index % 2
                                ? { background: "#F6F6F6" }
                                : { background: "white" }
                            }
                          >
                            <TableCell>
                              {metricsAccuracy1[row] && row}
                            </TableCell>
                            <TableCell>
                              {metricsAccuracy1[row] && metricsAccuracy1[row].threshold}
                            </TableCell>
                            <TableCell style={{ verticalAlign: "center" }}>
                              {metricsAccuracy1[row] && metricsAccuracy1[row].value} {metricsAccuracy1[row] >= metricsAccuracy2[row] ? <NorthIcon fontSize={"small"} color="success" /> : <SouthIcon fontSize="small" color="error" />}
                            </TableCell>
                            <TableCell>
                              {metricsAccuracy2[row] && metricsAccuracy2[row].value} {metricsAccuracy2[row] > metricsAccuracy1[row] ? <NorthIcon fontSize={"small"} color="success" /> : <SouthIcon fontSize="small" color="error" />}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                )}
              </Table>
            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={data.length}
              rowsPerPage={rowPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </>
        )}
      </Paper>
    </div>
  );
};

export default Dashboard;
