import React from 'react';
import './MetricsTable.css';
const MetricsTable = ({ data, runs, isExpanded, colorMap }) => {
    const visibleRuns = isExpanded ? runs : runs.slice(0, 4);
    return (
        <div className="table-container">
            <table className="metrics-table">
                <thead>
                    <tr>
                        <th className="column-header">Metric Name</th>
                        {visibleRuns.map(run => (
                            <th key={run} className="column-header">{run}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, idx) => (
                        <tr key={idx}>
                            <td className="metric-label">{row['Metric Name']}</td>
                            {visibleRuns.map(run => (
                                <td key={run} style={{ color: colorMap[run] }}>
                                    {row[run]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
export default MetricsTable;