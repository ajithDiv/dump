import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import { Link } from 'react-router-dom';
import { userService, validationService } from '../../_services';
import base64 from 'react-native-base64';
import DOMPurify from 'dompurify';
import { CircularProgress } from '@mui/material';

class CreateUser extends Component {

  constructor(props) {
    super(props);
    this.state = {
      user: {},
      username: '',
      password: '',
      firstName: '',
      lastName: '',
      emailId: '',
      submitted: false,
      loading: false,
      error: '',
      action: '',
      ldapUser: false,
      selectedRolePrivilege: 'executionRole',
      userError: '',
      executeUserRole:'devUser',
      passwordType:'password',
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateUser = this.updateUser.bind(this);
    this.onRadioChangeType = this.onRadioChangeType.bind(this);
    this.handleErrorClose = this.handleErrorClose.bind(this);
    this.setUserPrivilege = this.setUserPrivilege.bind(this);
    this.setUserRole=this.setUserRole.bind(this);
    this.onHandlePassword=this.onHandlePassword.bind(this);
  }

  componentDidMount() {
    this.setState({isLoading: true});
    const action = this.props.match.params.action;
    this.setState({ action: action});
    const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
    userService.getUserDetails(sanitizedUserName).then(data => {
      this.setState({
        selectedUserPrivilege: data.selectedRolePrivilege,
      })
    if(this.state.selectedUserPrivilege == 'superAdmin'){
      if(action === 'create') {
        this.setState({
          isLoading: false
        })
      } else {
        userService.getUserDetails(this.props.match.params.id).then( data => {
          this.setState({
            user: data,
            username: data.username,
            password: data.username!='admin' ?  atob(data.authToken).split(":")[1] : (data.authToken!=null  ? atob(data.authToken).split(":")[1] : data.username+'temp'),
            authString:data.authString!=null?data.authString:null,
            firstName: data.firstName,
            lastName: data.lastName,
            emailId: data.emailId,
            ldapUser: data.ldapUser,
            isLoading: false,
            selectedRolePrivilege: data.selectedRolePrivilege,
            executeUserRole:data.username=="admin"||data.selectedRolePrivilege=="readOnlyRole"?null:data.executeUserRole!=null?data.executeUserRole:this.state.executeUserRole
          })
        });
      }
    }else{
      this.setState({
        userError: 'You do not have permission to access this tab.',
        loading: false,
      })
    }
  })
  }

  handleChange(e) {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  isValidForm() {
    const {firstName, lastName, emailId, username} = this.state;
    return firstName && lastName && emailId && username;
  }

  handleSubmit() {
    // e.preventDefault();
    let authToken = base64.encode(this.state.username + ":" + this.state.password);
    const { username, password, firstName, lastName, emailId, ldapUser, selectedRolePrivilege} = this.state;
    let userObj;
    const executeUserRole =this.state.selectedRolePrivilege!='readOnlyRole' ? this.state.executeUserRole:null
    
    if (ldapUser) {
      if (!username) {
        this.setState({
          error: 'Please enter user name', 
          loading: false 
        })
       return Promise.reject(this.state.error);
      }
    } else {
      if (!(username && password)) {
        this.setState({
          error: 'Please enter user name and password', 
          loading: false 
        })
       return Promise.reject(this.state.error);      
      }
    }

    
    this.setState({ submitted: true });
    this.setState({ loading: true });
    
    if(this.state.action === 'edit') {
      
      if (validationService.forNames(firstName) ){
        this.setState({
           error: 'First ' + validationService.forNames(firstName), 
        loading: false })
        return Promise.reject(this.state.error);
      }
      if (validationService.forNames(lastName) ){
        this.setState({
           error: 'Last ' + validationService.forNames(lastName), 
        loading: false })
        return Promise.reject(this.state.error);
      }
      if (validationService.forEmails(emailId)){
        this.setState({
          error: validationService.forEmails(emailId),
          loading: false
        })   
        return Promise.reject(this.state.error)
      }
      if(validationService.forPasswords(password)){
        this.setState({
          error: validationService.forPasswords(password),
          loading: false
        })
        return Promise.reject(this.state.error)
      }      
      this.updateUser();
      return;
    }
    // to create user  
    else {
      userObj = JSON.stringify({username, firstName, lastName, emailId, ldapUser, authToken, selectedRolePrivilege,executeUserRole});
    }
    if (validationService.forNames(username) ){
      this.setState({
         error: 'User ' + validationService.forNames(username), 
      loading: false })
      return Promise.reject(this.state.error);
    }
    if (validationService.forNames(firstName) ){
      this.setState({
         error: "First " + validationService.forNames(firstName), 
      loading: false })
      return Promise.reject(this.state.error);
    }
    if (validationService.forNames(lastName) ){
      this.setState({
         error: 'Last ' + validationService.forNames(lastName), 
      loading: false })
      return Promise.reject(this.state.error);
    }
    if (validationService.forEmails(emailId)){
      this.setState({
        error: validationService.forEmails(emailId),
        loading: false
      })
 
      return Promise.reject(this.state.error)
    }
    if(validationService.forPasswords(password)){
      this.setState({
        error: validationService.forPasswords(password),
        loading: false
      })
      return Promise.reject(this.state.error)
    }

    userService.createUser(userObj)
      .then(
          response => {
              const { from } = { from: { pathname: "/settings/users" } };
              this.props.history.push(from);
          },
          error => this.setState({ error, loading: false })
      );
  }

  updateUser() {
    let userObj = this.state.user;
    this.state.user.firstName = this.state.firstName;
    this.state.user.lastName = this.state.lastName;
    this.state.user.emailId = this.state.emailId;
    this.state.user.username = this.state.username;
    this.state.user.ldapUser = this.state.ldapUser;
    this.state.user.selectedRolePrivilege = this.state.selectedRolePrivilege;
    this.state.user.authToken = '';
    if (this.state.password && this.state.password !== this.state.user.username+ 'temp') {
      this.state.user.authToken = base64.encode(this.state.username + ":" + this.state.password);
    }

    this.state.user = JSON.stringify(this.state.user);

    userService.updateUser(this.state.user)
    .then(
        response => {
            const { from } = { from: { pathname: "/settings/users" } };
            this.props.history.push(from);
        },
        error => this.setState({ error, loading: false })
    );
  }

  onRadioChangeType(e) {
    this.setState({
      [e.target.name]: e.target.value.toLowerCase() == 'true' ? true : false,
    })
  }

  handleErrorClose() {
    this.setState({ error : '',loading : true });
  }

  setUserPrivilege(e){
    this.setState({
      selectedRolePrivilege: e.target.value
    });
  }

  setUserRole(e){
    this.setState({
      executeUserRole: e.target.value
    });
  }

  onHandlePassword(){
    if(this.state.passwordType=='password'){
      this.setState({
        passwordType:'text',
      })
    }else{
      this.setState({
        passwordType:'password',
      })
    }
  }

  render() {
    const { username, password, firstName, lastName, emailId, submitted, loading, error } = this.state;
    if (loading) {
      return <CircularProgress/>;
    }
    return (
      <div className="animated fadeIn">
        {
          this.state.userError &&
          <div className="alertmessage alert alert-danger">
              <a className="close">
                <span aria-hidden="true">&nbsp;&times;</span>
              </a>
              <span className="span-message">{this.state.userError}</span>
            </div>
        }
        { !this.state.userError &&        
        <Row>
          <Col xs="12" sm="9">
            <Card>
              <CardHeader>
                <strong>User</strong>
                <small> Form</small>
              </CardHeader>
              {error && 
                  <div className="alertmessage alert alert-danger">
                    <a className="close" onClick={this.handleErrorClose}>
                        <span aria-hidden="true">&nbsp;&times;</span>
                    </a>
                    <span className="span-message">{error}</span>
                  </div>
                }
              <CardBody>
                <FormGroup row className="my-0">
                  <Col xs="6">
                    <FormGroup>
                      <Label style={{color: 'red'}}>* </Label>
                      <Label htmlFor="mandatory">First Name</Label>
                      <Input type="text" id="firstName" placeholder="Enter your first name" name="firstName" value={firstName} onChange={this.handleChange}/>
                    </FormGroup>
                  </Col>
                  <Col xs="6">
                    <FormGroup>
                      <Label style={{color: 'red'}}>* </Label>
                      <Label htmlFor="mandatory">Last Name</Label>
                      <Input type="text" id="lastName" placeholder="Enter your last name" name="lastName" value={lastName} onChange={this.handleChange}/>
                    </FormGroup>
                  </Col>
                </FormGroup>
                <FormGroup row className="my-0">
                  <Col xs="6">
                    <FormGroup>
                      { this.state.action === 'create' &&
                      <Label style={{color: 'red'}}>* </Label>
                      }
                      <Label htmlFor="mandatory">User Name</Label>
                      { this.state.action === 'create' &&
                      <Input type="text" id="username" placeholder="Enter your User Name" name="username" value={username} onChange={this.handleChange}/>
                      }
                      {this.state.action === 'edit' &&
                      <Input type="text" id="username" 
                      disabled={this.state.username}
                      placeholder="Enter your User Name" name="username" value={username} onChange={this.handleChange}/>
                      }
                      </FormGroup>
                  </Col>
                  {this.state.selectedRolePrivilege != "superAdmin" &&
                  <Col xs="6">
                    <FormGroup>
                      <Label htmlFor="userRole">User Role</Label><br></br>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="execution" name="userRole" value="executionRole" checked={this.state.selectedRolePrivilege == "executionRole"}
                          onChange={this.setUserPrivilege} disabled={this.state.action=="edit"}/>
                        <Label className="form-check-label"  htmlFor="execution">Execution Role &nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="read-only" name="userRole" value="readOnlyRole" checked={this.state.selectedRolePrivilege == "readOnlyRole"}
                            onChange={this.setUserPrivilege} disabled={this.state.action=="edit"}/>                       
                        <Label className="form-check-label"  htmlFor="read-only">Read-Only Role&nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                    </FormGroup>
                  </Col>
                  }
                  {this.state.selectedRolePrivilege == "executionRole" &&
                    <Col xs="6">
                    <FormGroup>
                      <Label htmlFor="devQA">User Type</Label><br></br>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="devUser" name="devUser" value="devUser" checked={this.state.executeUserRole == "devUser"}
                          onChange={this.setUserRole} disabled={this.state.action=="edit"}/>
                        <Label className="form-check-label"  htmlFor="devUser">Dev User &nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="qaUser" name="qaUser" value="qaUser" checked={this.state.executeUserRole == "qaUser"}
                            onChange={this.setUserRole} disabled={this.state.action=="edit"}/>                       
                        <Label className="form-check-label"  htmlFor="qaUser">QA User&nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                    </FormGroup>
                  </Col>
                  }
                  <Col xs="6">
                    <FormGroup>
                      <Label htmlFor="city">LDAP User</Label><br></br>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="model-type-2" name="ldapUser" value="true" checked={this.state.ldapUser} onChange={this.onRadioChangeType} />
                        <Label className="form-check-label"  htmlFor="model-type-2">Yes&nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                      <FormGroup check inline>
                        <input className="form-check-input" type="radio" id="model-type-1" name="ldapUser" value="false" checked={!this.state.ldapUser} onChange={this.onRadioChangeType} />
                        <Label className="form-check-label"  htmlFor="model-type-1">No&nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                    </FormGroup>
                  </Col>
                </FormGroup>
                {
                  !this.state.ldapUser && 
                  <FormGroup row className="my-0">
                    <Col xs="5">
                      <FormGroup>
                        <Label style={{color: 'red'}}>* </Label>
                        <Label htmlFor="mandatory">Password</Label>
                        <Input type={this.state.passwordType} id="password" placeholder="Enter your password" name="password" value={password} onChange={this.handleChange}/>
                        <FormText>Password must at least contain a Capital letter, a lower case, and a number</FormText>
                      </FormGroup>
                    </Col>
                    <Col xs="1">
                      <i style={{padding:"40px",float:"right"}} className={`${this.state.passwordType=="password" ? "fa fa-eye" : "fa fa-eye-slash" }`} onClick={this.onHandlePassword}></i>
                    </Col>
                    <Col xs="6">
                      <FormGroup>
                        <Label htmlFor="vat" style={{color: 'red'}}>* </Label>
                        <Label htmlFor="mandatory">Email ID</Label>
                        <Input type="text" id="emailId" placeholder="Enter your email id" name="emailId" value={emailId} onChange={this.handleChange}/>
                      </FormGroup>
                    </Col>
                  </FormGroup>
                }
                
                
              </CardBody>
              <CardFooter>
                  <Button type="submit" size="sm" color="primary" style={{marginRight: '10px'}} 
                    disabled={!this.isValidForm()} onClick={() => {this.handleSubmit();}}>
                    <i className="fa fa-save"></i> Submit</Button>
                  <Button type="reset" size="sm" color="info" tag={Link} to={`/settings/users`}>
                    <i className="fa fa-arrow-left"></i> Back</Button>
                  <Label style={{float: 'right'}}><span style={{ color: 'red'}}>* </span><strong>Marked fields are mandatory</strong></Label>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      }
      </div>
    )
  }
}

export default CreateUser;

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.
