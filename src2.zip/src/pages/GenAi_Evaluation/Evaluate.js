import React, { useContext } from "react";
import { useState } from "react";
import Configure from "../../components/GenAi_Evaluation/Configure/Configure";
import Evaluation from "../../components/GenAi_Evaluation/Evaluation/Evaluation";
import { AuthContext } from "../../globals/AuthContext";
import { useLocation } from "react-router-dom";

//Changing order of tab will impact other page redirection to this page
let tabMenu = ["Configure", "Evaluation"];

const Evaluate = () => {
  const ctx = useContext(AuthContext);
  const location = useLocation();

  ctx.updateHeader("Evaluation");
  const [selectedTab, setSelectedTab] = useState(
    tabMenu[(location.state && location.state.tabIndex) || 0]
  );

  const handleTabSelection = (menu) => {
    setSelectedTab(menu);
  };
  return (
    <div>
      <div
        style={{
          backgroundColor: "#FEF2FA",
          borderBottom: "1px solid #C8C4D9",
          color: "gray",
        }}
      >
        {tabMenu.map((menu) => (
          <h5
            style={{
              display: "inline-block",
              margin: "0",
              padding: "8px",
              borderRight: "1px solid #C8C4D9",
              color: selectedTab === menu ? "#4546D9" : "#434343",
              borderBottom: selectedTab === menu ? "2px solid #4546D9" : null,
              fontSize: "1rem",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => handleTabSelection(menu)}
          >
            {menu}
          </h5>
        ))}
      </div>

      <div style={{ padding: "1rem" }}>
        {selectedTab === "Configure" && <Configure />}
        {selectedTab === "Evaluation" && <Evaluation />}
      </div>
    </div>
  );
};

export default Evaluate;
