import { Box, Paper, TextField, Typography } from "@mui/material";
import React, { useState } from "react";

const PromptTemplate = ({
  heading,
  level,
  levelIndex,
  template,
  promptType,
  setVariableNameList,
  setVariableTypes,
  setSelectedVariable,
  handleChangeCustomPromptTemplate,
}) => {
  const extractPromptVariables = (event) => {
    const { name, value } = event.target;
    const regex = /{([^}]*)}/g;
    const variable_names = [];
    const initialVariableTypeMapObject = {};
    let match;
    if (promptType === "Single Level") promptType = "1 Level";
    let isTypeEqualLevel = promptType.split("")[0] === level.split("_")[1];
    if (isTypeEqualLevel) {
      while ((match = regex.exec(value)) !== null) {
        variable_names.push(match[1]);
        initialVariableTypeMapObject[match[1]] = "String";
      }
      setVariableNameList(variable_names);
      setVariableTypes(initialVariableTypeMapObject);
      setSelectedVariable(variable_names[0]);
    }
    handleChangeCustomPromptTemplate(name, value, levelIndex);
  };

  return (
    <Paper sx={{ p: 1, mb: 2 }} elevation={2}>
      <Box sx={{ mb: 0.5 }}>
        <Typography variant="body">{heading}</Typography>
      </Box>
      {/* Prompt Template input field */}
      <TextField
        fullWidth
        id="outlined-basic"
        label="Prompt Template"
        variant="outlined"
        margin="dense"
        name="promptTemplate"
        multiline
        minRows={2}
        required
        value={template}
        onChange={extractPromptVariables}
      />
    </Paper>
  );
};

export default PromptTemplate;
