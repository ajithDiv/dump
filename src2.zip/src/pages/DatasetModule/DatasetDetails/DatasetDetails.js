import {
  Alert,
  Box,
  Button,
  Checkbox,
  Chip,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  IconButton,
  InputLabel,
  ListItemText,
  MenuItem,
  Modal,
  OutlinedInput,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Snackbar,
  Stack,
  Switch,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import AddIcon from "@mui/icons-material/Add";
import uploadPromptsIcon from "../../../assets/genaiIcons/arrow_circle_right.png";
import generatePromptsIcon from "../../../assets/genaiIcons/model_training.png";
import CloseIcon from "@mui/icons-material/Close";
import bg from "../../../assets/img/background.png";
import deleteIcon from "../../../assets/genaiIcons/delete.png";
import wordIcon from "../../../assets/genaiIcons/word.png";
import excelIcon from "../../../assets/genaiIcons/excel.png";
import csvIcon from "../../../assets/genaiIcons/csv.png";
import pdfIcon from "../../../assets/genaiIcons/pdf.png";
import txtFile from "../../../assets/genaiIcons/txt.png";
import moreOptionsIcon from "../../../assets/genaiIcons/more_vert.png";

import styles from "./DatasetDetails.module.css";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import AugmentDataset from "../AugmentDataset/AugmentDataset";
import VerifyDataset from "../VerifyDataset/VerifyDataset";
import FileUpload from "../../../components/FileUpload/FileUpload";
import TextSnippetOutlinedIcon from "@mui/icons-material/TextSnippetOutlined";
import {
  downloadTemplate,
  generatePrompt,
  generateQuestions,
  getDatasetById,
  getProjectById,
  uploadDocuments,
  uploadFile,
} from "../../../_services/genai_dataset.service";
import { AuthContext } from "../../../globals/AuthContext";
import { getModelDetails } from "../../../_services/genai_evaluation.service";
import { getExistingModels } from "../../../_services/model.service";
import CoverageForCodeGen from "../../../components/GenAi_Evaluation/Coverage/CoverageForCodeGen";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
      overflowX: "auto",
    },
  },
};

const questionTypeList = [
  {
    label: "Basic Questions - Generates default questions",
    value: "Basic Questions",
  },
  { label: "Seed - Generates a simple question", value: "Seed" },
  {
    label:
      "Reasoning - Response contains multiple logical connections or inferences",
    value: "Reasoning",
  },
  {
    label:
      "Conditioning - Question contains scenario or condition present in context",
    value: "Conditioning",
  },
  {
    label: "Compressed - Question is as short as possible.",
    value: "Compressed",
  },
  {
    label:
      "Conversational - 2 Questions that are dependent on each other like a conversation",
    value: "Conversational",
  },
  {
    label:
      "Hypothetical - Question contains hypothetical scenario that can be answered from context",
    value: "Hypothetical",
  },
  {
    label:
      "Analytical - Question requires analytical thinking for generating response",
    value: "Analytical",
  },
  {
    label:
      "Comparative - Question contains a comparision element from the context",
    value: "Comparative",
  },
  {
    label:
      "Problem-Solving - Question contains a problem that can be solved from the context",
    value: "Problem-Solving",
  },
  {
    label:
      "Creative - Response generation requires imaginative and innovative thinking",
    value: "Creative",
  },
  {
    label:
      "Multiple - Choice - Question contains multiple choices and response is one correct choice",
    value: "Multiple-Choice",
  },
  {
    label:
      "Detailed - Response to the question is detailed often more than 1 sentences",
    value: "Detailed",
  },
];

const questionTypeListForQandA = [
  { label: "Seed - Generates a simple question", value: "Seed" },
  {
    label:
      "Reasoning - Response contains multiple logical connections or inferences",
    value: "Reasoning",
  },
  {
    label:
      "Multi-Context - Questions requires multiple contexts to generate answer",
    value: "Multi-Context",
  },
  {
    label:
      "Multiple - Choice - Question contains multiple choices and response is one correct choice",
    value: "Multiple-Choice",
  },
  {
    label:
      "Analytical - Question requires analytical thinking for generating response",
    value: "Analytical",
  },
  {
    label:
      "Hypothetical - Question contains hypothetical scenario that can be answered from context",
    value: "Hypothetical",
  },
  {
    label:
      "Comparative - Question contains a comparision element from the context",
    value: "Comparative",
  },
];

const awsFields = [
  { label: "Service Name", key: "SERVICE_NAME" },
  { label: "Region Name", key: "REGION_NAME" },
  { label: "Access Key ID", key: "AWS_ACCESS_KEY_ID" },
  { label: "Secret Access Key", key: "AWS_SECRET_ACCESS_KEY" },
];

const azureFields = [
  { label: "OpenAI API Key", key: "OPENAI_API_KEY" },
  { label: "OpenAI API Version", key: "OPENAI_API_VERSION" },
  { label: "Deployment Name", key: "DEPLOYMENT_NAME" },
  { label: "OpenAI Endpoint", key: "OPENAI_ENDPOINT" },
];

const anthropicFields = [
  { label: "Anthropic API Key", key: "ANTHROPIC_API_KEY" },
];

const DatasetDetails = (props) => {
  const { state } = useLocation();

  const ctx = useContext(AuthContext);
  const parameters = useParams();

  let tabMenu =
    ctx.projectSubType === "SUM"
      ? ["Generate", "Augment", "Verify"] :  ctx.projectSubType === "CODEGEN" ?  ["Generate", "Augment", "Verify", "Coverage"]  
      : ["Upload", "Generate", "Augment", "Verify"];

  const [selectedTab, setSelectedTab] = useState(
    ctx.projectSubType === "SUM" ? "Generate" : "Upload"
  );
  const [keyword, setKeyword] = useState("");
  const [keywordList, setKeywordList] = useState([]);

  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [documentModal, setDcoumentModal] = useState(false);
  const [documentFiles, setDocumentFiles] = useState([]);
  const [snackOpen, setSnackOpen] = useState(false);
  const [snackData, setSnackData] = useState("");
  const [selectedGenerateOption, setSelectedGenerateOption] = useState(
    ctx.projectSubType === "P2I" || ctx.projectSubType === "SUM"
      ? "Upload Curated Dataset"
      : "Generate Input"
  );
  const [selectedCriticValue, setSelectedCriticValue] = useState("Moderate");
  const [providersList, setProvidersList] = useState({});
  const [open, setOpen] = useState(false);
  const [provider, setProvider] = useState("");
  const [selectedExistingModel, setSelectedExistingModel] = useState("");
  const [modelName, setModelName] = useState("");
  const [modelDetails, setModelDetails] = useState({});
  const [projectType, setProjectType] = useState("");
  const [parser, setParser] = useState("Inhouse");
  const [files, setFiles] = useState([]);
  const [selectedQuestionTypes, setSelectedQuestionTypes] = useState([
    ctx.projectSubType === "GEN" ? "Seed" : "Basic Questions",
  ]);
  const [isCritic, setIsCritic] = useState(false);
  const [documentList, setDocumentList] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [numberInput, setNumberInput] = useState(5);
  const [inputMinToken, setInputMinToken] = useState(5);
  const [inputMaxToken, setInputMaxToken] = useState(30);
  const [outputMinToken, setOutputMinToken] = useState(10);
  const [outputMaxToken, setOutputMaxToken] = useState(40);
  const [existingModels, setExistingModels] = useState([]);
  const [checked, setChecked] = React.useState(false);
  const [evaluatorName, setEvaluatorName] = useState("");
  const [inProgress, setInProgress] = useState(false);

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const handleCriticLLMChange = (event) => {
    setIsCritic(event.target.checked);
  };

  if (state.datasetId !== "" || state.datasetId !== null) {
    ctx.updateDatasetId(state.datasetId);
  }
  let datasetId = ctx.datasetId;

  const handleClose = () => {
    setSnackOpen(false);
  };

  const navigate = useNavigate();

  const handleChangeGenerateOption = (event) => {
    setSelectedGenerateOption(event.target.value);
  };

  const handleCriticChange = (event) => {
    setSelectedCriticValue(event.target.value);
  };

  const handleFileUploadSubmit = () => {
    setInProgress(true);
    uploadFile(uploadedFiles[0], datasetId, ctx.projectSubType).then(
      (result) => {
        setInProgress(false);
        navigate("prompts", { state: { datasetId: datasetId } });
      }
    );
  };

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(files);
  };

  const removeFile = (file) => {
    // console.log(file);
  };

  const handleDocumentFileUploadSubmit = () => {
    uploadDocuments(documentFiles, datasetId, parser).then(
      (result) => {
        setDcoumentModal(false);
        setSnackData("File Uploaded Successfully");
        setSnackOpen(true);
        getDatasetById(parameters.id).then((result) => {
          setDocumentList(result.data.file_metadata);
          let arr = [];
          result.data.file_metadata.map((item) => {
            arr.push({
              label: item.file_name,
              value: item.file_path,
            });
          });
          setFiles(arr);
        });
      },
      (error) => {
        setDcoumentModal(false);
        setSnackData(error.response.data.error);
        setSnackOpen(true);
      }
    );
  };

  const handleDocumentFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setDocumentFiles(files);
  };

  const removeDocumentFile = (file) => {
    let temp = [...documentFiles];
    setDocumentFiles(
      temp.filter((existingFile) => existingFile.name !== file.name)
    );
  };

  const handleTabSelection = (menu) => {
    setSelectedTab(menu);
  };

  const handleKeywordChange = (event) => {
    setKeyword(event.target.value);
  };

  const addKeyword = () => {
    if (keyword !== "") {
      setKeywordList((prevList) => [...prevList, keyword]);
      setKeyword("");
    }
  };

  const handleKeywordDelete = (val) => {
    setKeywordList((prevList) => prevList.filter((item) => item !== val));
  };

  const toggleDocumentModal = () => {
    setDcoumentModal((prev) => !prev);
  };

  const handleDownloadTemplate = async () => {
    try {
      const blobData = await downloadTemplate();

      // const blobData = await blobResponse();

      const url = window.URL.createObjectURL(new Blob([blobData]));

      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "InputsTemplate.xlsx");
      document.body.appendChild(link);
      link.click();

      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
      setSnackOpen(true);
      setSnackData("File downloaded successfully.");
    } catch (error) {
      console.error("Error downloading file:", error);
    }
  };

  const handleSubmitCreatePrompts = () => {
    let arr = [];
    files.map((item) => {
      if (
        selectedFiles.indexOf(item.label) > -1 ||
        selectedFiles.indexOf("All Files") > -1
      ) {
        arr.push(item.value);
      }
    });

    let modified_list_files = arr.map((file) => [file]);
    let temp_model_details = modelDetails;
    let temp_model_name = modelName;
    let temp_provider = provider;
    if (!checked) {
      for (let i = 0; i < existingModels.length; i++) {
        if (selectedExistingModel === existingModels[i].customEvaluatorName) {
          temp_model_details = { ...existingModels[i].details };
          temp_model_name = existingModels[i].model;
          temp_provider = existingModels[i].provider;
        }
      }
    }
    let fileKind = "Individuals";
    if (selectedFiles.indexOf("All Files") > -1) {
      fileKind = "All Files";
      // modified_list_files = [];
    }
    let data = {
      isCreate: checked,
      projectName: ctx.projectName,
      datasetId: datasetId,
      fileKind: fileKind,
      paths: modified_list_files,
      question_types: selectedQuestionTypes,
      no_of_questions: numberInput,
      in_min_tok: inputMinToken,
      in_max_tok: inputMaxToken,
      out_min_tok: outputMinToken,
      out_max_tok: outputMaxToken,
      avoid_keywords: keywordList,
      parserType: parser,
      model: temp_model_name,
      provider: temp_provider,
      customEvaluatorName: checked ? evaluatorName : selectedExistingModel,
      modelDetails: temp_model_details,
      is_critic: isCritic,
      filter_type: isCritic ? selectedCriticValue : "",
    };
    setInProgress(true);
    generatePrompt(data).then((result) => {
      // navigate("prompts", { state: { datasetId: datasetId } });
      setInProgress(false);
    });
  };

  const handleFileChange = (event) => {
    const {
      target: { value },
    } = event;
    setSelectedFiles((prev) => {
      // On autofill we get a stringified value.
      let newState = typeof value === "string" ? value.split(",") : value;

      if (newState.indexOf("All Files") > -1) {
        if (newState[newState.length - 1] === "All Files") {
          return ["All Files"];
        } else {
          let arr = [];
          files.map((item) => {
            if (newState.indexOf(item.label) === -1) {
              arr.push(item.label);
            }
          });
          return arr;
        }
      }
      if (newState.length === files.length) {
        return ["All Files"];
      }
      return newState;
    });
  };

  const handleChangeQuestionTypes = (event) => {
    const {
      target: { value },
    } = event;
    setSelectedQuestionTypes(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleChangeParser = (event) => {
    setParser(event.target.value);
  };

  const generateQuestion = () => {
    let arr = [];
    files.map((item) => {
      if (
        selectedFiles.indexOf(item.label) > -1 ||
        selectedFiles.indexOf("All Files")
      ) {
        arr.push(item.value);
      }
    });
    let modified_list_files = arr.map((file) => [file]);
    let data = {
      datasetId: datasetId,
      paths: modified_list_files,
      question_types: selectedQuestionTypes,
      no_of_questions: numberInput,
      in_min_tok: inputMinToken,
      in_max_tok: inputMaxToken,
      out_min_tok: outputMinToken,
      out_max_tok: outputMaxToken,
      avoid_keywords: keywordList,
    };

    generateQuestions(data).then((result) => {
      // console.log(result);
    });
  };

  useEffect(() => {
    getModelDetails().then((result) => {
      const parsedModels = JSON.parse(result.models);

      const providers = {};

      parsedModels.forEach((item) => {
        const provider = item.Provider;
        const models = item.Model;
        providers[provider] = models;
      });

      setProvidersList(providers);
    });

    getProjectById(ctx.projectId).then((result) => {
      setProjectType(result.data.projectType);
    });

    getDatasetById(parameters.id).then((result) => {
      setDocumentList(result.data.file_metadata);
      let arr = [];
      result.data.file_metadata.map((item) => {
        arr.push({
          label: item.file_name,
          value: item.file_path,
        });
      });
      setFiles(arr);
    });

    getExistingModels({
      projectName: ctx.projectName,
    }).then((res) => {
      setExistingModels(res);
    });
  }, []);

  return (
    <div style={{ backgroundImage: bg }}>
      <Snackbar open={snackOpen} autoHideDuration={6000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity="info"
          variant="filled"
          sx={{ width: "100%" }}
        >
          {snackData}
        </Alert>
      </Snackbar>
      <div
        style={{
          backgroundColor: "#FEF2FA",
          borderBottom: "1px solid #C8C4D9",
          color: "gray",
        }}
      >
        {tabMenu.map((menu) => (
          <h5
            style={{
              display: "inline-block",
              margin: "0",
              padding: "8px",
              borderRight: "1px solid #C8C4D9",
              color: selectedTab === menu ? "#4546D9" : "#434343",
              borderBottom: selectedTab === menu ? "2px solid #4546D9" : null,
              fontSize: "1rem",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => handleTabSelection(menu)}
          >
            {menu}
          </h5>
        ))}
      </div>
      {selectedTab === "Upload" && (
        <Stack className={styles.documentContainer} gap="1rem">
          <div className={styles.documentUploadBtn}>
            <Button
              style={{ backgroundColor: "#4546D9" }}
              variant="contained"
              onClick={toggleDocumentModal}
            >
              Upload Documents{" "}
              <img src={uploadPromptsIcon} alt="Upload Documents" />{" "}
            </Button>
          </div>

          <Paper>
            <Paper className={styles.documentHeader}>
              Latest Document Processed ({documentList.length})
            </Paper>

            <div className={styles.documentContent}>
              {documentList.length === 0 && (
                <Typography
                  margin="auto"
                  color="#6C6E7C"
                  width="100%"
                  textAlign="center"
                  alignItems="center"
                >
                  No Documents Uploaded
                </Typography>
              )}
              {documentList.map((docs) => (
                <Paper elevation={2} className={styles.documentBox}>
                  <div className={styles.firstLayer}>
                    <div className={styles.iconContainer}>
                      <img
                        alt="File Icon"
                        src={
                          docs.file_path.endsWith(".xlsx")
                            ? excelIcon
                            : docs.file_path.endsWith(".docx")
                            ? wordIcon
                            : docs.file_path.endsWith(".csv")
                            ? csvIcon
                            : docs.file_path.endsWith(".pdf")
                            ? pdfIcon
                            : txtFile
                        }
                      />
                    </div>
                    <div className={styles.optionContainer}>
                      <img alt="Options Icon" src={moreOptionsIcon} />
                    </div>
                  </div>
                  <div className={styles.documentDetails}>
                    {docs.file_name.length > 15
                      ? docs.file_name.substr(0, 15) + "..."
                      : docs.file_name}
                    <div className={styles.uploadTime}>{docs.upload_time}</div>
                  </div>
                  <div className={styles.documentBoxFooter}>
                    {docs.file_size ? docs.file_size.toFixed(2) : 105.76}kb
                  </div>
                </Paper>
              ))}
            </div>
          </Paper>

          <Box width="100%" textAlign="center">
            <Button
              variant="contained"
              onClick={() => setSelectedTab("Generate")}
            >
              Skip
            </Button>
          </Box>

          <Modal
            style={{ overflow: "auto", padding: "1rem" }}
            open={documentModal}
            onClose={toggleDocumentModal}
            aria-labelledby="document-modal-title"
            aria-describedby="document-modal-description"
          >
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                maxWidth: "90%", // Adjust the maximum width as needed
                width: "504px",
                bgcolor: "background.paper",
                boxShadow: 24,
                overflow: "auto", // Enable scrolling if content overflows
                maxHeight: "85vh", // Set a maximum height to trigger scrolling
                // p: 2,
                borderRadius: "1rem",
              }}
            >
              <div className={styles.modalHeader}>
                <Typography
                  id="document-modal-title"
                  variant="h6"
                  component="h2"
                >
                  Upload Documents
                </Typography>
                <IconButton onClick={toggleDocumentModal}>
                  {" "}
                  <CloseIcon />
                </IconButton>
              </div>
              <div className={styles.modalContent}>
                <FileUpload
                  handleFileUploadSubmit={handleDocumentFileUploadSubmit}
                  handleFileUpload={handleDocumentFileUpload}
                  uploadedFiles={documentFiles}
                  updateFiles={setDocumentFiles}
                  removeFile={removeDocumentFile}
                  multi={true}
                  // fileInputRef={fileInputRef}
                  acceptType={
                    parser === "Unstructured.io"
                      ? ".html, .txt, .xml, .png, .jpg, .jpeg, .doc, .docx, .epub, .pdf, .ppt, .pptx, .xlsx"
                      : ".pdf, .docx, .xml, .txt, .mp3, .wav, .flac, .mp4, .avi, .mov"
                  }
                />
              </div>
            </Box>
          </Modal>
        </Stack>
      )}

      {selectedTab === "Generate" && (
        <>
          {inProgress && (
            <Typography style={{ margin: "1rem" }} color="red">
              Test Data Generation is in progress...
            </Typography>
          )}
          <div className={styles.inputBody}>
            <FormControl fullWidth>
              <RadioGroup
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue="Generate Input"
                name="radio-buttons-group"
                className={styles.radioContainer}
                value={selectedGenerateOption}
                onChange={handleChangeGenerateOption}
              >
                <Paper
                  style={{
                    borderRadius: "0.5rem",
                    backgroundColor:
                      selectedGenerateOption === "Generate Input"
                        ? "#E9FAFF"
                        : null,
                    border:
                      selectedGenerateOption === "Generate Input"
                        ? "2px solid #0546C5"
                        : null,
                  }}
                  className={styles.radioBox}
                >
                  <FormControlLabel
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "start",
                    }}
                    value="Generate Input"
                    control={<Radio />}
                    label={
                      <>
                        <strong>Generate Input</strong>
                        <br />
                        <p>
                          This option enables you to generate Input, Output, and
                          Context data from the documents that got uploaded.
                        </p>
                      </>
                    }
                  />
                </Paper>
                <Paper
                  style={{
                    borderRadius: "0.5rem",
                    backgroundColor:
                      selectedGenerateOption === "Upload Curated Dataset"
                        ? "#E9FAFF"
                        : null,
                    border:
                      selectedGenerateOption === "Upload Curated Dataset"
                        ? "2px solid #0546C5"
                        : null,
                  }}
                  className={styles.radioBox}
                >
                  <FormControlLabel
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "start",
                    }}
                    value="Upload Curated Dataset"
                    control={<Radio />}
                    label={
                      <>
                        <strong>Upload Curated Dataset</strong>
                        <br />
                        <p>
                          Upload your curated dataset which includes the Input ,
                          Output and Context.
                        </p>
                      </>
                    }
                  />
                </Paper>
              </RadioGroup>
            </FormControl>
          </div>

          {selectedGenerateOption === "Generate Input" && (
            <>
              <Typography
                fontSize="20px"
                fontWeight="500"
                margin="1rem"
                color="#313B3E"
              >
                Settings
              </Typography>

              <div className={styles.inputBody}>
                <FormControl fullWidth>
                  <RadioGroup
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="Generate Input"
                    name="radio-buttons-group"
                    className={styles.radioContainer}
                    value={parser}
                    onChange={handleChangeParser}
                  >
                    <Paper
                      style={{
                        borderRadius: "0.5rem",
                        backgroundColor:
                          parser === "Inhouse" ? "#E9FAFF" : null,
                        border:
                          parser === "Inhouse" ? "2px solid #0546C5" : null,
                      }}
                      className={styles.radioBox}
                    >
                      <FormControlLabel
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "start",
                        }}
                        value="Inhouse"
                        control={<Radio />}
                        label={
                          <>
                            <strong>Inhouse Parser</strong>
                            <br />
                            <p>
                              Supported FileTypes: .mp3, .flac, .wav, .mp4,
                              .mov, .avi, .pdf, .docx, .xml
                            </p>
                          </>
                        }
                      />
                    </Paper>
                    <Paper
                      style={{
                        borderRadius: "0.5rem",
                        backgroundColor:
                          parser === "Unstructured.io" ? "#E9FAFF" : null,
                        border:
                          parser === "Unstructured.io"
                            ? "2px solid #0546C5"
                            : null,
                      }}
                      className={styles.radioBox}
                    >
                      <FormControlLabel
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "start",
                        }}
                        value="Unstructured.io"
                        control={<Radio />}
                        label={
                          <>
                            <strong>Unstructured.io</strong>
                            <br />
                            <p>
                              Supported FilTypes: .pdf, .docx, .doc, .odt,
                              .pptx, .ppt, .xlsx, .csv, .epub, .html, .xml,
                              .jpeg, .png, .bmp
                            </p>
                          </>
                        }
                      />
                    </Paper>
                  </RadioGroup>
                </FormControl>
              </div>

              <Paper style={{ margin: "1rem", padding: "1rem" }}>
                <Stack direction="column" gap="1rem">
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>
                      <strong>Select Files</strong>
                    </FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: 700 }}>
                      <Select
                        fullWidth
                        displayEmpty
                        labelId="demo-multiple-checkbox-label"
                        id="demo-multiple-checkbox"
                        multiple
                        value={selectedFiles}
                        onChange={handleFileChange}
                        // input={<OutlinedInput label="Select Inputs" />}
                        renderValue={(selected) => {
                          if (selected.length === 0) {
                            return <em>Select Files</em>;
                          }
                          return (
                            <Box
                              sx={{
                                display: "flex",
                                flexWrap: "wrap",
                                gap: 0.5,
                              }}
                            >
                              {selected.map((value) => (
                                <Chip key={value} label={value} />
                              ))}
                            </Box>
                          );
                        }}
                        MenuProps={MenuProps}
                      >
                        <MenuItem value="All Files">
                          <Checkbox
                            checked={selectedFiles.indexOf("All Files") > -1}
                          />
                          <ListItemText primary={"All Files"} />
                        </MenuItem>
                        {files.map((item) => (
                          <MenuItem key={item.value} value={item.label}>
                            <Checkbox
                              checked={
                                selectedFiles.indexOf(item.label) > -1 ||
                                selectedFiles.indexOf("All Files") > -1
                              }
                            />
                            <ListItemText primary={item.label} />
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Stack>

                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>
                      <strong>Select Question Types</strong>
                    </FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: 700 }}>
                      <Select
                        fullWidth
                        displayEmpty
                        labelId="demo-multiple-checkbox-label"
                        id="demo-multiple-checkbox"
                        multiple
                        value={selectedQuestionTypes}
                        onChange={handleChangeQuestionTypes}
                        // input={<OutlinedInput label="Select Inputs" />}
                        renderValue={(selected) => {
                          return (
                            <Box
                              sx={{
                                display: "flex",
                                flexWrap: "wrap",
                                gap: 0.5,
                              }}
                            >
                              {selected.map((value) => (
                                <Chip key={value} label={value} />
                              ))}
                            </Box>
                          );
                        }}
                        MenuProps={MenuProps}
                      >
                        {ctx.projectSubType === "GEN"
                          ? questionTypeListForQandA.map((item) => (
                              <MenuItem key={item.value} value={item.value}>
                                <Checkbox
                                  checked={
                                    selectedQuestionTypes.indexOf(item.value) >
                                    -1
                                  }
                                />
                                <ListItemText primary={item.label} />
                              </MenuItem>
                            ))
                          : questionTypeList.map((item) => (
                              <MenuItem key={item.value} value={item.value}>
                                <Checkbox
                                  checked={
                                    selectedQuestionTypes.indexOf(item.value) >
                                    -1
                                  }
                                />
                                <ListItemText primary={item.label} />
                              </MenuItem>
                            ))}
                      </Select>
                    </FormControl>
                  </Stack>

                  {ctx.projectSubType === "GEN" && (
                    <Stack direction="row" alignItems="center" spacing={2}>
                      <FormLabel sx={{ width: "10rem" }}>
                        <strong>Critic LLM</strong>
                      </FormLabel>
                      <FormLabel>:</FormLabel>
                      <Checkbox
                        checked={isCritic}
                        onChange={handleCriticLLMChange}
                        inputProps={{ "aria-label": "controlled" }}
                      />
                    </Stack>
                  )}

                  {isCritic && (
                    <div className={styles.inputBody}>
                      <FormControl style={{ width: "50%" }}>
                        <RadioGroup
                          aria-labelledby="demo-radio-buttons-group-label"
                          defaultValue="Moderate"
                          name="radio-buttons-group"
                          className={styles.radioContainer}
                          value={selectedCriticValue}
                          onChange={handleCriticChange}
                        >
                          <Paper
                            style={{
                              borderRadius: "0.5rem",
                              backgroundColor:
                                selectedCriticValue === "Moderate"
                                  ? "#E9FAFF"
                                  : null,
                              border:
                                selectedCriticValue === "Moderate"
                                  ? "2px solid #0546C5"
                                  : null,
                            }}
                            className={styles.radioBox}
                          >
                            <FormControlLabel
                              sx={{
                                display: "flex",
                                flexDirection: "row",
                                alignItems: "start",
                              }}
                              value="Moderate"
                              control={<Radio />}
                              label={
                                <>
                                  <strong>Moderate</strong>
                                </>
                              }
                            />
                          </Paper>
                          <Paper
                            style={{
                              borderRadius: "0.5rem",
                              backgroundColor:
                                selectedCriticValue === "Strict"
                                  ? "#E9FAFF"
                                  : null,
                              border:
                                selectedCriticValue === "Strict"
                                  ? "2px solid #0546C5"
                                  : null,
                            }}
                            className={styles.radioBox}
                          >
                            <FormControlLabel
                              sx={{
                                display: "flex",
                                flexDirection: "row",
                                alignItems: "start",
                              }}
                              value="Strict"
                              control={<Radio />}
                              label={
                                <>
                                  <strong>Strict</strong>
                                </>
                              }
                            />
                          </Paper>
                        </RadioGroup>
                      </FormControl>
                    </div>
                  )}
                </Stack>
              </Paper>

              <div className={styles.container}>
                <Paper elevation={3} className={styles.inputContainer}>
                  <Paper className={styles.inputHeader}>
                    Inputs &nbsp;
                    <InfoOutlinedIcon color="action" />
                  </Paper>
                  <div className={styles.inputBody}>
                    <TextField
                      fullWidth
                      id="outlined-basic"
                      label="No. of test-data to be generated per chunk"
                      variant="outlined"
                      margin="dense"
                      type="number"
                      value={numberInput}
                      onChange={(e) => setNumberInput(+e.target.value)}
                    />
                  </div>
                </Paper>

                <Paper elevation={3} className={styles.inputContainer}>
                  <Paper className={styles.inputHeader}>
                    Input Tokens &nbsp;
                    <InfoOutlinedIcon color="action" />
                  </Paper>
                  <div className={styles.inputBody}>
                    <TextField
                      className={styles.textBox}
                      id="outlined-basic"
                      label="Min Value"
                      variant="outlined"
                      margin="dense"
                      type="number"
                      value={inputMinToken}
                      onChange={(e) => setInputMinToken(+e.target.value)}
                    />
                    <TextField
                      className={styles.textBox}
                      id="outlined-basic"
                      label="Max Value"
                      variant="outlined"
                      margin="dense"
                      type="number"
                      value={inputMaxToken}
                      onChange={(e) => setInputMaxToken(+e.target.value)}
                    />
                  </div>
                </Paper>
                <Paper elevation={3} className={styles.inputContainer}>
                  <Paper className={styles.inputHeader}>
                    Output Tokens &nbsp;
                    <InfoOutlinedIcon color="action" />
                  </Paper>
                  <div className={styles.inputBody}>
                    <TextField
                      className={styles.textBox}
                      id="outlined-basic"
                      label="Min Value"
                      variant="outlined"
                      margin="dense"
                      type="number"
                      value={outputMinToken}
                      onChange={(e) => setOutputMinToken(+e.target.value)}
                    />
                    <TextField
                      className={styles.textBox}
                      id="outlined-basic"
                      label="Max Value"
                      variant="outlined"
                      margin="dense"
                      type="number"
                      value={outputMaxToken}
                      onChange={(e) => setOutputMaxToken(+e.target.value)}
                    />
                  </div>
                </Paper>
              </div>

              <div className={styles.keyword}>
                <Paper elevation={3} className={styles.keywordContainer}>
                  <Paper className={styles.keywordHeader}>
                    Refrain Input generation with keywords &nbsp;
                    <InfoOutlinedIcon color="action" />
                  </Paper>
                  <div className={styles.keywordBody}>
                    <div className={styles.keywordBox}>
                      {keywordList &&
                        keywordList.map((item) => (
                          <>
                            <Chip
                              style={{ backgroundColor: "#E1EAFF" }}
                              label={item}
                              variant="filled"
                              onDelete={() => handleKeywordDelete(item)}
                            />
                            &nbsp;
                          </>
                        ))}
                    </div>
                    <div className={styles.keywordInput}>
                      <TextField
                        className={styles.textBox}
                        id="outlined-basic"
                        label="Enter the keyword"
                        variant="outlined"
                        margin="dense"
                        type="text"
                        value={keyword}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            addKeyword();
                          }
                        }}
                        onChange={handleKeywordChange}
                      />
                      <Button
                        variant="contained"
                        size="large"
                        style={{ backgroundColor: "#4546D9" }}
                        onClick={addKeyword}
                      >
                        Add
                        <AddIcon />
                      </Button>
                    </div>
                  </div>
                </Paper>
              </div>
              <div className={styles.buttonContainer}>
                {/* <Button
                  variant="contained"
                  style={{ backgroundColor: "#4546D9" }}
                  onClick={generateQuestion}
                >
                  Generate Questions
                  <img src={generatePromptsIcon} alt="generateInputsIcon" />
                </Button> */}

                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setOpen(true)}
                  disabled={
                    selectedFiles.length === 0 ||
                    selectedQuestionTypes.length === 0
                  }
                >
                  Generate Test Data
                  <img src={generatePromptsIcon} alt="generateInputsIcon" />
                </Button>
              </div>
            </>
          )}

          {selectedGenerateOption === "Upload Curated Dataset" && (
            <>
              <Typography
                fontSize="20px"
                fontWeight="500"
                margin="1rem"
                color="#313B3E"
              >
                Upload Dataset
              </Typography>
              <div style={{ margin: "1rem" }}>
                <div style={{ textAlign: "right" }}>
                  <Tooltip
                    title="Download Template"
                    style={{ padding: "0 0 0.5rem 0" }}
                  >
                    <IconButton onClick={handleDownloadTemplate}>
                      <TextSnippetOutlinedIcon color="primary" />
                    </IconButton>
                  </Tooltip>
                </div>
                <FileUpload
                  handleFileUploadSubmit={handleFileUploadSubmit}
                  handleFileUpload={handleFileUpload}
                  uploadedFiles={uploadedFiles}
                  removeFile={removeFile}
                  multi={false}
                  inProgress={inProgress}
                  // fileInputRef={fileInputRef}
                  acceptType={
                    ctx.projectSubType === "P2I" ? ".xlsx, .csv" : "/*"
                  }
                />
              </div>
            </>
          )}
        </>
      )}

      {selectedTab === "Augment" && (
        <AugmentDataset projectType={projectType} datasetId={datasetId} />
      )}

      {selectedTab === "Verify" && <VerifyDataset datasetId={datasetId} />}

      {selectedTab === "Coverage" && <CoverageForCodeGen /> }

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "50rem",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "60vh", // Set a maximum height to trigger scrolling
            // p: 2,
            borderRadius: "1rem",
          }}
        >
          <Paper square elevation={1} className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Additional Inputs
            </Typography>
            <IconButton onClick={() => setOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Paper>
          <div className={styles.modalContent}>
            <Stack direction="column" spacing={2}>
              <Stack direction="row" alignItems="center" spacing={2}>
                <FormControlLabel
                  value="Create New Model"
                  control={
                    <Switch
                      checked={checked}
                      onChange={handleChange}
                      inputProps={{ "aria-label": "controlled" }}
                    />
                  }
                  label="Create New Model"
                  labelPlacement="start"
                />
              </Stack>
              {!checked && (
                <Stack direction="row" alignItems="center" spacing={2}>
                  <FormLabel sx={{ width: "10rem" }}>Existing Model</FormLabel>
                  <FormLabel>:</FormLabel>
                  <FormControl sx={{ m: 1, width: "70%" }}>
                    <Select
                      labelId="demo-simple-select-label"
                      id="demo-simple-select"
                      value={selectedExistingModel}
                      onChange={(e) => setSelectedExistingModel(e.target.value)}
                    >
                      {existingModels.map((item) => (
                        <MenuItem
                          key={item.customEvaluatorName}
                          value={item.customEvaluatorName}
                        >
                          {item.customEvaluatorName}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Stack>
              )}

              {checked && (
                <>
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>
                      Generator Name
                    </FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <TextField
                        id="outlined-basic"
                        variant="outlined"
                        value={evaluatorName}
                        onChange={(e) => setEvaluatorName(e.target.value)}
                      />
                    </FormControl>
                  </Stack>
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>Provider</FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={provider}
                        onChange={(e) => setProvider(e.target.value)}
                      >
                        {Object.keys(providersList).map((item) => (
                          <MenuItem key={item} value={item}>
                            {item}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Stack>

                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>Model</FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={modelName}
                        onChange={(e) => setModelName(e.target.value)}
                      >
                        {provider === "AWS-Bedrock"
                          ? providersList["AWS-Bedrock"].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))
                          : provider === "Azure"
                          ? providersList["Azure"].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))
                          : provider === "Anthropic"
                          ? providersList["Anthropic"].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))
                          : provider === "Cohere"
                          ? providersList["Cohere"].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))
                          : provider === "Meta"
                          ? providersList["Meta"].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))
                          : [].map((item) => (
                              <MenuItem key={item} value={item}>
                                {item}
                              </MenuItem>
                            ))}
                      </Select>
                    </FormControl>
                  </Stack>

                  {provider === "AWS-Bedrock"
                    ? awsFields.map((item, index) => (
                        <>
                          <Stack
                            direction="row"
                            alignItems="center"
                            spacing={2}
                          >
                            <FormLabel sx={{ width: "10rem" }}>
                              {item.label}
                            </FormLabel>
                            <FormLabel>:</FormLabel>
                            <FormControl sx={{ m: 1, width: "70%" }}>
                              <TextField
                                key={index}
                                label={item.label}
                                variant="outlined"
                                onChange={(e) => {
                                  setModelDetails((prev) => {
                                    let obj = { ...prev };
                                    obj[item.key] = e.target.value;
                                    return obj;
                                  });
                                }}
                              />
                            </FormControl>
                          </Stack>
                        </>
                      ))
                    : provider === "Azure"
                    ? azureFields.map((item, index) => (
                        <>
                          <Stack
                            direction="row"
                            alignItems="center"
                            spacing={2}
                          >
                            <FormLabel sx={{ width: "10rem" }}>
                              {item.label}
                            </FormLabel>
                            <FormLabel>:</FormLabel>
                            <FormControl sx={{ m: 1, width: "70%" }}>
                              <TextField
                                key={index}
                                label={item.label}
                                variant="outlined"
                                onChange={(e) => {
                                  setModelDetails((prev) => {
                                    let obj = { ...prev };
                                    obj[item.key] = e.target.value;
                                    return obj;
                                  });
                                }}
                              />
                            </FormControl>
                          </Stack>
                        </>
                      ))
                    : provider === "Anthropic"
                    ? anthropicFields.map((item, index) => (
                        <>
                          <Stack
                            direction="row"
                            alignItems="center"
                            spacing={2}
                          >
                            <FormLabel sx={{ width: "10rem" }}>
                              {item.label}
                            </FormLabel>
                            <FormLabel>:</FormLabel>
                            <FormControl sx={{ m: 1, width: "70%" }}>
                              <TextField
                                key={index}
                                label={item.label}
                                variant="outlined"
                                onChange={(e) => {
                                  setModelDetails((prev) => {
                                    let obj = { ...prev };
                                    obj[item.key] = e.target.value;
                                    return obj;
                                  });
                                }}
                              />
                            </FormControl>
                          </Stack>
                        </>
                      ))
                    : ""}
                </>
              )}
            </Stack>
          </div>
          <div className={styles.modalFooter}>
            Questions will be generated with following techniques :{" "}
            {selectedQuestionTypes.map((val, idx) => {
              if (idx === 0) {
                return val;
              }
              return ", " + val;
            })}
            <br />
            <Button
              style={{ marginBottom: "1rem" }}
              centerRipple
              variant="contained"
              color="primary"
              onClick={() => {
                handleSubmitCreatePrompts();
                setOpen(false);
              }}
            >
              Generate
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  );
};

export default DatasetDetails;
